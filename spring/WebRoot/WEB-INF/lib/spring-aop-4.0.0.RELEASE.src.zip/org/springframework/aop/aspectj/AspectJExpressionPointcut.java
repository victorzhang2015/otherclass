/*     */ package org.springframework.aop.aspectj;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.ObjectInputStream;
/*     */ import java.lang.reflect.Method;
/*     */ import java.util.HashSet;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import java.util.concurrent.ConcurrentHashMap;
/*     */ import org.aopalliance.intercept.MethodInvocation;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.aspectj.weaver.BCException;
/*     */ import org.aspectj.weaver.patterns.NamePattern;
/*     */ import org.aspectj.weaver.reflect.ReflectionWorld.ReflectionWorldException;
/*     */ import org.aspectj.weaver.reflect.ShadowMatchImpl;
/*     */ import org.aspectj.weaver.tools.ContextBasedMatcher;
/*     */ import org.aspectj.weaver.tools.JoinPointMatch;
/*     */ import org.aspectj.weaver.tools.MatchingContext;
/*     */ import org.aspectj.weaver.tools.PointcutDesignatorHandler;
/*     */ import org.aspectj.weaver.tools.PointcutExpression;
/*     */ import org.aspectj.weaver.tools.PointcutParameter;
/*     */ import org.aspectj.weaver.tools.PointcutParser;
/*     */ import org.aspectj.weaver.tools.PointcutPrimitive;
/*     */ import org.aspectj.weaver.tools.ShadowMatch;
/*     */ import org.springframework.aop.ClassFilter;
/*     */ import org.springframework.aop.IntroductionAwareMethodMatcher;
/*     */ import org.springframework.aop.MethodMatcher;
/*     */ import org.springframework.aop.ProxyMethodInvocation;
/*     */ import org.springframework.aop.framework.autoproxy.ProxyCreationContext;
/*     */ import org.springframework.aop.interceptor.ExposeInvocationInterceptor;
/*     */ import org.springframework.aop.support.AbstractExpressionPointcut;
/*     */ import org.springframework.aop.support.AopUtils;
/*     */ import org.springframework.beans.factory.BeanFactory;
/*     */ import org.springframework.beans.factory.BeanFactoryAware;
/*     */ import org.springframework.beans.factory.BeanFactoryUtils;
/*     */ import org.springframework.beans.factory.FactoryBean;
/*     */ import org.springframework.beans.factory.config.ConfigurableBeanFactory;
/*     */ import org.springframework.util.ObjectUtils;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ public class AspectJExpressionPointcut extends AbstractExpressionPointcut
/*     */   implements ClassFilter, IntroductionAwareMethodMatcher, BeanFactoryAware
/*     */ {
/*  83 */   private static final Set<PointcutPrimitive> SUPPORTED_PRIMITIVES = new HashSet();
/*     */ 
/*  99 */   private static final Log logger = LogFactory.getLog(AspectJExpressionPointcut.class);
/*     */   private Class<?> pointcutDeclarationScope;
/* 103 */   private String[] pointcutParameterNames = new String[0];
/*     */ 
/* 105 */   private Class<?>[] pointcutParameterTypes = new Class[0];
/*     */   private BeanFactory beanFactory;
/*     */   private transient PointcutExpression pointcutExpression;
/* 111 */   private transient Map<Method, ShadowMatch> shadowMatchCache = new ConcurrentHashMap(32);
/*     */ 
/*     */   public AspectJExpressionPointcut()
/*     */   {
/*     */   }
/*     */ 
/*     */   public AspectJExpressionPointcut(Class<?> declarationScope, String[] paramNames, Class<?>[] paramTypes)
/*     */   {
/* 127 */     this.pointcutDeclarationScope = declarationScope;
/* 128 */     if (paramNames.length != paramTypes.length) {
/* 129 */       throw new IllegalStateException("Number of pointcut parameter names must match number of pointcut parameter types");
/*     */     }
/*     */ 
/* 132 */     this.pointcutParameterNames = paramNames;
/* 133 */     this.pointcutParameterTypes = paramTypes;
/*     */   }
/*     */ 
/*     */   public void setPointcutDeclarationScope(Class<?> pointcutDeclarationScope)
/*     */   {
/* 141 */     this.pointcutDeclarationScope = pointcutDeclarationScope;
/*     */   }
/*     */ 
/*     */   public void setParameterNames(String[] names)
/*     */   {
/* 148 */     this.pointcutParameterNames = names;
/*     */   }
/*     */ 
/*     */   public void setParameterTypes(Class<?>[] types)
/*     */   {
/* 155 */     this.pointcutParameterTypes = types;
/*     */   }
/*     */ 
/*     */   public void setBeanFactory(BeanFactory beanFactory)
/*     */   {
/* 160 */     this.beanFactory = beanFactory;
/*     */   }
/*     */ 
/*     */   public ClassFilter getClassFilter()
/*     */   {
/* 166 */     checkReadyToMatch();
/* 167 */     return this;
/*     */   }
/*     */ 
/*     */   public MethodMatcher getMethodMatcher()
/*     */   {
/* 172 */     checkReadyToMatch();
/* 173 */     return this;
/*     */   }
/*     */ 
/*     */   private void checkReadyToMatch()
/*     */   {
/* 182 */     if (getExpression() == null) {
/* 183 */       throw new IllegalStateException("Must set property 'expression' before attempting to match");
/*     */     }
/* 185 */     if (this.pointcutExpression == null)
/* 186 */       this.pointcutExpression = buildPointcutExpression();
/*     */   }
/*     */ 
/*     */   private PointcutExpression buildPointcutExpression()
/*     */   {
/* 196 */     ClassLoader cl = (this.beanFactory instanceof ConfigurableBeanFactory) ? ((ConfigurableBeanFactory)this.beanFactory)
/* 195 */       .getBeanClassLoader() : Thread.currentThread()
/* 196 */       .getContextClassLoader();
/* 197 */     return buildPointcutExpression(cl);
/*     */   }
/*     */ 
/*     */   private PointcutExpression buildPointcutExpression(ClassLoader classLoader)
/*     */   {
/* 204 */     PointcutParser parser = initializePointcutParser(classLoader);
/* 205 */     PointcutParameter[] pointcutParameters = new PointcutParameter[this.pointcutParameterNames.length];
/* 206 */     for (int i = 0; i < pointcutParameters.length; i++) {
/* 207 */       pointcutParameters[i] = parser.createPointcutParameter(this.pointcutParameterNames[i], this.pointcutParameterTypes[i]);
/*     */     }
/*     */ 
/* 211 */     return parser.parsePointcutExpression(
/* 212 */       replaceBooleanOperators(getExpression()), this.pointcutDeclarationScope, pointcutParameters);
/*     */   }
/*     */ 
/*     */   private PointcutParser initializePointcutParser(ClassLoader cl)
/*     */   {
/* 221 */     PointcutParser parser = PointcutParser.getPointcutParserSupportingSpecifiedPrimitivesAndUsingSpecifiedClassLoaderForResolution(SUPPORTED_PRIMITIVES, cl);
/*     */ 
/* 223 */     parser.registerPointcutDesignatorHandler(new BeanNamePointcutDesignatorHandler(null));
/* 224 */     return parser;
/*     */   }
/*     */ 
/*     */   private String replaceBooleanOperators(String pcExpr)
/*     */   {
/* 235 */     String result = StringUtils.replace(pcExpr, " and ", " && ");
/* 236 */     result = StringUtils.replace(result, " or ", " || ");
/* 237 */     result = StringUtils.replace(result, " not ", " ! ");
/* 238 */     return result;
/*     */   }
/*     */ 
/*     */   public PointcutExpression getPointcutExpression()
/*     */   {
/* 246 */     checkReadyToMatch();
/* 247 */     return this.pointcutExpression;
/*     */   }
/*     */ 
/*     */   public boolean matches(Class<?> targetClass)
/*     */   {
/* 252 */     checkReadyToMatch();
/*     */     try {
/* 254 */       return this.pointcutExpression.couldMatchJoinPointsInType(targetClass);
/*     */     } catch (ReflectionWorld.ReflectionWorldException e) {
/* 256 */       logger.debug("PointcutExpression matching rejected target class", e);
/*     */       try
/*     */       {
/* 260 */         return getFallbackPointcutExpression(targetClass).couldMatchJoinPointsInType(targetClass);
/*     */       } catch (BCException ex) {
/* 262 */         logger.debug("Fallback PointcutExpression matching rejected target class", ex);
/*     */ 
/* 265 */         return false;
/*     */       }
/*     */     }
/*     */     catch (BCException ex) {
/* 269 */       logger.debug("PointcutExpression matching rejected target class", ex);
/* 270 */     }return false;
/*     */   }
/*     */ 
/*     */   public boolean matches(Method method, Class<?> targetClass, boolean beanHasIntroductions)
/*     */   {
/* 276 */     checkReadyToMatch();
/* 277 */     Method targetMethod = AopUtils.getMostSpecificMethod(method, targetClass);
/* 278 */     ShadowMatch shadowMatch = getShadowMatch(targetMethod, method);
/*     */ 
/* 283 */     if (shadowMatch.alwaysMatches()) {
/* 284 */       return true;
/*     */     }
/* 286 */     if (shadowMatch.neverMatches()) {
/* 287 */       return false;
/*     */     }
/*     */ 
/* 291 */     return (beanHasIntroductions) || (matchesIgnoringSubtypes(shadowMatch)) || (matchesTarget(shadowMatch, targetClass));
/*     */   }
/*     */ 
/*     */   public boolean matches(Method method, Class<?> targetClass)
/*     */   {
/* 297 */     return matches(method, targetClass, false);
/*     */   }
/*     */ 
/*     */   public boolean isRuntime()
/*     */   {
/* 302 */     checkReadyToMatch();
/* 303 */     return this.pointcutExpression.mayNeedDynamicTest();
/*     */   }
/*     */ 
/*     */   public boolean matches(Method method, Class<?> targetClass, Object[] args)
/*     */   {
/* 308 */     checkReadyToMatch();
/* 309 */     ShadowMatch shadowMatch = getShadowMatch(AopUtils.getMostSpecificMethod(method, targetClass), method);
/* 310 */     ShadowMatch originalShadowMatch = getShadowMatch(method, method);
/*     */ 
/* 314 */     ProxyMethodInvocation pmi = null;
/* 315 */     Object targetObject = null;
/* 316 */     Object thisObject = null;
/*     */     try {
/* 318 */       MethodInvocation mi = ExposeInvocationInterceptor.currentInvocation();
/* 319 */       targetObject = mi.getThis();
/* 320 */       if (!(mi instanceof ProxyMethodInvocation)) {
/* 321 */         throw new IllegalStateException(new StringBuilder().append("MethodInvocation is not a Spring ProxyMethodInvocation: ").append(mi).toString());
/*     */       }
/* 323 */       pmi = (ProxyMethodInvocation)mi;
/* 324 */       thisObject = pmi.getProxy();
/*     */     }
/*     */     catch (IllegalStateException ex)
/*     */     {
/* 329 */       logger.debug(new StringBuilder().append("Couldn't access current invocation - matching with limited context: ").append(ex).toString());
/*     */     }
/*     */ 
/* 332 */     JoinPointMatch joinPointMatch = shadowMatch.matchesJoinPoint(thisObject, targetObject, args);
/*     */ 
/* 342 */     if (pmi != null) {
/* 343 */       RuntimeTestWalker originalMethodResidueTest = getRuntimeTestWalker(originalShadowMatch);
/* 344 */       if (!originalMethodResidueTest.testThisInstanceOfResidue(thisObject.getClass())) {
/* 345 */         return false;
/*     */       }
/*     */     }
/* 348 */     if ((joinPointMatch.matches()) && (pmi != null)) {
/* 349 */       bindParameters(pmi, joinPointMatch);
/*     */     }
/* 351 */     return joinPointMatch.matches();
/*     */   }
/*     */ 
/*     */   protected String getCurrentProxiedBeanName()
/*     */   {
/* 356 */     return ProxyCreationContext.getCurrentProxiedBeanName();
/*     */   }
/*     */ 
/*     */   private PointcutExpression getFallbackPointcutExpression(Class<?> targetClass)
/*     */   {
/* 366 */     ClassLoader classLoader = targetClass.getClassLoader();
/* 367 */     return classLoader == null ? this.pointcutExpression : buildPointcutExpression(classLoader);
/*     */   }
/*     */ 
/*     */   private boolean matchesIgnoringSubtypes(ShadowMatch shadowMatch)
/*     */   {
/* 377 */     return !getRuntimeTestWalker(shadowMatch).testsSubtypeSensitiveVars();
/*     */   }
/*     */ 
/*     */   private boolean matchesTarget(ShadowMatch shadowMatch, Class<?> targetClass) {
/* 381 */     return getRuntimeTestWalker(shadowMatch).testTargetInstanceOfResidue(targetClass);
/*     */   }
/*     */ 
/*     */   private RuntimeTestWalker getRuntimeTestWalker(ShadowMatch shadowMatch) {
/* 385 */     if ((shadowMatch instanceof DefensiveShadowMatch)) {
/* 386 */       return new RuntimeTestWalker(((DefensiveShadowMatch)shadowMatch).primary);
/*     */     }
/* 388 */     return new RuntimeTestWalker(shadowMatch);
/*     */   }
/*     */ 
/*     */   private void bindParameters(ProxyMethodInvocation invocation, JoinPointMatch jpm)
/*     */   {
/* 398 */     invocation.setUserAttribute(getExpression(), jpm);
/*     */   }
/*     */ 
/*     */   private ShadowMatch getShadowMatch(Method targetMethod, Method originalMethod)
/*     */   {
/* 403 */     ShadowMatch shadowMatch = (ShadowMatch)this.shadowMatchCache.get(targetMethod);
/* 404 */     if (shadowMatch == null) {
/* 405 */       synchronized (this.shadowMatchCache)
/*     */       {
/* 407 */         Method methodToMatch = targetMethod;
/* 408 */         PointcutExpression fallbackPointcutExpression = null;
/* 409 */         shadowMatch = (ShadowMatch)this.shadowMatchCache.get(methodToMatch);
/* 410 */         if (shadowMatch == null) {
/*     */           try {
/* 412 */             shadowMatch = this.pointcutExpression.matchesMethodExecution(targetMethod);
/*     */           }
/*     */           catch (ReflectionWorld.ReflectionWorldException ex)
/*     */           {
/*     */             try
/*     */             {
/* 418 */               fallbackPointcutExpression = getFallbackPointcutExpression(methodToMatch.getDeclaringClass());
/* 419 */               shadowMatch = fallbackPointcutExpression.matchesMethodExecution(methodToMatch);
/*     */             } catch (ReflectionWorld.ReflectionWorldException e) {
/* 421 */               if (targetMethod == originalMethod)
/* 422 */                 shadowMatch = new ShadowMatchImpl(org.aspectj.util.FuzzyBoolean.NO, null, null, null);
/*     */               else {
/*     */                 try
/*     */                 {
/* 426 */                   shadowMatch = this.pointcutExpression.matchesMethodExecution(originalMethod);
/*     */                 }
/*     */                 catch (ReflectionWorld.ReflectionWorldException ex2)
/*     */                 {
/* 431 */                   methodToMatch = originalMethod;
/* 432 */                   fallbackPointcutExpression = getFallbackPointcutExpression(methodToMatch.getDeclaringClass());
/*     */                   try {
/* 434 */                     shadowMatch = fallbackPointcutExpression.matchesMethodExecution(methodToMatch);
/*     */                   } catch (ReflectionWorld.ReflectionWorldException e2) {
/* 436 */                     shadowMatch = new ShadowMatchImpl(org.aspectj.util.FuzzyBoolean.NO, null, null, null);
/*     */                   }
/*     */                 }
/*     */               }
/*     */             }
/*     */           }
/* 442 */           if ((shadowMatch.maybeMatches()) && (fallbackPointcutExpression != null))
/*     */           {
/* 444 */             shadowMatch = new DefensiveShadowMatch(shadowMatch, fallbackPointcutExpression
/* 444 */               .matchesMethodExecution(methodToMatch));
/*     */           }
/*     */ 
/* 446 */           this.shadowMatchCache.put(targetMethod, shadowMatch);
/*     */         }
/*     */       }
/*     */     }
/* 450 */     return shadowMatch;
/*     */   }
/*     */ 
/*     */   public boolean equals(Object other)
/*     */   {
/* 456 */     if (this == other) {
/* 457 */       return true;
/*     */     }
/* 459 */     if (!(other instanceof AspectJExpressionPointcut)) {
/* 460 */       return false;
/*     */     }
/* 462 */     AspectJExpressionPointcut otherPc = (AspectJExpressionPointcut)other;
/*     */ 
/* 466 */     return (ObjectUtils.nullSafeEquals(getExpression(), otherPc.getExpression())) && 
/* 464 */       (ObjectUtils.nullSafeEquals(this.pointcutDeclarationScope, otherPc.pointcutDeclarationScope)) && 
/* 465 */       (ObjectUtils.nullSafeEquals(this.pointcutParameterNames, otherPc.pointcutParameterNames)) && 
/* 466 */       (ObjectUtils.nullSafeEquals(this.pointcutParameterTypes, otherPc.pointcutParameterTypes));
/*     */   }
/*     */ 
/*     */   public int hashCode()
/*     */   {
/* 471 */     int hashCode = ObjectUtils.nullSafeHashCode(getExpression());
/* 472 */     hashCode = 31 * hashCode + ObjectUtils.nullSafeHashCode(this.pointcutDeclarationScope);
/* 473 */     hashCode = 31 * hashCode + ObjectUtils.nullSafeHashCode(this.pointcutParameterNames);
/* 474 */     hashCode = 31 * hashCode + ObjectUtils.nullSafeHashCode(this.pointcutParameterTypes);
/* 475 */     return hashCode;
/*     */   }
/*     */ 
/*     */   public String toString()
/*     */   {
/* 480 */     StringBuilder sb = new StringBuilder();
/* 481 */     sb.append("AspectJExpressionPointcut: ");
/* 482 */     if ((this.pointcutParameterNames != null) && (this.pointcutParameterTypes != null)) {
/* 483 */       sb.append("(");
/* 484 */       for (int i = 0; i < this.pointcutParameterTypes.length; i++) {
/* 485 */         sb.append(this.pointcutParameterTypes[i].getName());
/* 486 */         sb.append(" ");
/* 487 */         sb.append(this.pointcutParameterNames[i]);
/* 488 */         if (i + 1 < this.pointcutParameterTypes.length) {
/* 489 */           sb.append(", ");
/*     */         }
/*     */       }
/* 492 */       sb.append(")");
/*     */     }
/* 494 */     sb.append(" ");
/* 495 */     if (getExpression() != null) {
/* 496 */       sb.append(getExpression());
/*     */     }
/*     */     else {
/* 499 */       sb.append("<pointcut expression not set>");
/*     */     }
/* 501 */     return sb.toString();
/*     */   }
/*     */ 
/*     */   private void readObject(ObjectInputStream ois)
/*     */     throws IOException, ClassNotFoundException
/*     */   {
/* 616 */     ois.defaultReadObject();
/*     */ 
/* 620 */     this.shadowMatchCache = new ConcurrentHashMap(32);
/*     */   }
/*     */ 
/*     */   static
/*     */   {
/*  86 */     SUPPORTED_PRIMITIVES.add(PointcutPrimitive.EXECUTION);
/*  87 */     SUPPORTED_PRIMITIVES.add(PointcutPrimitive.ARGS);
/*  88 */     SUPPORTED_PRIMITIVES.add(PointcutPrimitive.REFERENCE);
/*  89 */     SUPPORTED_PRIMITIVES.add(PointcutPrimitive.THIS);
/*  90 */     SUPPORTED_PRIMITIVES.add(PointcutPrimitive.TARGET);
/*  91 */     SUPPORTED_PRIMITIVES.add(PointcutPrimitive.WITHIN);
/*  92 */     SUPPORTED_PRIMITIVES.add(PointcutPrimitive.AT_ANNOTATION);
/*  93 */     SUPPORTED_PRIMITIVES.add(PointcutPrimitive.AT_WITHIN);
/*  94 */     SUPPORTED_PRIMITIVES.add(PointcutPrimitive.AT_ARGS);
/*  95 */     SUPPORTED_PRIMITIVES.add(PointcutPrimitive.AT_TARGET);
/*     */   }
/*     */ 
/*     */   private static class DefensiveShadowMatch
/*     */     implements ShadowMatch
/*     */   {
/*     */     private final ShadowMatch primary;
/*     */     private final ShadowMatch other;
/*     */ 
/*     */     public DefensiveShadowMatch(ShadowMatch primary, ShadowMatch other)
/*     */     {
/* 629 */       this.primary = primary;
/* 630 */       this.other = other;
/*     */     }
/*     */ 
/*     */     public boolean alwaysMatches()
/*     */     {
/* 635 */       return this.primary.alwaysMatches();
/*     */     }
/*     */ 
/*     */     public boolean maybeMatches()
/*     */     {
/* 640 */       return this.primary.maybeMatches();
/*     */     }
/*     */ 
/*     */     public boolean neverMatches()
/*     */     {
/* 645 */       return this.primary.neverMatches();
/*     */     }
/*     */ 
/*     */     public JoinPointMatch matchesJoinPoint(Object thisObject, Object targetObject, Object[] args)
/*     */     {
/*     */       try
/*     */       {
/* 652 */         return this.primary.matchesJoinPoint(thisObject, targetObject, args); } catch (ReflectionWorld.ReflectionWorldException e) {
/*     */       }
/* 654 */       return this.other.matchesJoinPoint(thisObject, targetObject, args);
/*     */     }
/*     */ 
/*     */     public void setMatchingContext(MatchingContext aMatchContext)
/*     */     {
/* 660 */       this.primary.setMatchingContext(aMatchContext);
/* 661 */       this.other.setMatchingContext(aMatchContext);
/*     */     }
/*     */   }
/*     */ 
/*     */   private class BeanNameContextMatcher
/*     */     implements ContextBasedMatcher
/*     */   {
/*     */     private final NamePattern expressionPattern;
/*     */ 
/*     */     public BeanNameContextMatcher(String expression)
/*     */     {
/* 541 */       this.expressionPattern = new NamePattern(expression);
/*     */     }
/*     */ 
/*     */     @Deprecated
/*     */     public boolean couldMatchJoinPointsInType(Class someClass)
/*     */     {
/* 548 */       return contextMatch(someClass) == org.aspectj.weaver.tools.FuzzyBoolean.YES;
/*     */     }
/*     */ 
/*     */     @Deprecated
/*     */     public boolean couldMatchJoinPointsInType(Class someClass, MatchingContext context)
/*     */     {
/* 555 */       return contextMatch(someClass) == org.aspectj.weaver.tools.FuzzyBoolean.YES;
/*     */     }
/*     */ 
/*     */     public boolean matchesDynamically(MatchingContext context)
/*     */     {
/* 560 */       return true;
/*     */     }
/*     */ 
/*     */     public org.aspectj.weaver.tools.FuzzyBoolean matchesStatically(MatchingContext context)
/*     */     {
/* 565 */       return contextMatch(null);
/*     */     }
/*     */ 
/*     */     public boolean mayNeedDynamicTest()
/*     */     {
/* 570 */       return false;
/*     */     }
/*     */ 
/*     */     private org.aspectj.weaver.tools.FuzzyBoolean contextMatch(Class<?> targetType) {
/* 574 */       String advisedBeanName = AspectJExpressionPointcut.this.getCurrentProxiedBeanName();
/* 575 */       if (advisedBeanName == null)
/*     */       {
/* 577 */         return org.aspectj.weaver.tools.FuzzyBoolean.MAYBE;
/*     */       }
/* 579 */       if (BeanFactoryUtils.isGeneratedBeanName(advisedBeanName)) {
/* 580 */         return org.aspectj.weaver.tools.FuzzyBoolean.NO;
/*     */       }
/* 582 */       if (targetType != null) {
/* 583 */         boolean isFactory = FactoryBean.class.isAssignableFrom(targetType);
/* 584 */         return org.aspectj.weaver.tools.FuzzyBoolean.fromBoolean(
/* 585 */           matchesBeanName(isFactory ? "&" + advisedBeanName : advisedBeanName));
/*     */       }
/*     */ 
/* 588 */       return org.aspectj.weaver.tools.FuzzyBoolean.fromBoolean((matchesBeanName(advisedBeanName)) || 
/* 589 */         (matchesBeanName("&" + advisedBeanName)));
/*     */     }
/*     */ 
/*     */     private boolean matchesBeanName(String advisedBeanName)
/*     */     {
/* 594 */       if (this.expressionPattern.matches(advisedBeanName)) {
/* 595 */         return true;
/*     */       }
/* 597 */       if (AspectJExpressionPointcut.this.beanFactory != null) {
/* 598 */         String[] aliases = AspectJExpressionPointcut.this.beanFactory.getAliases(advisedBeanName);
/* 599 */         for (String alias : aliases) {
/* 600 */           if (this.expressionPattern.matches(alias)) {
/* 601 */             return true;
/*     */           }
/*     */         }
/*     */       }
/* 605 */       return false;
/*     */     }
/*     */   }
/*     */ 
/*     */   private class BeanNamePointcutDesignatorHandler
/*     */     implements PointcutDesignatorHandler
/*     */   {
/*     */     private static final String BEAN_DESIGNATOR_NAME = "bean";
/*     */ 
/*     */     private BeanNamePointcutDesignatorHandler()
/*     */     {
/*     */     }
/*     */ 
/*     */     public String getDesignatorName()
/*     */     {
/* 519 */       return "bean";
/*     */     }
/*     */ 
/*     */     public ContextBasedMatcher parse(String expression)
/*     */     {
/* 524 */       return new AspectJExpressionPointcut.BeanNameContextMatcher(AspectJExpressionPointcut.this, expression);
/*     */     }
/*     */   }
/*     */ }

/* Location:           D:\Git\study\spring\WebRoot\WEB-INF\lib\spring-aop-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.aop.aspectj.AspectJExpressionPointcut
 * JD-Core Version:    0.6.2
 */