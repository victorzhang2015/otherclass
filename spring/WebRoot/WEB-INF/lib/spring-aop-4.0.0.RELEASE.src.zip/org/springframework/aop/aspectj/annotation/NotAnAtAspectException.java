/*    */ package org.springframework.aop.aspectj.annotation;
/*    */ 
/*    */ import org.springframework.aop.framework.AopConfigException;
/*    */ 
/*    */ public class NotAnAtAspectException extends AopConfigException
/*    */ {
/*    */   private Class<?> nonAspectClass;
/*    */ 
/*    */   public NotAnAtAspectException(Class<?> nonAspectClass)
/*    */   {
/* 40 */     super(nonAspectClass.getName() + " is not an @AspectJ aspect");
/* 41 */     this.nonAspectClass = nonAspectClass;
/*    */   }
/*    */ 
/*    */   public Class<?> getNonAspectClass()
/*    */   {
/* 48 */     return this.nonAspectClass;
/*    */   }
/*    */ }

/* Location:           D:\Git\study\spring\WebRoot\WEB-INF\lib\spring-aop-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.aop.aspectj.annotation.NotAnAtAspectException
 * JD-Core Version:    0.6.2
 */