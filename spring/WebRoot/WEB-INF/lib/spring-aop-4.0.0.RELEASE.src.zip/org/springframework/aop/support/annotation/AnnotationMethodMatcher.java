/*    */ package org.springframework.aop.support.annotation;
/*    */ 
/*    */ import java.lang.annotation.Annotation;
/*    */ import java.lang.reflect.Method;
/*    */ import org.springframework.aop.support.AopUtils;
/*    */ import org.springframework.aop.support.StaticMethodMatcher;
/*    */ import org.springframework.util.Assert;
/*    */ 
/*    */ public class AnnotationMethodMatcher extends StaticMethodMatcher
/*    */ {
/*    */   private final Class<? extends Annotation> annotationType;
/*    */ 
/*    */   public AnnotationMethodMatcher(Class<? extends Annotation> annotationType)
/*    */   {
/* 45 */     Assert.notNull(annotationType, "Annotation type must not be null");
/* 46 */     this.annotationType = annotationType;
/*    */   }
/*    */ 
/*    */   public boolean matches(Method method, Class<?> targetClass)
/*    */   {
/* 52 */     if (method.isAnnotationPresent(this.annotationType)) {
/* 53 */       return true;
/*    */     }
/*    */ 
/* 56 */     Method specificMethod = AopUtils.getMostSpecificMethod(method, targetClass);
/* 57 */     return (specificMethod != method) && (specificMethod.isAnnotationPresent(this.annotationType));
/*    */   }
/*    */ 
/*    */   public boolean equals(Object other)
/*    */   {
/* 62 */     if (this == other) {
/* 63 */       return true;
/*    */     }
/* 65 */     if (!(other instanceof AnnotationMethodMatcher)) {
/* 66 */       return false;
/*    */     }
/* 68 */     AnnotationMethodMatcher otherMm = (AnnotationMethodMatcher)other;
/* 69 */     return this.annotationType.equals(otherMm.annotationType);
/*    */   }
/*    */ 
/*    */   public int hashCode()
/*    */   {
/* 74 */     return this.annotationType.hashCode();
/*    */   }
/*    */ }

/* Location:           D:\Git\study\spring\WebRoot\WEB-INF\lib\spring-aop-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.aop.support.annotation.AnnotationMethodMatcher
 * JD-Core Version:    0.6.2
 */