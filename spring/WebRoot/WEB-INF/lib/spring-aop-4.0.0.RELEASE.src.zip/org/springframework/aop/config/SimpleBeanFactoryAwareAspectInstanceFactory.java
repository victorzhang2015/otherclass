/*    */ package org.springframework.aop.config;
/*    */ 
/*    */ import org.springframework.aop.aspectj.AspectInstanceFactory;
/*    */ import org.springframework.beans.factory.BeanFactory;
/*    */ import org.springframework.beans.factory.BeanFactoryAware;
/*    */ import org.springframework.beans.factory.config.ConfigurableBeanFactory;
/*    */ import org.springframework.core.Ordered;
/*    */ import org.springframework.util.ClassUtils;
/*    */ import org.springframework.util.StringUtils;
/*    */ 
/*    */ public class SimpleBeanFactoryAwareAspectInstanceFactory
/*    */   implements AspectInstanceFactory, BeanFactoryAware
/*    */ {
/*    */   private String aspectBeanName;
/*    */   private BeanFactory beanFactory;
/*    */ 
/*    */   public void setAspectBeanName(String aspectBeanName)
/*    */   {
/* 47 */     this.aspectBeanName = aspectBeanName;
/*    */   }
/*    */ 
/*    */   public void setBeanFactory(BeanFactory beanFactory)
/*    */   {
/* 52 */     this.beanFactory = beanFactory;
/* 53 */     if (!StringUtils.hasText(this.aspectBeanName))
/* 54 */       throw new IllegalArgumentException("'aspectBeanName' is required");
/*    */   }
/*    */ 
/*    */   public Object getAspectInstance()
/*    */   {
/* 65 */     return this.beanFactory.getBean(this.aspectBeanName);
/*    */   }
/*    */ 
/*    */   public ClassLoader getAspectClassLoader()
/*    */   {
/* 70 */     if ((this.beanFactory instanceof ConfigurableBeanFactory)) {
/* 71 */       return ((ConfigurableBeanFactory)this.beanFactory).getBeanClassLoader();
/*    */     }
/*    */ 
/* 74 */     return ClassUtils.getDefaultClassLoader();
/*    */   }
/*    */ 
/*    */   public int getOrder()
/*    */   {
/* 80 */     if ((this.beanFactory.isSingleton(this.aspectBeanName)) && 
/* 81 */       (this.beanFactory
/* 81 */       .isTypeMatch(this.aspectBeanName, Ordered.class)))
/*    */     {
/* 82 */       return ((Ordered)this.beanFactory.getBean(this.aspectBeanName)).getOrder();
/*    */     }
/* 84 */     return 2147483647;
/*    */   }
/*    */ }

/* Location:           D:\Git\study\spring\WebRoot\WEB-INF\lib\spring-aop-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.aop.config.SimpleBeanFactoryAwareAspectInstanceFactory
 * JD-Core Version:    0.6.2
 */