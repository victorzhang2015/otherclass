/*    */ package org.springframework.aop.config;
/*    */ 
/*    */ import org.springframework.beans.factory.xml.NamespaceHandlerSupport;
/*    */ 
/*    */ public class AopNamespaceHandler extends NamespaceHandlerSupport
/*    */ {
/*    */   public void init()
/*    */   {
/* 65 */     registerBeanDefinitionParser("config", new ConfigBeanDefinitionParser());
/* 66 */     registerBeanDefinitionParser("aspectj-autoproxy", new AspectJAutoProxyBeanDefinitionParser());
/* 67 */     registerBeanDefinitionDecorator("scoped-proxy", new ScopedProxyBeanDefinitionDecorator());
/*    */ 
/* 70 */     registerBeanDefinitionParser("spring-configured", new SpringConfiguredBeanDefinitionParser());
/*    */   }
/*    */ }

/* Location:           D:\Git\study\spring\WebRoot\WEB-INF\lib\spring-aop-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.aop.config.AopNamespaceHandler
 * JD-Core Version:    0.6.2
 */