/*    */ package org.springframework.aop.aspectj;
/*    */ 
/*    */ import org.springframework.core.Ordered;
/*    */ import org.springframework.util.Assert;
/*    */ 
/*    */ public class SingletonAspectInstanceFactory
/*    */   implements AspectInstanceFactory
/*    */ {
/*    */   private final Object aspectInstance;
/*    */ 
/*    */   public SingletonAspectInstanceFactory(Object aspectInstance)
/*    */   {
/* 42 */     Assert.notNull(aspectInstance, "Aspect instance must not be null");
/* 43 */     this.aspectInstance = aspectInstance;
/*    */   }
/*    */ 
/*    */   public final Object getAspectInstance()
/*    */   {
/* 49 */     return this.aspectInstance;
/*    */   }
/*    */ 
/*    */   public ClassLoader getAspectClassLoader()
/*    */   {
/* 54 */     return this.aspectInstance.getClass().getClassLoader();
/*    */   }
/*    */ 
/*    */   public int getOrder()
/*    */   {
/* 67 */     if ((this.aspectInstance instanceof Ordered)) {
/* 68 */       return ((Ordered)this.aspectInstance).getOrder();
/*    */     }
/* 70 */     return getOrderForAspectClass(this.aspectInstance.getClass());
/*    */   }
/*    */ 
/*    */   protected int getOrderForAspectClass(Class<?> aspectClass)
/*    */   {
/* 81 */     return 2147483647;
/*    */   }
/*    */ }

/* Location:           D:\Git\study\spring\WebRoot\WEB-INF\lib\spring-aop-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.aop.aspectj.SingletonAspectInstanceFactory
 * JD-Core Version:    0.6.2
 */