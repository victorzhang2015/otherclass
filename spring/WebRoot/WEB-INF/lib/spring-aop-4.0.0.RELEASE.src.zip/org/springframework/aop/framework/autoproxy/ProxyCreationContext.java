/*    */ package org.springframework.aop.framework.autoproxy;
/*    */ 
/*    */ import org.springframework.core.NamedThreadLocal;
/*    */ 
/*    */ public class ProxyCreationContext
/*    */ {
/* 32 */   private static final ThreadLocal<String> currentProxiedBeanName = new NamedThreadLocal("Name of currently proxied bean");
/*    */ 
/*    */   public static String getCurrentProxiedBeanName()
/*    */   {
/* 41 */     return (String)currentProxiedBeanName.get();
/*    */   }
/*    */ 
/*    */   static void setCurrentProxiedBeanName(String beanName)
/*    */   {
/* 49 */     if (beanName != null) {
/* 50 */       currentProxiedBeanName.set(beanName);
/*    */     }
/*    */     else
/* 53 */       currentProxiedBeanName.remove();
/*    */   }
/*    */ }

/* Location:           D:\Git\study\spring\WebRoot\WEB-INF\lib\spring-aop-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.aop.framework.autoproxy.ProxyCreationContext
 * JD-Core Version:    0.6.2
 */