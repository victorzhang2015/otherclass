package org.springframework.aop;

public abstract interface RawTargetAccess
{
}

/* Location:           D:\Git\study\spring\WebRoot\WEB-INF\lib\spring-aop-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.aop.RawTargetAccess
 * JD-Core Version:    0.6.2
 */