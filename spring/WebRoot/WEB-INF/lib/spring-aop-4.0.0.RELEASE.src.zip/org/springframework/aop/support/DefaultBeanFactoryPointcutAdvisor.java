/*    */ package org.springframework.aop.support;
/*    */ 
/*    */ import org.springframework.aop.Pointcut;
/*    */ 
/*    */ public class DefaultBeanFactoryPointcutAdvisor extends AbstractBeanFactoryPointcutAdvisor
/*    */ {
/* 38 */   private Pointcut pointcut = Pointcut.TRUE;
/*    */ 
/*    */   public void setPointcut(Pointcut pointcut)
/*    */   {
/* 47 */     this.pointcut = (pointcut != null ? pointcut : Pointcut.TRUE);
/*    */   }
/*    */ 
/*    */   public Pointcut getPointcut()
/*    */   {
/* 52 */     return this.pointcut;
/*    */   }
/*    */ 
/*    */   public String toString()
/*    */   {
/* 58 */     return getClass().getName() + ": pointcut [" + getPointcut() + "]; advice bean '" + getAdviceBeanName() + "'";
/*    */   }
/*    */ }

/* Location:           D:\Git\study\spring\WebRoot\WEB-INF\lib\spring-aop-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.aop.support.DefaultBeanFactoryPointcutAdvisor
 * JD-Core Version:    0.6.2
 */