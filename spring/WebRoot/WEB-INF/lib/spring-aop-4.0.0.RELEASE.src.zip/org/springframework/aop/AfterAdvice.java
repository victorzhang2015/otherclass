package org.springframework.aop;

import org.aopalliance.aop.Advice;

public abstract interface AfterAdvice extends Advice
{
}

/* Location:           D:\Git\study\spring\WebRoot\WEB-INF\lib\spring-aop-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.aop.AfterAdvice
 * JD-Core Version:    0.6.2
 */