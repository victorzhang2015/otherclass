/*    */ package org.springframework.aop;
/*    */ 
/*    */ public abstract interface Pointcut
/*    */ {
/* 51 */   public static final Pointcut TRUE = TruePointcut.INSTANCE;
/*    */ 
/*    */   public abstract ClassFilter getClassFilter();
/*    */ 
/*    */   public abstract MethodMatcher getMethodMatcher();
/*    */ }

/* Location:           D:\Git\study\spring\WebRoot\WEB-INF\lib\spring-aop-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.aop.Pointcut
 * JD-Core Version:    0.6.2
 */