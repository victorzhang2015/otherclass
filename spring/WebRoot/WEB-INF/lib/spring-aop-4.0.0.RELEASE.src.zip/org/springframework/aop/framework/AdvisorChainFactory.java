package org.springframework.aop.framework;

import java.lang.reflect.Method;
import java.util.List;

public abstract interface AdvisorChainFactory
{
  public abstract List<Object> getInterceptorsAndDynamicInterceptionAdvice(Advised paramAdvised, Method paramMethod, Class<?> paramClass);
}

/* Location:           D:\Git\study\spring\WebRoot\WEB-INF\lib\spring-aop-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.aop.framework.AdvisorChainFactory
 * JD-Core Version:    0.6.2
 */