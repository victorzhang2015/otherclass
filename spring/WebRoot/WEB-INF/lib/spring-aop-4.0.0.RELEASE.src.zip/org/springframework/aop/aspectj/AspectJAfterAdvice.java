/*    */ package org.springframework.aop.aspectj;
/*    */ 
/*    */ import java.lang.reflect.Method;
/*    */ import org.aopalliance.intercept.MethodInterceptor;
/*    */ import org.aopalliance.intercept.MethodInvocation;
/*    */ import org.springframework.aop.AfterAdvice;
/*    */ 
/*    */ public class AspectJAfterAdvice extends AbstractAspectJAdvice
/*    */   implements MethodInterceptor, AfterAdvice
/*    */ {
/*    */   public AspectJAfterAdvice(Method aspectJBeforeAdviceMethod, AspectJExpressionPointcut pointcut, AspectInstanceFactory aif)
/*    */   {
/* 37 */     super(aspectJBeforeAdviceMethod, pointcut, aif);
/*    */   }
/*    */ 
/*    */   public Object invoke(MethodInvocation mi) throws Throwable
/*    */   {
/*    */     try {
/* 43 */       return mi.proceed();
/*    */     }
/*    */     finally {
/* 46 */       invokeAdviceMethod(getJoinPointMatch(), null, null);
/*    */     }
/*    */   }
/*    */ 
/*    */   public boolean isBeforeAdvice()
/*    */   {
/* 52 */     return false;
/*    */   }
/*    */ 
/*    */   public boolean isAfterAdvice()
/*    */   {
/* 57 */     return true;
/*    */   }
/*    */ }

/* Location:           D:\Git\study\spring\WebRoot\WEB-INF\lib\spring-aop-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.aop.aspectj.AspectJAfterAdvice
 * JD-Core Version:    0.6.2
 */