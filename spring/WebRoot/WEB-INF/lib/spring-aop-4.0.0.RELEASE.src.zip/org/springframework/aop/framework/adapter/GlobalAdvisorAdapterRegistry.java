/*    */ package org.springframework.aop.framework.adapter;
/*    */ 
/*    */ public abstract class GlobalAdvisorAdapterRegistry
/*    */ {
/* 32 */   private static AdvisorAdapterRegistry instance = new DefaultAdvisorAdapterRegistry();
/*    */ 
/*    */   public static AdvisorAdapterRegistry getInstance()
/*    */   {
/* 38 */     return instance;
/*    */   }
/*    */ 
/*    */   static void reset()
/*    */   {
/* 47 */     instance = new DefaultAdvisorAdapterRegistry();
/*    */   }
/*    */ }

/* Location:           D:\Git\study\spring\WebRoot\WEB-INF\lib\spring-aop-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.aop.framework.adapter.GlobalAdvisorAdapterRegistry
 * JD-Core Version:    0.6.2
 */