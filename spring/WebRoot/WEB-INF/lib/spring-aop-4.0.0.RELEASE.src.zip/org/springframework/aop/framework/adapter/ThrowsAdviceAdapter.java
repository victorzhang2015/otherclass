/*    */ package org.springframework.aop.framework.adapter;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ import org.aopalliance.aop.Advice;
/*    */ import org.aopalliance.intercept.MethodInterceptor;
/*    */ import org.springframework.aop.Advisor;
/*    */ import org.springframework.aop.ThrowsAdvice;
/*    */ 
/*    */ class ThrowsAdviceAdapter
/*    */   implements AdvisorAdapter, Serializable
/*    */ {
/*    */   public boolean supportsAdvice(Advice advice)
/*    */   {
/* 39 */     return advice instanceof ThrowsAdvice;
/*    */   }
/*    */ 
/*    */   public MethodInterceptor getInterceptor(Advisor advisor)
/*    */   {
/* 44 */     return new ThrowsAdviceInterceptor(advisor.getAdvice());
/*    */   }
/*    */ }

/* Location:           D:\Git\study\spring\WebRoot\WEB-INF\lib\spring-aop-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.aop.framework.adapter.ThrowsAdviceAdapter
 * JD-Core Version:    0.6.2
 */