/*    */ package org.springframework.aop.aspectj.annotation;
/*    */ 
/*    */ import org.springframework.aop.aspectj.SingletonAspectInstanceFactory;
/*    */ import org.springframework.core.annotation.AnnotationUtils;
/*    */ import org.springframework.core.annotation.Order;
/*    */ 
/*    */ public class SingletonMetadataAwareAspectInstanceFactory extends SingletonAspectInstanceFactory
/*    */   implements MetadataAwareAspectInstanceFactory
/*    */ {
/*    */   private final AspectMetadata metadata;
/*    */ 
/*    */   public SingletonMetadataAwareAspectInstanceFactory(Object aspectInstance, String aspectName)
/*    */   {
/* 46 */     super(aspectInstance);
/* 47 */     this.metadata = new AspectMetadata(aspectInstance.getClass(), aspectName);
/*    */   }
/*    */ 
/*    */   public final AspectMetadata getAspectMetadata()
/*    */   {
/* 53 */     return this.metadata;
/*    */   }
/*    */ 
/*    */   protected int getOrderForAspectClass(Class<?> aspectClass)
/*    */   {
/* 64 */     Order order = (Order)AnnotationUtils.findAnnotation(aspectClass, Order.class);
/* 65 */     if (order != null) {
/* 66 */       return order.value();
/*    */     }
/* 68 */     return 2147483647;
/*    */   }
/*    */ }

/* Location:           D:\Git\study\spring\WebRoot\WEB-INF\lib\spring-aop-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.aop.aspectj.annotation.SingletonMetadataAwareAspectInstanceFactory
 * JD-Core Version:    0.6.2
 */