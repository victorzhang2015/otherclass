/*     */ package org.springframework.aop.aspectj;
/*     */ 
/*     */ import java.lang.reflect.Method;
/*     */ import java.lang.reflect.Type;
/*     */ import org.springframework.aop.AfterAdvice;
/*     */ import org.springframework.aop.AfterReturningAdvice;
/*     */ import org.springframework.util.ClassUtils;
/*     */ import org.springframework.util.TypeUtils;
/*     */ 
/*     */ public class AspectJAfterReturningAdvice extends AbstractAspectJAdvice
/*     */   implements AfterReturningAdvice, AfterAdvice
/*     */ {
/*     */   public AspectJAfterReturningAdvice(Method aspectJBeforeAdviceMethod, AspectJExpressionPointcut pointcut, AspectInstanceFactory aif)
/*     */   {
/*  40 */     super(aspectJBeforeAdviceMethod, pointcut, aif);
/*     */   }
/*     */ 
/*     */   public boolean isBeforeAdvice()
/*     */   {
/*  45 */     return false;
/*     */   }
/*     */ 
/*     */   public boolean isAfterAdvice()
/*     */   {
/*  50 */     return true;
/*     */   }
/*     */ 
/*     */   public void setReturningName(String name)
/*     */   {
/*  55 */     setReturningNameNoCheck(name);
/*     */   }
/*     */ 
/*     */   public void afterReturning(Object returnValue, Method method, Object[] args, Object target) throws Throwable
/*     */   {
/*  60 */     if (shouldInvokeOnReturnValueOf(method, returnValue))
/*  61 */       invokeAdviceMethod(getJoinPointMatch(), returnValue, null);
/*     */   }
/*     */ 
/*     */   private boolean shouldInvokeOnReturnValueOf(Method method, Object returnValue)
/*     */   {
/*  74 */     Class type = getDiscoveredReturningType();
/*  75 */     Type genericType = getDiscoveredReturningGenericType();
/*     */ 
/*  79 */     return (matchesReturnValue(type, method, returnValue)) && ((genericType == null) || (genericType == type) || 
/*  79 */       (TypeUtils.isAssignable(genericType, method
/*  79 */       .getGenericReturnType())));
/*     */   }
/*     */ 
/*     */   private boolean matchesReturnValue(Class<?> type, Method method, Object returnValue)
/*     */   {
/*  93 */     if (returnValue != null) {
/*  94 */       return ClassUtils.isAssignableValue(type, returnValue);
/*     */     }
/*  96 */     if ((type.equals(Object.class)) && (method.getReturnType().equals(Void.TYPE))) {
/*  97 */       return true;
/*     */     }
/*     */ 
/* 100 */     return ClassUtils.isAssignable(type, method.getReturnType());
/*     */   }
/*     */ }

/* Location:           D:\Git\study\spring\WebRoot\WEB-INF\lib\spring-aop-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.aop.aspectj.AspectJAfterReturningAdvice
 * JD-Core Version:    0.6.2
 */