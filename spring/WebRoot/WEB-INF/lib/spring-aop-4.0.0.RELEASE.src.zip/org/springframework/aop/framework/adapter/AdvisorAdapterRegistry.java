package org.springframework.aop.framework.adapter;

import org.aopalliance.intercept.MethodInterceptor;
import org.springframework.aop.Advisor;

public abstract interface AdvisorAdapterRegistry
{
  public abstract Advisor wrap(Object paramObject)
    throws UnknownAdviceTypeException;

  public abstract MethodInterceptor[] getInterceptors(Advisor paramAdvisor)
    throws UnknownAdviceTypeException;

  public abstract void registerAdvisorAdapter(AdvisorAdapter paramAdvisorAdapter);
}

/* Location:           D:\Git\study\spring\WebRoot\WEB-INF\lib\spring-aop-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.aop.framework.adapter.AdvisorAdapterRegistry
 * JD-Core Version:    0.6.2
 */