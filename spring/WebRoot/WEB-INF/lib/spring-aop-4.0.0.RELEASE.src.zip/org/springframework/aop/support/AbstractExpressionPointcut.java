/*    */ package org.springframework.aop.support;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ 
/*    */ public abstract class AbstractExpressionPointcut
/*    */   implements ExpressionPointcut, Serializable
/*    */ {
/*    */   private String location;
/*    */   private String expression;
/*    */ 
/*    */   public void setLocation(String location)
/*    */   {
/* 43 */     this.location = location;
/*    */   }
/*    */ 
/*    */   public String getLocation()
/*    */   {
/* 53 */     return this.location;
/*    */   }
/*    */ 
/*    */   public void setExpression(String expression) {
/* 57 */     this.expression = expression;
/*    */     try {
/* 59 */       onSetExpression(expression);
/*    */     }
/*    */     catch (IllegalArgumentException ex)
/*    */     {
/* 63 */       if (this.location != null) {
/* 64 */         throw new IllegalArgumentException("Invalid expression at location [" + this.location + "]: " + ex);
/*    */       }
/*    */ 
/* 67 */       throw ex;
/*    */     }
/*    */   }
/*    */ 
/*    */   protected void onSetExpression(String expression)
/*    */     throws IllegalArgumentException
/*    */   {
/*    */   }
/*    */ 
/*    */   public String getExpression()
/*    */   {
/* 88 */     return this.expression;
/*    */   }
/*    */ }

/* Location:           D:\Git\study\spring\WebRoot\WEB-INF\lib\spring-aop-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.aop.support.AbstractExpressionPointcut
 * JD-Core Version:    0.6.2
 */