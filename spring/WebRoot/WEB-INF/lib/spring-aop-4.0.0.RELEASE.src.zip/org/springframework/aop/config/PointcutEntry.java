/*    */ package org.springframework.aop.config;
/*    */ 
/*    */ import org.springframework.beans.factory.parsing.ParseState.Entry;
/*    */ 
/*    */ public class PointcutEntry
/*    */   implements ParseState.Entry
/*    */ {
/*    */   private final String name;
/*    */ 
/*    */   public PointcutEntry(String name)
/*    */   {
/* 36 */     this.name = name;
/*    */   }
/*    */ 
/*    */   public String toString()
/*    */   {
/* 41 */     return "Pointcut '" + this.name + "'";
/*    */   }
/*    */ }

/* Location:           D:\Git\study\spring\WebRoot\WEB-INF\lib\spring-aop-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.aop.config.PointcutEntry
 * JD-Core Version:    0.6.2
 */