/*     */ package org.springframework.aop.framework;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import java.lang.reflect.Method;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.List;
/*     */ import org.aopalliance.intercept.Interceptor;
/*     */ import org.aopalliance.intercept.MethodInterceptor;
/*     */ import org.springframework.aop.Advisor;
/*     */ import org.springframework.aop.ClassFilter;
/*     */ import org.springframework.aop.IntroductionAdvisor;
/*     */ import org.springframework.aop.MethodMatcher;
/*     */ import org.springframework.aop.Pointcut;
/*     */ import org.springframework.aop.PointcutAdvisor;
/*     */ import org.springframework.aop.framework.adapter.AdvisorAdapterRegistry;
/*     */ import org.springframework.aop.framework.adapter.GlobalAdvisorAdapterRegistry;
/*     */ import org.springframework.aop.support.MethodMatchers;
/*     */ 
/*     */ public class DefaultAdvisorChainFactory
/*     */   implements AdvisorChainFactory, Serializable
/*     */ {
/*     */   public List<Object> getInterceptorsAndDynamicInterceptionAdvice(Advised config, Method method, Class<?> targetClass)
/*     */   {
/*  55 */     List interceptorList = new ArrayList(config.getAdvisors().length);
/*  56 */     boolean hasIntroductions = hasMatchingIntroductions(config, targetClass);
/*  57 */     AdvisorAdapterRegistry registry = GlobalAdvisorAdapterRegistry.getInstance();
/*  58 */     for (Advisor advisor : config.getAdvisors()) {
/*  59 */       if ((advisor instanceof PointcutAdvisor))
/*     */       {
/*  61 */         PointcutAdvisor pointcutAdvisor = (PointcutAdvisor)advisor;
/*  62 */         if ((config.isPreFiltered()) || (pointcutAdvisor.getPointcut().getClassFilter().matches(targetClass))) {
/*  63 */           MethodInterceptor[] interceptors = registry.getInterceptors(advisor);
/*  64 */           MethodMatcher mm = pointcutAdvisor.getPointcut().getMethodMatcher();
/*  65 */           if (MethodMatchers.matches(mm, method, targetClass, hasIntroductions)) {
/*  66 */             if (mm.isRuntime())
/*     */             {
/*  69 */               for (MethodInterceptor interceptor : interceptors) {
/*  70 */                 interceptorList.add(new InterceptorAndDynamicMethodMatcher(interceptor, mm));
/*     */               }
/*     */             }
/*     */             else {
/*  74 */               interceptorList.addAll(Arrays.asList(interceptors));
/*     */             }
/*     */           }
/*     */         }
/*     */       }
/*  79 */       else if ((advisor instanceof IntroductionAdvisor)) {
/*  80 */         IntroductionAdvisor ia = (IntroductionAdvisor)advisor;
/*  81 */         if ((config.isPreFiltered()) || (ia.getClassFilter().matches(targetClass))) {
/*  82 */           Interceptor[] interceptors = registry.getInterceptors(advisor);
/*  83 */           interceptorList.addAll(Arrays.asList(interceptors));
/*     */         }
/*     */       }
/*     */       else {
/*  87 */         Interceptor[] interceptors = registry.getInterceptors(advisor);
/*  88 */         interceptorList.addAll(Arrays.asList(interceptors));
/*     */       }
/*     */     }
/*  91 */     return interceptorList;
/*     */   }
/*     */ 
/*     */   private static boolean hasMatchingIntroductions(Advised config, Class<?> targetClass)
/*     */   {
/*  98 */     for (int i = 0; i < config.getAdvisors().length; i++) {
/*  99 */       Advisor advisor = config.getAdvisors()[i];
/* 100 */       if ((advisor instanceof IntroductionAdvisor)) {
/* 101 */         IntroductionAdvisor ia = (IntroductionAdvisor)advisor;
/* 102 */         if (ia.getClassFilter().matches(targetClass)) {
/* 103 */           return true;
/*     */         }
/*     */       }
/*     */     }
/* 107 */     return false;
/*     */   }
/*     */ }

/* Location:           D:\Git\study\spring\WebRoot\WEB-INF\lib\spring-aop-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.aop.framework.DefaultAdvisorChainFactory
 * JD-Core Version:    0.6.2
 */