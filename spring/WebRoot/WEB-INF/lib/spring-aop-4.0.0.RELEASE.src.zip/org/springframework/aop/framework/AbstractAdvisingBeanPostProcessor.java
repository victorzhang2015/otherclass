/*     */ package org.springframework.aop.framework;
/*     */ 
/*     */ import java.util.Map;
/*     */ import java.util.concurrent.ConcurrentHashMap;
/*     */ import org.springframework.aop.Advisor;
/*     */ import org.springframework.aop.support.AopUtils;
/*     */ import org.springframework.beans.factory.BeanClassLoaderAware;
/*     */ import org.springframework.beans.factory.config.BeanPostProcessor;
/*     */ import org.springframework.core.Ordered;
/*     */ import org.springframework.util.ClassUtils;
/*     */ 
/*     */ public abstract class AbstractAdvisingBeanPostProcessor extends ProxyConfig
/*     */   implements BeanPostProcessor, BeanClassLoaderAware, Ordered
/*     */ {
/*     */   protected Advisor advisor;
/*  42 */   protected boolean beforeExistingAdvisors = false;
/*     */ 
/*  44 */   private ClassLoader beanClassLoader = ClassUtils.getDefaultClassLoader();
/*     */ 
/*  50 */   private int order = 2147483647;
/*     */ 
/*  52 */   private final Map<Class<?>, Boolean> eligibleBeans = new ConcurrentHashMap(64);
/*     */ 
/*     */   public void setBeforeExistingAdvisors(boolean beforeExistingAdvisors)
/*     */   {
/*  65 */     this.beforeExistingAdvisors = beforeExistingAdvisors;
/*     */   }
/*     */ 
/*     */   public void setBeanClassLoader(ClassLoader beanClassLoader)
/*     */   {
/*  70 */     this.beanClassLoader = beanClassLoader;
/*     */   }
/*     */ 
/*     */   public void setOrder(int order) {
/*  74 */     this.order = order;
/*     */   }
/*     */ 
/*     */   public int getOrder()
/*     */   {
/*  79 */     return this.order;
/*     */   }
/*     */ 
/*     */   public Object postProcessBeforeInitialization(Object bean, String beanName)
/*     */   {
/*  85 */     return bean;
/*     */   }
/*     */ 
/*     */   public Object postProcessAfterInitialization(Object bean, String beanName)
/*     */   {
/*  90 */     if ((bean instanceof AopInfrastructureBean))
/*     */     {
/*  92 */       return bean;
/*     */     }
/*  94 */     if (isEligible(bean, beanName)) {
/*  95 */       if ((bean instanceof Advised)) {
/*  96 */         Advised advised = (Advised)bean;
/*  97 */         if (this.beforeExistingAdvisors) {
/*  98 */           advised.addAdvisor(0, this.advisor);
/*     */         }
/*     */         else {
/* 101 */           advised.addAdvisor(this.advisor);
/*     */         }
/* 103 */         return bean;
/*     */       }
/*     */ 
/* 106 */       ProxyFactory proxyFactory = new ProxyFactory(bean);
/*     */ 
/* 108 */       proxyFactory.copyFrom(this);
/* 109 */       proxyFactory.addAdvisor(this.advisor);
/* 110 */       return proxyFactory.getProxy(this.beanClassLoader);
/*     */     }
/*     */ 
/* 115 */     return bean;
/*     */   }
/*     */ 
/*     */   protected boolean isEligible(Object bean, String beanName)
/*     */   {
/* 130 */     Class targetClass = AopUtils.getTargetClass(bean);
/* 131 */     Boolean eligible = (Boolean)this.eligibleBeans.get(targetClass);
/* 132 */     if (eligible != null) {
/* 133 */       return eligible.booleanValue();
/*     */     }
/* 135 */     eligible = Boolean.valueOf(AopUtils.canApply(this.advisor, targetClass));
/* 136 */     this.eligibleBeans.put(targetClass, eligible);
/* 137 */     return eligible.booleanValue();
/*     */   }
/*     */ }

/* Location:           D:\Git\study\spring\WebRoot\WEB-INF\lib\spring-aop-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.aop.framework.AbstractAdvisingBeanPostProcessor
 * JD-Core Version:    0.6.2
 */