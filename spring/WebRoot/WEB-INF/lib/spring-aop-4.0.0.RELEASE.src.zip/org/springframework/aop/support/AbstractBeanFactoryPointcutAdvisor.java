/*     */ package org.springframework.aop.support;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.ObjectInputStream;
/*     */ import org.aopalliance.aop.Advice;
/*     */ import org.springframework.beans.factory.BeanFactory;
/*     */ import org.springframework.beans.factory.BeanFactoryAware;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ public abstract class AbstractBeanFactoryPointcutAdvisor extends AbstractPointcutAdvisor
/*     */   implements BeanFactoryAware
/*     */ {
/*     */   private String adviceBeanName;
/*     */   private BeanFactory beanFactory;
/*     */   private transient Advice advice;
/*  50 */   private volatile transient Object adviceMonitor = new Object();
/*     */ 
/*     */   public void setAdviceBeanName(String adviceBeanName)
/*     */   {
/*  62 */     this.adviceBeanName = adviceBeanName;
/*     */   }
/*     */ 
/*     */   public String getAdviceBeanName()
/*     */   {
/*  69 */     return this.adviceBeanName;
/*     */   }
/*     */ 
/*     */   public void setBeanFactory(BeanFactory beanFactory)
/*     */   {
/*  74 */     this.beanFactory = beanFactory;
/*     */   }
/*     */ 
/*     */   public void setAdvice(Advice advice) {
/*  78 */     synchronized (this.adviceMonitor) {
/*  79 */       this.advice = advice;
/*     */     }
/*     */   }
/*     */ 
/*     */   public Advice getAdvice()
/*     */   {
/*  85 */     synchronized (this.adviceMonitor) {
/*  86 */       if ((this.advice == null) && (this.adviceBeanName != null)) {
/*  87 */         Assert.state(this.beanFactory != null, "BeanFactory must be set to resolve 'adviceBeanName'");
/*  88 */         this.advice = ((Advice)this.beanFactory.getBean(this.adviceBeanName, Advice.class));
/*     */       }
/*  90 */       return this.advice;
/*     */     }
/*     */   }
/*     */ 
/*     */   public String toString()
/*     */   {
/*  96 */     return getClass().getName() + ": advice bean '" + getAdviceBeanName() + "'";
/*     */   }
/*     */ 
/*     */   private void readObject(ObjectInputStream ois)
/*     */     throws IOException, ClassNotFoundException
/*     */   {
/* 106 */     ois.defaultReadObject();
/*     */ 
/* 109 */     this.adviceMonitor = new Object();
/*     */   }
/*     */ }

/* Location:           D:\Git\study\spring\WebRoot\WEB-INF\lib\spring-aop-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.aop.support.AbstractBeanFactoryPointcutAdvisor
 * JD-Core Version:    0.6.2
 */