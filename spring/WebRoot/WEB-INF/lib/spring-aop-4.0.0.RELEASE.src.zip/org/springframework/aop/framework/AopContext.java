/*    */ package org.springframework.aop.framework;
/*    */ 
/*    */ import org.springframework.core.NamedThreadLocal;
/*    */ 
/*    */ public abstract class AopContext
/*    */ {
/* 49 */   private static final ThreadLocal<Object> currentProxy = new NamedThreadLocal("Current AOP proxy");
/*    */ 
/*    */   public static Object currentProxy()
/*    */     throws IllegalStateException
/*    */   {
/* 62 */     Object proxy = currentProxy.get();
/* 63 */     if (proxy == null) {
/* 64 */       throw new IllegalStateException("Cannot find current proxy: Set 'exposeProxy' property on Advised to 'true' to make it available.");
/*    */     }
/*    */ 
/* 67 */     return proxy;
/*    */   }
/*    */ 
/*    */   static Object setCurrentProxy(Object proxy)
/*    */   {
/* 78 */     Object old = currentProxy.get();
/* 79 */     if (proxy != null) {
/* 80 */       currentProxy.set(proxy);
/*    */     }
/*    */     else {
/* 83 */       currentProxy.remove();
/*    */     }
/* 85 */     return old;
/*    */   }
/*    */ }

/* Location:           D:\Git\study\spring\WebRoot\WEB-INF\lib\spring-aop-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.aop.framework.AopContext
 * JD-Core Version:    0.6.2
 */