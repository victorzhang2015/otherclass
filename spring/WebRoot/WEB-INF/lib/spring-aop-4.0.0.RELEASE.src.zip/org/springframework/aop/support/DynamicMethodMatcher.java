/*    */ package org.springframework.aop.support;
/*    */ 
/*    */ import java.lang.reflect.Method;
/*    */ import org.springframework.aop.MethodMatcher;
/*    */ 
/*    */ public abstract class DynamicMethodMatcher
/*    */   implements MethodMatcher
/*    */ {
/*    */   public final boolean isRuntime()
/*    */   {
/* 31 */     return true;
/*    */   }
/*    */ 
/*    */   public boolean matches(Method method, Class<?> targetClass)
/*    */   {
/* 40 */     return true;
/*    */   }
/*    */ }

/* Location:           D:\Git\study\spring\WebRoot\WEB-INF\lib\spring-aop-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.aop.support.DynamicMethodMatcher
 * JD-Core Version:    0.6.2
 */