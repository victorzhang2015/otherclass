/*    */ package org.springframework.aop.aspectj;
/*    */ 
/*    */ import java.util.List;
/*    */ import org.springframework.aop.Advisor;
/*    */ import org.springframework.aop.PointcutAdvisor;
/*    */ import org.springframework.aop.interceptor.ExposeInvocationInterceptor;
/*    */ 
/*    */ public abstract class AspectJProxyUtils
/*    */ {
/*    */   public static boolean makeAdvisorChainAspectJCapableIfNecessary(List<Advisor> advisors)
/*    */   {
/* 44 */     if (!advisors.isEmpty()) {
/* 45 */       boolean foundAspectJAdvice = false;
/* 46 */       for (Advisor advisor : advisors)
/*    */       {
/* 49 */         if (isAspectJAdvice(advisor)) {
/* 50 */           foundAspectJAdvice = true;
/*    */         }
/*    */       }
/* 53 */       if ((foundAspectJAdvice) && (!advisors.contains(ExposeInvocationInterceptor.ADVISOR))) {
/* 54 */         advisors.add(0, ExposeInvocationInterceptor.ADVISOR);
/* 55 */         return true;
/*    */       }
/*    */     }
/* 58 */     return false;
/*    */   }
/*    */ 
/*    */   private static boolean isAspectJAdvice(Advisor advisor)
/*    */   {
/* 66 */     if ((!(advisor instanceof InstantiationModelAwarePointcutAdvisor)) && 
/* 67 */       (!(advisor
/* 67 */       .getAdvice() instanceof AbstractAspectJAdvice))) if (!(advisor instanceof PointcutAdvisor))
/*    */         break label45;
/* 69 */     label45: return (((PointcutAdvisor)advisor)
/* 69 */       .getPointcut() instanceof AspectJExpressionPointcut);
/*    */   }
/*    */ }

/* Location:           D:\Git\study\spring\WebRoot\WEB-INF\lib\spring-aop-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.aop.aspectj.AspectJProxyUtils
 * JD-Core Version:    0.6.2
 */