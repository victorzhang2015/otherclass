/*    */ package org.springframework.aop.support.annotation;
/*    */ 
/*    */ import java.lang.annotation.Annotation;
/*    */ import org.springframework.aop.ClassFilter;
/*    */ import org.springframework.core.annotation.AnnotationUtils;
/*    */ import org.springframework.util.Assert;
/*    */ 
/*    */ public class AnnotationClassFilter
/*    */   implements ClassFilter
/*    */ {
/*    */   private final Class<? extends Annotation> annotationType;
/*    */   private final boolean checkInherited;
/*    */ 
/*    */   public AnnotationClassFilter(Class<? extends Annotation> annotationType)
/*    */   {
/* 45 */     this(annotationType, false);
/*    */   }
/*    */ 
/*    */   public AnnotationClassFilter(Class<? extends Annotation> annotationType, boolean checkInherited)
/*    */   {
/* 56 */     Assert.notNull(annotationType, "Annotation type must not be null");
/* 57 */     this.annotationType = annotationType;
/* 58 */     this.checkInherited = checkInherited;
/*    */   }
/*    */ 
/*    */   public boolean matches(Class<?> clazz)
/*    */   {
/* 66 */     return this.checkInherited ? 
/* 65 */       false : AnnotationUtils.findAnnotation(clazz, this.annotationType) != null ? 
/* 65 */       true : clazz
/* 66 */       .isAnnotationPresent(this.annotationType);
/*    */   }
/*    */ }

/* Location:           D:\Git\study\spring\WebRoot\WEB-INF\lib\spring-aop-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.aop.support.annotation.AnnotationClassFilter
 * JD-Core Version:    0.6.2
 */