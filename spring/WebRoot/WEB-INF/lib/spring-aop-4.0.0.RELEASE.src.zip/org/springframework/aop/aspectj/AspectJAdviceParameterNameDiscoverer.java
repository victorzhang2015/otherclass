/*     */ package org.springframework.aop.aspectj;
/*     */ 
/*     */ import java.lang.annotation.Annotation;
/*     */ import java.lang.reflect.Constructor;
/*     */ import java.lang.reflect.Method;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashSet;
/*     */ import java.util.List;
/*     */ import java.util.Set;
/*     */ import org.aspectj.lang.JoinPoint;
/*     */ import org.aspectj.lang.JoinPoint.StaticPart;
/*     */ import org.aspectj.lang.ProceedingJoinPoint;
/*     */ import org.aspectj.weaver.tools.PointcutParser;
/*     */ import org.aspectj.weaver.tools.PointcutPrimitive;
/*     */ import org.springframework.core.ParameterNameDiscoverer;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ public class AspectJAdviceParameterNameDiscoverer
/*     */   implements ParameterNameDiscoverer
/*     */ {
/*     */   private static final String THIS_JOIN_POINT = "thisJoinPoint";
/*     */   private static final String THIS_JOIN_POINT_STATIC_PART = "thisJoinPointStaticPart";
/*     */   private static final int STEP_JOIN_POINT_BINDING = 1;
/*     */   private static final int STEP_THROWING_BINDING = 2;
/*     */   private static final int STEP_ANNOTATION_BINDING = 3;
/*     */   private static final int STEP_RETURNING_BINDING = 4;
/*     */   private static final int STEP_PRIMITIVE_ARGS_BINDING = 5;
/*     */   private static final int STEP_THIS_TARGET_ARGS_BINDING = 6;
/*     */   private static final int STEP_REFERENCE_PCUT_BINDING = 7;
/*     */   private static final int STEP_FINISHED = 8;
/* 132 */   private static final Set<String> singleValuedAnnotationPcds = new HashSet();
/* 133 */   private static final Set<String> nonReferencePointcutTokens = new HashSet();
/*     */   private boolean raiseExceptions;
/*     */   private String returningName;
/*     */   private String throwingName;
/*     */   private String pointcutExpression;
/*     */   private Class<?>[] argumentTypes;
/*     */   private String[] parameterNameBindings;
/*     */   private int numberOfRemainingUnboundArguments;
/*     */ 
/*     */   public AspectJAdviceParameterNameDiscoverer(String pointcutExpression)
/*     */   {
/* 185 */     this.pointcutExpression = pointcutExpression;
/*     */   }
/*     */ 
/*     */   public void setRaiseExceptions(boolean raiseExceptions)
/*     */   {
/* 194 */     this.raiseExceptions = raiseExceptions;
/*     */   }
/*     */ 
/*     */   public void setReturningName(String returningName)
/*     */   {
/* 203 */     this.returningName = returningName;
/*     */   }
/*     */ 
/*     */   public void setThrowingName(String throwingName)
/*     */   {
/* 212 */     this.throwingName = throwingName;
/*     */   }
/*     */ 
/*     */   public String[] getParameterNames(Method method)
/*     */   {
/* 224 */     this.argumentTypes = method.getParameterTypes();
/* 225 */     this.numberOfRemainingUnboundArguments = this.argumentTypes.length;
/* 226 */     this.parameterNameBindings = new String[this.numberOfRemainingUnboundArguments];
/*     */ 
/* 228 */     int minimumNumberUnboundArgs = 0;
/* 229 */     if (this.returningName != null) {
/* 230 */       minimumNumberUnboundArgs++;
/*     */     }
/* 232 */     if (this.throwingName != null) {
/* 233 */       minimumNumberUnboundArgs++;
/*     */     }
/* 235 */     if (this.numberOfRemainingUnboundArguments < minimumNumberUnboundArgs) {
/* 236 */       throw new IllegalStateException("Not enough arguments in method to satisfy binding of returning and throwing variables");
/*     */     }
/*     */ 
/*     */     try
/*     */     {
/* 241 */       int algorithmicStep = 1;
/* 242 */       while ((this.numberOfRemainingUnboundArguments > 0) && (algorithmicStep < 8))
/* 243 */         switch (algorithmicStep++) {
/*     */         case 1:
/* 245 */           if (!maybeBindThisJoinPoint())
/* 246 */             maybeBindThisJoinPointStaticPart(); break;
/*     */         case 2:
/* 250 */           maybeBindThrowingVariable();
/* 251 */           break;
/*     */         case 3:
/* 253 */           maybeBindAnnotationsFromPointcutExpression();
/* 254 */           break;
/*     */         case 4:
/* 256 */           maybeBindReturningVariable();
/* 257 */           break;
/*     */         case 5:
/* 259 */           maybeBindPrimitiveArgsFromPointcutExpression();
/* 260 */           break;
/*     */         case 6:
/* 262 */           maybeBindThisOrTargetOrArgsFromPointcutExpression();
/* 263 */           break;
/*     */         case 7:
/* 265 */           maybeBindReferencePointcutParameter();
/* 266 */           break;
/*     */         default:
/* 268 */           throw new IllegalStateException(new StringBuilder().append("Unknown algorithmic step: ").append(algorithmicStep - 1).toString());
/*     */         }
/*     */     }
/*     */     catch (AmbiguousBindingException ambigEx)
/*     */     {
/* 273 */       if (this.raiseExceptions) {
/* 274 */         throw ambigEx;
/*     */       }
/*     */ 
/* 277 */       return null;
/*     */     }
/*     */     catch (IllegalArgumentException ex)
/*     */     {
/* 281 */       if (this.raiseExceptions) {
/* 282 */         throw ex;
/*     */       }
/*     */ 
/* 285 */       return null;
/*     */     }
/*     */ 
/* 289 */     if (this.numberOfRemainingUnboundArguments == 0) {
/* 290 */       return this.parameterNameBindings;
/*     */     }
/*     */ 
/* 293 */     if (this.raiseExceptions) {
/* 294 */       throw new IllegalStateException(new StringBuilder().append("Failed to bind all argument names: ").append(this.numberOfRemainingUnboundArguments).append(" argument(s) could not be bound").toString());
/*     */     }
/*     */ 
/* 299 */     return null;
/*     */   }
/*     */ 
/*     */   public String[] getParameterNames(Constructor<?> ctor)
/*     */   {
/* 312 */     if (this.raiseExceptions) {
/* 313 */       throw new UnsupportedOperationException("An advice method can never be a constructor");
/*     */     }
/*     */ 
/* 318 */     return null;
/*     */   }
/*     */ 
/*     */   private void bindParameterName(int index, String name)
/*     */   {
/* 324 */     this.parameterNameBindings[index] = name;
/* 325 */     this.numberOfRemainingUnboundArguments -= 1;
/*     */   }
/*     */ 
/*     */   private boolean maybeBindThisJoinPoint()
/*     */   {
/* 333 */     if ((this.argumentTypes[0] == JoinPoint.class) || (this.argumentTypes[0] == ProceedingJoinPoint.class)) {
/* 334 */       bindParameterName(0, "thisJoinPoint");
/* 335 */       return true;
/*     */     }
/*     */ 
/* 338 */     return false;
/*     */   }
/*     */ 
/*     */   private void maybeBindThisJoinPointStaticPart()
/*     */   {
/* 343 */     if (this.argumentTypes[0] == JoinPoint.StaticPart.class)
/* 344 */       bindParameterName(0, "thisJoinPointStaticPart");
/*     */   }
/*     */ 
/*     */   private void maybeBindThrowingVariable()
/*     */   {
/* 353 */     if (this.throwingName == null) {
/* 354 */       return;
/*     */     }
/*     */ 
/* 358 */     int throwableIndex = -1;
/* 359 */     for (int i = 0; i < this.argumentTypes.length; i++) {
/* 360 */       if ((isUnbound(i)) && (isSubtypeOf(Throwable.class, i))) {
/* 361 */         if (throwableIndex == -1) {
/* 362 */           throwableIndex = i;
/*     */         }
/*     */         else
/*     */         {
/* 366 */           throw new AmbiguousBindingException(new StringBuilder().append("Binding of throwing parameter '").append(this.throwingName).append("' is ambiguous: could be bound to argument ").append(throwableIndex).append(" or argument ").append(i).toString());
/*     */         }
/*     */ 
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 373 */     if (throwableIndex == -1) {
/* 374 */       throw new IllegalStateException(new StringBuilder().append("Binding of throwing parameter '").append(this.throwingName).append("' could not be completed as no available arguments are a subtype of Throwable").toString());
/*     */     }
/*     */ 
/* 378 */     bindParameterName(throwableIndex, this.throwingName);
/*     */   }
/*     */ 
/*     */   private void maybeBindReturningVariable()
/*     */   {
/* 386 */     if (this.numberOfRemainingUnboundArguments == 0) {
/* 387 */       throw new IllegalStateException("Algorithm assumes that there must be at least one unbound parameter on entry to this method");
/*     */     }
/*     */ 
/* 391 */     if (this.returningName != null) {
/* 392 */       if (this.numberOfRemainingUnboundArguments > 1) {
/* 393 */         throw new AmbiguousBindingException(new StringBuilder().append("Binding of returning parameter '").append(this.returningName).append("' is ambiguous, there are ").append(this.numberOfRemainingUnboundArguments).append(" candidates.").toString());
/*     */       }
/*     */ 
/* 398 */       for (int i = 0; i < this.parameterNameBindings.length; i++)
/* 399 */         if (this.parameterNameBindings[i] == null) {
/* 400 */           bindParameterName(i, this.returningName);
/* 401 */           break;
/*     */         }
/*     */     }
/*     */   }
/*     */ 
/*     */   private void maybeBindAnnotationsFromPointcutExpression()
/*     */   {
/* 416 */     List varNames = new ArrayList();
/* 417 */     String[] tokens = StringUtils.tokenizeToStringArray(this.pointcutExpression, " ");
/* 418 */     for (int i = 0; i < tokens.length; i++) {
/* 419 */       String toMatch = tokens[i];
/* 420 */       int firstParenIndex = toMatch.indexOf("(");
/* 421 */       if (firstParenIndex != -1) {
/* 422 */         toMatch = toMatch.substring(0, firstParenIndex);
/*     */       }
/* 424 */       if (singleValuedAnnotationPcds.contains(toMatch)) {
/* 425 */         PointcutBody body = getPointcutBody(tokens, i);
/* 426 */         i += body.numTokensConsumed;
/* 427 */         String varName = maybeExtractVariableName(body.text);
/* 428 */         if (varName != null) {
/* 429 */           varNames.add(varName);
/*     */         }
/*     */       }
/* 432 */       else if ((tokens[i].startsWith("@args(")) || (tokens[i].equals("@args"))) {
/* 433 */         PointcutBody body = getPointcutBody(tokens, i);
/* 434 */         i += body.numTokensConsumed;
/* 435 */         maybeExtractVariableNamesFromArgs(body.text, varNames);
/*     */       }
/*     */     }
/*     */ 
/* 439 */     bindAnnotationsFromVarNames(varNames);
/*     */   }
/*     */ 
/*     */   private void bindAnnotationsFromVarNames(List<String> varNames)
/*     */   {
/* 446 */     if (!varNames.isEmpty())
/*     */     {
/* 448 */       int numAnnotationSlots = countNumberOfUnboundAnnotationArguments();
/* 449 */       if (numAnnotationSlots > 1) {
/* 450 */         throw new AmbiguousBindingException(new StringBuilder().append("Found ").append(varNames.size()).append(" potential annotation variable(s), and ").append(numAnnotationSlots).append(" potential argument slots").toString());
/*     */       }
/*     */ 
/* 454 */       if (numAnnotationSlots == 1)
/* 455 */         if (varNames.size() == 1)
/*     */         {
/* 457 */           findAndBind(Annotation.class, (String)varNames.get(0));
/*     */         }
/*     */         else
/*     */         {
/* 461 */           throw new IllegalArgumentException(new StringBuilder().append("Found ").append(varNames.size()).append(" candidate annotation binding variables").append(" but only one potential argument binding slot").toString());
/*     */         }
/*     */     }
/*     */   }
/*     */ 
/*     */   private String maybeExtractVariableName(String candidateToken)
/*     */   {
/* 476 */     if ((candidateToken == null) || (candidateToken.equals(""))) {
/* 477 */       return null;
/*     */     }
/* 479 */     if ((Character.isJavaIdentifierStart(candidateToken.charAt(0))) && 
/* 480 */       (Character.isLowerCase(candidateToken
/* 480 */       .charAt(0))))
/*     */     {
/* 481 */       char[] tokenChars = candidateToken.toCharArray();
/* 482 */       for (char tokenChar : tokenChars) {
/* 483 */         if (!Character.isJavaIdentifierPart(tokenChar)) {
/* 484 */           return null;
/*     */         }
/*     */       }
/* 487 */       return candidateToken;
/*     */     }
/*     */ 
/* 490 */     return null;
/*     */   }
/*     */ 
/*     */   private void maybeExtractVariableNamesFromArgs(String argsSpec, List<String> varNames)
/*     */   {
/* 499 */     if (argsSpec == null) {
/* 500 */       return;
/*     */     }
/* 502 */     String[] tokens = StringUtils.tokenizeToStringArray(argsSpec, ",");
/* 503 */     for (int i = 0; i < tokens.length; i++) {
/* 504 */       tokens[i] = StringUtils.trimWhitespace(tokens[i]);
/* 505 */       String varName = maybeExtractVariableName(tokens[i]);
/* 506 */       if (varName != null)
/* 507 */         varNames.add(varName);
/*     */     }
/*     */   }
/*     */ 
/*     */   private void maybeBindThisOrTargetOrArgsFromPointcutExpression()
/*     */   {
/* 517 */     if (this.numberOfRemainingUnboundArguments > 1) {
/* 518 */       throw new AmbiguousBindingException(new StringBuilder().append("Still ").append(this.numberOfRemainingUnboundArguments).append(" unbound args at this(),target(),args() binding stage, with no way to determine between them").toString());
/*     */     }
/*     */ 
/* 522 */     List varNames = new ArrayList();
/* 523 */     String[] tokens = StringUtils.tokenizeToStringArray(this.pointcutExpression, " ");
/* 524 */     for (int i = 0; i < tokens.length; i++) {
/* 525 */       if ((tokens[i].equals("this")) || 
/* 526 */         (tokens[i]
/* 526 */         .startsWith("this(")) || 
/* 527 */         (tokens[i]
/* 527 */         .equals("target")) || 
/* 528 */         (tokens[i]
/* 528 */         .startsWith("target(")))
/*     */       {
/* 529 */         PointcutBody body = getPointcutBody(tokens, i);
/* 530 */         i += body.numTokensConsumed;
/* 531 */         String varName = maybeExtractVariableName(body.text);
/* 532 */         if (varName != null) {
/* 533 */           varNames.add(varName);
/*     */         }
/*     */       }
/* 536 */       else if ((tokens[i].equals("args")) || (tokens[i].startsWith("args("))) {
/* 537 */         PointcutBody body = getPointcutBody(tokens, i);
/* 538 */         i += body.numTokensConsumed;
/* 539 */         List candidateVarNames = new ArrayList();
/* 540 */         maybeExtractVariableNamesFromArgs(body.text, candidateVarNames);
/*     */ 
/* 543 */         for (String varName : candidateVarNames) {
/* 544 */           if (!alreadyBound(varName)) {
/* 545 */             varNames.add(varName);
/*     */           }
/*     */         }
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 552 */     if (varNames.size() > 1) {
/* 553 */       throw new AmbiguousBindingException(new StringBuilder().append("Found ").append(varNames.size()).append(" candidate this(), target() or args() variables but only one unbound argument slot").toString());
/*     */     }
/*     */ 
/* 556 */     if (varNames.size() == 1)
/* 557 */       for (int j = 0; j < this.parameterNameBindings.length; j++)
/* 558 */         if (isUnbound(j)) {
/* 559 */           bindParameterName(j, (String)varNames.get(0));
/* 560 */           break;
/*     */         }
/*     */   }
/*     */ 
/*     */   private void maybeBindReferencePointcutParameter()
/*     */   {
/* 568 */     if (this.numberOfRemainingUnboundArguments > 1) {
/* 569 */       throw new AmbiguousBindingException(new StringBuilder().append("Still ").append(this.numberOfRemainingUnboundArguments).append(" unbound args at reference pointcut binding stage, with no way to determine between them").toString());
/*     */     }
/*     */ 
/* 573 */     List varNames = new ArrayList();
/* 574 */     String[] tokens = StringUtils.tokenizeToStringArray(this.pointcutExpression, " ");
/* 575 */     for (int i = 0; i < tokens.length; i++) {
/* 576 */       String toMatch = tokens[i];
/* 577 */       if (toMatch.startsWith("!")) {
/* 578 */         toMatch = toMatch.substring(1);
/*     */       }
/* 580 */       int firstParenIndex = toMatch.indexOf("(");
/* 581 */       if (firstParenIndex != -1) {
/* 582 */         toMatch = toMatch.substring(0, firstParenIndex);
/*     */       }
/*     */       else {
/* 585 */         if (tokens.length < i + 2)
/*     */         {
/*     */           continue;
/*     */         }
/*     */ 
/* 590 */         String nextToken = tokens[(i + 1)];
/* 591 */         if (nextToken.charAt(0) != '(')
/*     */         {
/*     */           continue;
/*     */         }
/*     */ 
/*     */       }
/*     */ 
/* 600 */       PointcutBody body = getPointcutBody(tokens, i);
/* 601 */       i += body.numTokensConsumed;
/*     */ 
/* 603 */       if (!nonReferencePointcutTokens.contains(toMatch))
/*     */       {
/* 605 */         String varName = maybeExtractVariableName(body.text);
/* 606 */         if (varName != null) {
/* 607 */           varNames.add(varName);
/*     */         }
/*     */       }
/*     */     }
/*     */ 
/* 612 */     if (varNames.size() > 1) {
/* 613 */       throw new AmbiguousBindingException(new StringBuilder().append("Found ").append(varNames.size()).append(" candidate reference pointcut variables but only one unbound argument slot").toString());
/*     */     }
/*     */ 
/* 616 */     if (varNames.size() == 1)
/* 617 */       for (int j = 0; j < this.parameterNameBindings.length; j++)
/* 618 */         if (isUnbound(j)) {
/* 619 */           bindParameterName(j, (String)varNames.get(0));
/* 620 */           break;
/*     */         }
/*     */   }
/*     */ 
/*     */   private PointcutBody getPointcutBody(String[] tokens, int startIndex)
/*     */   {
/* 632 */     int numTokensConsumed = 0;
/* 633 */     String currentToken = tokens[startIndex];
/* 634 */     int bodyStart = currentToken.indexOf(40);
/* 635 */     if (currentToken.charAt(currentToken.length() - 1) == ')')
/*     */     {
/* 637 */       return new PointcutBody(0, currentToken.substring(bodyStart + 1, currentToken.length() - 1));
/*     */     }
/*     */ 
/* 640 */     StringBuilder sb = new StringBuilder();
/* 641 */     if ((bodyStart >= 0) && (bodyStart != currentToken.length() - 1)) {
/* 642 */       sb.append(currentToken.substring(bodyStart + 1));
/* 643 */       sb.append(" ");
/*     */     }
/* 645 */     numTokensConsumed++;
/* 646 */     int currentIndex = startIndex + numTokensConsumed;
/* 647 */     while (currentIndex < tokens.length) {
/* 648 */       if (tokens[currentIndex].equals("(")) {
/* 649 */         currentIndex++;
/*     */       }
/*     */       else
/*     */       {
/* 653 */         if (tokens[currentIndex].endsWith(")")) {
/* 654 */           sb.append(tokens[currentIndex].substring(0, tokens[currentIndex].length() - 1));
/* 655 */           return new PointcutBody(numTokensConsumed, sb.toString().trim());
/*     */         }
/*     */ 
/* 658 */         String toAppend = tokens[currentIndex];
/* 659 */         if (toAppend.startsWith("(")) {
/* 660 */           toAppend = toAppend.substring(1);
/*     */         }
/* 662 */         sb.append(toAppend);
/* 663 */         sb.append(" ");
/* 664 */         currentIndex++;
/* 665 */         numTokensConsumed++;
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 671 */     return new PointcutBody(numTokensConsumed, null);
/*     */   }
/*     */ 
/*     */   private void maybeBindPrimitiveArgsFromPointcutExpression()
/*     */   {
/* 678 */     int numUnboundPrimitives = countNumberOfUnboundPrimitiveArguments();
/* 679 */     if (numUnboundPrimitives > 1) {
/* 680 */       throw new AmbiguousBindingException(new StringBuilder().append("Found '").append(numUnboundPrimitives).append("' unbound primitive arguments with no way to distinguish between them.").toString());
/*     */     }
/*     */ 
/* 683 */     if (numUnboundPrimitives == 1)
/*     */     {
/* 685 */       List varNames = new ArrayList();
/* 686 */       String[] tokens = StringUtils.tokenizeToStringArray(this.pointcutExpression, " ");
/* 687 */       for (int i = 0; i < tokens.length; i++) {
/* 688 */         if ((tokens[i].equals("args")) || (tokens[i].startsWith("args("))) {
/* 689 */           PointcutBody body = getPointcutBody(tokens, i);
/* 690 */           i += body.numTokensConsumed;
/* 691 */           maybeExtractVariableNamesFromArgs(body.text, varNames);
/*     */         }
/*     */       }
/* 694 */       if (varNames.size() > 1) {
/* 695 */         throw new AmbiguousBindingException(new StringBuilder().append("Found ").append(varNames.size()).append(" candidate variable names but only one candidate binding slot when matching primitive args").toString());
/*     */       }
/*     */ 
/* 698 */       if (varNames.size() == 1)
/*     */       {
/* 700 */         for (int i = 0; i < this.argumentTypes.length; i++)
/* 701 */           if ((isUnbound(i)) && (this.argumentTypes[i].isPrimitive())) {
/* 702 */             bindParameterName(i, (String)varNames.get(0));
/* 703 */             break;
/*     */           }
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   private boolean isUnbound(int i)
/*     */   {
/* 715 */     return this.parameterNameBindings[i] == null;
/*     */   }
/*     */ 
/*     */   private boolean alreadyBound(String varName) {
/* 719 */     for (int i = 0; i < this.parameterNameBindings.length; i++) {
/* 720 */       if ((!isUnbound(i)) && (varName.equals(this.parameterNameBindings[i]))) {
/* 721 */         return true;
/*     */       }
/*     */     }
/* 724 */     return false;
/*     */   }
/*     */ 
/*     */   private boolean isSubtypeOf(Class<?> supertype, int argumentNumber)
/*     */   {
/* 732 */     return supertype.isAssignableFrom(this.argumentTypes[argumentNumber]);
/*     */   }
/*     */ 
/*     */   private int countNumberOfUnboundAnnotationArguments() {
/* 736 */     int count = 0;
/* 737 */     for (int i = 0; i < this.argumentTypes.length; i++) {
/* 738 */       if ((isUnbound(i)) && (isSubtypeOf(Annotation.class, i))) {
/* 739 */         count++;
/*     */       }
/*     */     }
/* 742 */     return count;
/*     */   }
/*     */ 
/*     */   private int countNumberOfUnboundPrimitiveArguments() {
/* 746 */     int count = 0;
/* 747 */     for (int i = 0; i < this.argumentTypes.length; i++) {
/* 748 */       if ((isUnbound(i)) && (this.argumentTypes[i].isPrimitive())) {
/* 749 */         count++;
/*     */       }
/*     */     }
/* 752 */     return count;
/*     */   }
/*     */ 
/*     */   private void findAndBind(Class<?> argumentType, String varName)
/*     */   {
/* 760 */     for (int i = 0; i < this.argumentTypes.length; i++) {
/* 761 */       if ((isUnbound(i)) && (isSubtypeOf(argumentType, i))) {
/* 762 */         bindParameterName(i, varName);
/* 763 */         return;
/*     */       }
/*     */     }
/*     */ 
/* 767 */     throw new IllegalStateException(new StringBuilder().append("Expected to find an unbound argument of type '")
/* 767 */       .append(argumentType
/* 767 */       .getName()).append("'").toString());
/*     */   }
/*     */ 
/*     */   static
/*     */   {
/* 137 */     singleValuedAnnotationPcds.add("@this");
/* 138 */     singleValuedAnnotationPcds.add("@target");
/* 139 */     singleValuedAnnotationPcds.add("@within");
/* 140 */     singleValuedAnnotationPcds.add("@withincode");
/* 141 */     singleValuedAnnotationPcds.add("@annotation");
/*     */ 
/* 143 */     Set pointcutPrimitives = PointcutParser.getAllSupportedPointcutPrimitives();
/* 144 */     for (PointcutPrimitive primitive : pointcutPrimitives) {
/* 145 */       nonReferencePointcutTokens.add(primitive.getName());
/*     */     }
/* 147 */     nonReferencePointcutTokens.add("&&");
/* 148 */     nonReferencePointcutTokens.add("!");
/* 149 */     nonReferencePointcutTokens.add("||");
/* 150 */     nonReferencePointcutTokens.add("and");
/* 151 */     nonReferencePointcutTokens.add("or");
/* 152 */     nonReferencePointcutTokens.add("not");
/*     */   }
/*     */ 
/*     */   public static class AmbiguousBindingException extends RuntimeException
/*     */   {
/*     */     public AmbiguousBindingException(String msg)
/*     */     {
/* 800 */       super();
/*     */     }
/*     */   }
/*     */ 
/*     */   private static class PointcutBody
/*     */   {
/*     */     private int numTokensConsumed;
/*     */     private String text;
/*     */ 
/*     */     public PointcutBody(int tokens, String text)
/*     */     {
/* 782 */       this.numTokensConsumed = tokens;
/* 783 */       this.text = text;
/*     */     }
/*     */   }
/*     */ }

/* Location:           D:\Git\study\spring\WebRoot\WEB-INF\lib\spring-aop-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.aop.aspectj.AspectJAdviceParameterNameDiscoverer
 * JD-Core Version:    0.6.2
 */