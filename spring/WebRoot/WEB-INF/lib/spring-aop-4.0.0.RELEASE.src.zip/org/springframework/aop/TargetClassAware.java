package org.springframework.aop;

public abstract interface TargetClassAware
{
  public abstract Class<?> getTargetClass();
}

/* Location:           D:\Git\study\spring\WebRoot\WEB-INF\lib\spring-aop-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.aop.TargetClassAware
 * JD-Core Version:    0.6.2
 */