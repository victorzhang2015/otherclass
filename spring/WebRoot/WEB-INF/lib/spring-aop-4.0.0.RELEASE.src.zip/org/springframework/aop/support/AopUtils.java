/*     */ package org.springframework.aop.support;
/*     */ 
/*     */ import java.lang.reflect.InvocationTargetException;
/*     */ import java.lang.reflect.Method;
/*     */ import java.lang.reflect.Proxy;
/*     */ import java.util.HashSet;
/*     */ import java.util.Iterator;
/*     */ import java.util.LinkedList;
/*     */ import java.util.List;
/*     */ import java.util.Set;
/*     */ import org.springframework.aop.Advisor;
/*     */ import org.springframework.aop.AopInvocationException;
/*     */ import org.springframework.aop.ClassFilter;
/*     */ import org.springframework.aop.IntroductionAdvisor;
/*     */ import org.springframework.aop.IntroductionAwareMethodMatcher;
/*     */ import org.springframework.aop.MethodMatcher;
/*     */ import org.springframework.aop.Pointcut;
/*     */ import org.springframework.aop.PointcutAdvisor;
/*     */ import org.springframework.aop.SpringProxy;
/*     */ import org.springframework.aop.TargetClassAware;
/*     */ import org.springframework.core.BridgeMethodResolver;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ClassUtils;
/*     */ import org.springframework.util.ReflectionUtils;
/*     */ 
/*     */ public abstract class AopUtils
/*     */ {
/*     */   public static boolean isAopProxy(Object object)
/*     */   {
/*  64 */     return ((object instanceof SpringProxy)) && (
/*  64 */       (Proxy.isProxyClass(object
/*  64 */       .getClass())) || (ClassUtils.isCglibProxyClass(object.getClass())));
/*     */   }
/*     */ 
/*     */   public static boolean isJdkDynamicProxy(Object object)
/*     */   {
/*  73 */     return ((object instanceof SpringProxy)) && (Proxy.isProxyClass(object.getClass()));
/*     */   }
/*     */ 
/*     */   public static boolean isCglibProxy(Object object)
/*     */   {
/*  84 */     return ((object instanceof SpringProxy)) && (ClassUtils.isCglibProxy(object));
/*     */   }
/*     */ 
/*     */   @Deprecated
/*     */   public static boolean isCglibProxyClass(Class<?> clazz)
/*     */   {
/*  94 */     return ClassUtils.isCglibProxyClass(clazz);
/*     */   }
/*     */ 
/*     */   @Deprecated
/*     */   public static boolean isCglibProxyClassName(String className)
/*     */   {
/* 104 */     return ClassUtils.isCglibProxyClassName(className);
/*     */   }
/*     */ 
/*     */   public static Class<?> getTargetClass(Object candidate)
/*     */   {
/* 117 */     Assert.notNull(candidate, "Candidate object must not be null");
/* 118 */     Class result = null;
/* 119 */     if ((candidate instanceof TargetClassAware)) {
/* 120 */       result = ((TargetClassAware)candidate).getTargetClass();
/*     */     }
/* 122 */     if (result == null) {
/* 123 */       result = isCglibProxy(candidate) ? candidate.getClass().getSuperclass() : candidate.getClass();
/*     */     }
/* 125 */     return result;
/*     */   }
/*     */ 
/*     */   public static boolean isEqualsMethod(Method method)
/*     */   {
/* 133 */     return ReflectionUtils.isEqualsMethod(method);
/*     */   }
/*     */ 
/*     */   public static boolean isHashCodeMethod(Method method)
/*     */   {
/* 141 */     return ReflectionUtils.isHashCodeMethod(method);
/*     */   }
/*     */ 
/*     */   public static boolean isToStringMethod(Method method)
/*     */   {
/* 149 */     return ReflectionUtils.isToStringMethod(method);
/*     */   }
/*     */ 
/*     */   public static boolean isFinalizeMethod(Method method)
/*     */   {
/* 158 */     return (method != null) && (method.getName().equals("finalize")) && 
/* 158 */       (method
/* 158 */       .getParameterTypes().length == 0);
/*     */   }
/*     */ 
/*     */   public static Method getMostSpecificMethod(Method method, Class<?> targetClass)
/*     */   {
/* 178 */     Method resolvedMethod = ClassUtils.getMostSpecificMethod(method, targetClass);
/*     */ 
/* 180 */     return BridgeMethodResolver.findBridgedMethod(resolvedMethod);
/*     */   }
/*     */ 
/*     */   public static boolean canApply(Pointcut pc, Class<?> targetClass)
/*     */   {
/* 193 */     return canApply(pc, targetClass, false);
/*     */   }
/*     */ 
/*     */   public static boolean canApply(Pointcut pc, Class<?> targetClass, boolean hasIntroductions)
/*     */   {
/* 207 */     Assert.notNull(pc, "Pointcut must not be null");
/* 208 */     if (!pc.getClassFilter().matches(targetClass)) {
/* 209 */       return false;
/*     */     }
/*     */ 
/* 212 */     MethodMatcher methodMatcher = pc.getMethodMatcher();
/* 213 */     IntroductionAwareMethodMatcher introductionAwareMethodMatcher = null;
/* 214 */     if ((methodMatcher instanceof IntroductionAwareMethodMatcher)) {
/* 215 */       introductionAwareMethodMatcher = (IntroductionAwareMethodMatcher)methodMatcher;
/*     */     }
/*     */ 
/* 218 */     Set classes = new HashSet(ClassUtils.getAllInterfacesForClassAsSet(targetClass));
/* 219 */     classes.add(targetClass);
/* 220 */     for (Class clazz : classes) {
/* 221 */       Method[] methods = clazz.getMethods();
/* 222 */       for (Method method : methods) {
/* 223 */         if (((introductionAwareMethodMatcher != null) && 
/* 224 */           (introductionAwareMethodMatcher
/* 224 */           .matches(method, targetClass, hasIntroductions))) || 
/* 225 */           (methodMatcher
/* 225 */           .matches(method, targetClass)))
/*     */         {
/* 226 */           return true;
/*     */         }
/*     */       }
/*     */     }
/*     */ 
/* 231 */     return false;
/*     */   }
/*     */ 
/*     */   public static boolean canApply(Advisor advisor, Class<?> targetClass)
/*     */   {
/* 243 */     return canApply(advisor, targetClass, false);
/*     */   }
/*     */ 
/*     */   public static boolean canApply(Advisor advisor, Class<?> targetClass, boolean hasIntroductions)
/*     */   {
/* 257 */     if ((advisor instanceof IntroductionAdvisor)) {
/* 258 */       return ((IntroductionAdvisor)advisor).getClassFilter().matches(targetClass);
/*     */     }
/* 260 */     if ((advisor instanceof PointcutAdvisor)) {
/* 261 */       PointcutAdvisor pca = (PointcutAdvisor)advisor;
/* 262 */       return canApply(pca.getPointcut(), targetClass, hasIntroductions);
/*     */     }
/*     */ 
/* 266 */     return true;
/*     */   }
/*     */ 
/*     */   public static List<Advisor> findAdvisorsThatCanApply(List<Advisor> candidateAdvisors, Class<?> clazz)
/*     */   {
/* 279 */     if (candidateAdvisors.isEmpty()) {
/* 280 */       return candidateAdvisors;
/*     */     }
/* 282 */     List eligibleAdvisors = new LinkedList();
/* 283 */     for (Iterator localIterator = candidateAdvisors.iterator(); localIterator.hasNext(); ) { candidate = (Advisor)localIterator.next();
/* 284 */       if (((candidate instanceof IntroductionAdvisor)) && (canApply(candidate, clazz)))
/* 285 */         eligibleAdvisors.add(candidate);
/*     */     }
/*     */     Advisor candidate;
/* 288 */     boolean hasIntroductions = !eligibleAdvisors.isEmpty();
/* 289 */     for (Advisor candidate : candidateAdvisors) {
/* 290 */       if (!(candidate instanceof IntroductionAdvisor))
/*     */       {
/* 294 */         if (canApply(candidate, clazz, hasIntroductions))
/* 295 */           eligibleAdvisors.add(candidate);
/*     */       }
/*     */     }
/* 298 */     return eligibleAdvisors;
/*     */   }
/*     */ 
/*     */   public static Object invokeJoinpointUsingReflection(Object target, Method method, Object[] args)
/*     */     throws Throwable
/*     */   {
/*     */     try
/*     */     {
/* 316 */       ReflectionUtils.makeAccessible(method);
/* 317 */       return method.invoke(target, args);
/*     */     }
/*     */     catch (InvocationTargetException ex)
/*     */     {
/* 322 */       throw ex.getTargetException();
/*     */     }
/*     */     catch (IllegalArgumentException ex) {
/* 325 */       throw new AopInvocationException("AOP configuration seems to be invalid: tried calling method [" + method + "] on target [" + target + "]", ex);
/*     */     }
/*     */     catch (IllegalAccessException ex)
/*     */     {
/* 329 */       throw new AopInvocationException("Could not access method [" + method + "]", ex);
/*     */     }
/*     */   }
/*     */ }

/* Location:           D:\Git\study\spring\WebRoot\WEB-INF\lib\spring-aop-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.aop.support.AopUtils
 * JD-Core Version:    0.6.2
 */