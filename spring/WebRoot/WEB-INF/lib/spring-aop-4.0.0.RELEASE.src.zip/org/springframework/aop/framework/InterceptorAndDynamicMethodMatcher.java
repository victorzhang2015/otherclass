/*    */ package org.springframework.aop.framework;
/*    */ 
/*    */ import org.aopalliance.intercept.MethodInterceptor;
/*    */ import org.springframework.aop.MethodMatcher;
/*    */ 
/*    */ class InterceptorAndDynamicMethodMatcher
/*    */ {
/*    */   final MethodInterceptor interceptor;
/*    */   final MethodMatcher methodMatcher;
/*    */ 
/*    */   public InterceptorAndDynamicMethodMatcher(MethodInterceptor interceptor, MethodMatcher methodMatcher)
/*    */   {
/* 36 */     this.interceptor = interceptor;
/* 37 */     this.methodMatcher = methodMatcher;
/*    */   }
/*    */ }

/* Location:           D:\Git\study\spring\WebRoot\WEB-INF\lib\spring-aop-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.aop.framework.InterceptorAndDynamicMethodMatcher
 * JD-Core Version:    0.6.2
 */