package org.springframework.aop;

import org.aopalliance.intercept.MethodInterceptor;

public abstract interface IntroductionInterceptor extends MethodInterceptor, DynamicIntroductionAdvice
{
}

/* Location:           D:\Git\study\spring\WebRoot\WEB-INF\lib\spring-aop-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.aop.IntroductionInterceptor
 * JD-Core Version:    0.6.2
 */