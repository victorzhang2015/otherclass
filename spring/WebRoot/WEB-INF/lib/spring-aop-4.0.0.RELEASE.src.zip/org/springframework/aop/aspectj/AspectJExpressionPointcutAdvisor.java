/*    */ package org.springframework.aop.aspectj;
/*    */ 
/*    */ import org.springframework.aop.Pointcut;
/*    */ import org.springframework.aop.support.AbstractGenericPointcutAdvisor;
/*    */ 
/*    */ public class AspectJExpressionPointcutAdvisor extends AbstractGenericPointcutAdvisor
/*    */ {
/* 31 */   private final AspectJExpressionPointcut pointcut = new AspectJExpressionPointcut();
/*    */ 
/*    */   public Pointcut getPointcut()
/*    */   {
/* 36 */     return this.pointcut;
/*    */   }
/*    */ 
/*    */   public void setExpression(String expression) {
/* 40 */     this.pointcut.setExpression(expression);
/*    */   }
/*    */ 
/*    */   public void setLocation(String location) {
/* 44 */     this.pointcut.setLocation(location);
/*    */   }
/*    */ 
/*    */   public void setParameterTypes(Class<?>[] types) {
/* 48 */     this.pointcut.setParameterTypes(types);
/*    */   }
/*    */ 
/*    */   public void setParameterNames(String[] names) {
/* 52 */     this.pointcut.setParameterNames(names);
/*    */   }
/*    */ 
/*    */   public String getLocation() {
/* 56 */     return this.pointcut.getLocation();
/*    */   }
/*    */ 
/*    */   public String getExpression() {
/* 60 */     return this.pointcut.getExpression();
/*    */   }
/*    */ }

/* Location:           D:\Git\study\spring\WebRoot\WEB-INF\lib\spring-aop-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.aop.aspectj.AspectJExpressionPointcutAdvisor
 * JD-Core Version:    0.6.2
 */