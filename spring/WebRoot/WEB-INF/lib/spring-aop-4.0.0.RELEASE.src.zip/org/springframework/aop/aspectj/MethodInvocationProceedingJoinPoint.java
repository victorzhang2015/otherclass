/*     */ package org.springframework.aop.aspectj;
/*     */ 
/*     */ import java.lang.reflect.Method;
/*     */ import java.lang.reflect.Modifier;
/*     */ import org.aopalliance.intercept.MethodInvocation;
/*     */ import org.aspectj.lang.JoinPoint.StaticPart;
/*     */ import org.aspectj.lang.ProceedingJoinPoint;
/*     */ import org.aspectj.lang.Signature;
/*     */ import org.aspectj.lang.reflect.MethodSignature;
/*     */ import org.aspectj.lang.reflect.SourceLocation;
/*     */ import org.aspectj.runtime.internal.AroundClosure;
/*     */ import org.springframework.aop.ProxyMethodInvocation;
/*     */ import org.springframework.core.DefaultParameterNameDiscoverer;
/*     */ import org.springframework.core.ParameterNameDiscoverer;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ public class MethodInvocationProceedingJoinPoint
/*     */   implements ProceedingJoinPoint, JoinPoint.StaticPart
/*     */ {
/*  55 */   private static final ParameterNameDiscoverer parameterNameDiscoverer = new DefaultParameterNameDiscoverer();
/*     */   private final ProxyMethodInvocation methodInvocation;
/*     */   private Object[] defensiveCopyOfArgs;
/*     */   private Signature signature;
/*     */   private SourceLocation sourceLocation;
/*     */ 
/*     */   public MethodInvocationProceedingJoinPoint(ProxyMethodInvocation methodInvocation)
/*     */   {
/*  74 */     Assert.notNull(methodInvocation, "MethodInvocation must not be null");
/*  75 */     this.methodInvocation = methodInvocation;
/*     */   }
/*     */ 
/*     */   public void set$AroundClosure(AroundClosure aroundClosure)
/*     */   {
/*  80 */     throw new UnsupportedOperationException();
/*     */   }
/*     */ 
/*     */   public Object proceed() throws Throwable
/*     */   {
/*  85 */     return this.methodInvocation.invocableClone().proceed();
/*     */   }
/*     */ 
/*     */   public Object proceed(Object[] arguments) throws Throwable
/*     */   {
/*  90 */     Assert.notNull(arguments, "Argument array passed to proceed cannot be null");
/*  91 */     if (arguments.length != this.methodInvocation.getArguments().length)
/*     */     {
/*  93 */       throw new IllegalArgumentException("Expecting " + this.methodInvocation
/*  93 */         .getArguments().length + " arguments to proceed, " + "but was passed " + arguments.length + " arguments");
/*     */     }
/*     */ 
/*  96 */     this.methodInvocation.setArguments(arguments);
/*  97 */     return this.methodInvocation.invocableClone(arguments).proceed();
/*     */   }
/*     */ 
/*     */   public Object getThis()
/*     */   {
/* 105 */     return this.methodInvocation.getProxy();
/*     */   }
/*     */ 
/*     */   public Object getTarget()
/*     */   {
/* 113 */     return this.methodInvocation.getThis();
/*     */   }
/*     */ 
/*     */   public Object[] getArgs()
/*     */   {
/* 118 */     if (this.defensiveCopyOfArgs == null) {
/* 119 */       Object[] argsSource = this.methodInvocation.getArguments();
/* 120 */       this.defensiveCopyOfArgs = new Object[argsSource.length];
/* 121 */       System.arraycopy(argsSource, 0, this.defensiveCopyOfArgs, 0, argsSource.length);
/*     */     }
/* 123 */     return this.defensiveCopyOfArgs;
/*     */   }
/*     */ 
/*     */   public Signature getSignature()
/*     */   {
/* 128 */     if (this.signature == null) {
/* 129 */       this.signature = new MethodSignatureImpl(null);
/*     */     }
/* 131 */     return this.signature;
/*     */   }
/*     */ 
/*     */   public SourceLocation getSourceLocation()
/*     */   {
/* 136 */     if (this.sourceLocation == null) {
/* 137 */       this.sourceLocation = new SourceLocationImpl(null);
/*     */     }
/* 139 */     return this.sourceLocation;
/*     */   }
/*     */ 
/*     */   public String getKind()
/*     */   {
/* 144 */     return "method-execution";
/*     */   }
/*     */ 
/*     */   public int getId()
/*     */   {
/* 150 */     return 0;
/*     */   }
/*     */ 
/*     */   public JoinPoint.StaticPart getStaticPart()
/*     */   {
/* 155 */     return this;
/*     */   }
/*     */ 
/*     */   public String toShortString()
/*     */   {
/* 160 */     return "execution(" + getSignature().toShortString() + ")";
/*     */   }
/*     */ 
/*     */   public String toLongString()
/*     */   {
/* 165 */     return "execution(" + getSignature().toLongString() + ")";
/*     */   }
/*     */ 
/*     */   public String toString()
/*     */   {
/* 170 */     return "execution(" + getSignature().toString() + ")";
/*     */   }
/*     */ 
/*     */   private class SourceLocationImpl
/*     */     implements SourceLocation
/*     */   {
/*     */     private SourceLocationImpl()
/*     */     {
/*     */     }
/*     */ 
/*     */     public Class<?> getWithinType()
/*     */     {
/* 301 */       if (MethodInvocationProceedingJoinPoint.this.methodInvocation.getThis() == null) {
/* 302 */         throw new UnsupportedOperationException("No source location joinpoint available: target is null");
/*     */       }
/* 304 */       return MethodInvocationProceedingJoinPoint.this.methodInvocation.getThis().getClass();
/*     */     }
/*     */ 
/*     */     public String getFileName()
/*     */     {
/* 309 */       throw new UnsupportedOperationException();
/*     */     }
/*     */ 
/*     */     public int getLine()
/*     */     {
/* 314 */       throw new UnsupportedOperationException();
/*     */     }
/*     */ 
/*     */     @Deprecated
/*     */     public int getColumn()
/*     */     {
/* 320 */       throw new UnsupportedOperationException();
/*     */     }
/*     */   }
/*     */ 
/*     */   private class MethodSignatureImpl
/*     */     implements MethodSignature
/*     */   {
/*     */     private volatile String[] parameterNames;
/*     */ 
/*     */     private MethodSignatureImpl()
/*     */     {
/*     */     }
/*     */ 
/*     */     public String getName()
/*     */     {
/* 183 */       return MethodInvocationProceedingJoinPoint.this.methodInvocation.getMethod().getName();
/*     */     }
/*     */ 
/*     */     public int getModifiers()
/*     */     {
/* 188 */       return MethodInvocationProceedingJoinPoint.this.methodInvocation.getMethod().getModifiers();
/*     */     }
/*     */ 
/*     */     public Class<?> getDeclaringType()
/*     */     {
/* 193 */       return MethodInvocationProceedingJoinPoint.this.methodInvocation.getMethod().getDeclaringClass();
/*     */     }
/*     */ 
/*     */     public String getDeclaringTypeName()
/*     */     {
/* 198 */       return MethodInvocationProceedingJoinPoint.this.methodInvocation.getMethod().getDeclaringClass().getName();
/*     */     }
/*     */ 
/*     */     public Class<?> getReturnType()
/*     */     {
/* 203 */       return MethodInvocationProceedingJoinPoint.this.methodInvocation.getMethod().getReturnType();
/*     */     }
/*     */ 
/*     */     public Method getMethod()
/*     */     {
/* 208 */       return MethodInvocationProceedingJoinPoint.this.methodInvocation.getMethod();
/*     */     }
/*     */ 
/*     */     public Class<?>[] getParameterTypes()
/*     */     {
/* 213 */       return MethodInvocationProceedingJoinPoint.this.methodInvocation.getMethod().getParameterTypes();
/*     */     }
/*     */ 
/*     */     public String[] getParameterNames()
/*     */     {
/* 218 */       if (this.parameterNames == null) {
/* 219 */         this.parameterNames = MethodInvocationProceedingJoinPoint.parameterNameDiscoverer.getParameterNames(getMethod());
/*     */       }
/* 221 */       return this.parameterNames;
/*     */     }
/*     */ 
/*     */     public Class<?>[] getExceptionTypes()
/*     */     {
/* 226 */       return MethodInvocationProceedingJoinPoint.this.methodInvocation.getMethod().getExceptionTypes();
/*     */     }
/*     */ 
/*     */     public String toShortString()
/*     */     {
/* 231 */       return toString(false, false, false, false);
/*     */     }
/*     */ 
/*     */     public String toLongString()
/*     */     {
/* 236 */       return toString(true, true, true, true);
/*     */     }
/*     */ 
/*     */     public String toString()
/*     */     {
/* 241 */       return toString(false, true, false, true);
/*     */     }
/*     */ 
/*     */     private String toString(boolean includeModifier, boolean includeReturnTypeAndArgs, boolean useLongReturnAndArgumentTypeName, boolean useLongTypeName)
/*     */     {
/* 246 */       StringBuilder sb = new StringBuilder();
/* 247 */       if (includeModifier) {
/* 248 */         sb.append(Modifier.toString(getModifiers()));
/* 249 */         sb.append(" ");
/*     */       }
/* 251 */       if (includeReturnTypeAndArgs) {
/* 252 */         appendType(sb, getReturnType(), useLongReturnAndArgumentTypeName);
/* 253 */         sb.append(" ");
/*     */       }
/* 255 */       appendType(sb, getDeclaringType(), useLongTypeName);
/* 256 */       sb.append(".");
/* 257 */       sb.append(getMethod().getName());
/* 258 */       sb.append("(");
/* 259 */       Class[] parametersTypes = getParameterTypes();
/* 260 */       appendTypes(sb, parametersTypes, includeReturnTypeAndArgs, useLongReturnAndArgumentTypeName);
/* 261 */       sb.append(")");
/* 262 */       return sb.toString();
/*     */     }
/*     */ 
/*     */     private void appendTypes(StringBuilder sb, Class<?>[] types, boolean includeArgs, boolean useLongReturnAndArgumentTypeName)
/*     */     {
/* 267 */       if (includeArgs) {
/* 268 */         int size = types.length; for (int i = 0; i < size; i++) {
/* 269 */           appendType(sb, types[i], useLongReturnAndArgumentTypeName);
/* 270 */           if (i < size - 1) {
/* 271 */             sb.append(",");
/*     */           }
/*     */         }
/*     */ 
/*     */       }
/* 276 */       else if (types.length != 0) {
/* 277 */         sb.append("..");
/*     */       }
/*     */     }
/*     */ 
/*     */     private void appendType(StringBuilder sb, Class<?> type, boolean useLongTypeName)
/*     */     {
/* 283 */       if (type.isArray()) {
/* 284 */         appendType(sb, type.getComponentType(), useLongTypeName);
/* 285 */         sb.append("[]");
/*     */       }
/*     */       else {
/* 288 */         sb.append(useLongTypeName ? type.getName() : type.getSimpleName());
/*     */       }
/*     */     }
/*     */   }
/*     */ }

/* Location:           D:\Git\study\spring\WebRoot\WEB-INF\lib\spring-aop-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.aop.aspectj.MethodInvocationProceedingJoinPoint
 * JD-Core Version:    0.6.2
 */