/*     */ package org.springframework.aop.aspectj.annotation;
/*     */ 
/*     */ import java.lang.reflect.Method;
/*     */ import org.aopalliance.aop.Advice;
/*     */ import org.aspectj.lang.reflect.AjType;
/*     */ import org.aspectj.lang.reflect.PerClause;
/*     */ import org.aspectj.lang.reflect.PerClauseKind;
/*     */ import org.springframework.aop.MethodMatcher;
/*     */ import org.springframework.aop.Pointcut;
/*     */ import org.springframework.aop.aspectj.AspectJExpressionPointcut;
/*     */ import org.springframework.aop.aspectj.AspectJPrecedenceInformation;
/*     */ import org.springframework.aop.aspectj.InstantiationModelAwarePointcutAdvisor;
/*     */ import org.springframework.aop.support.DynamicMethodMatcherPointcut;
/*     */ import org.springframework.aop.support.Pointcuts;
/*     */ 
/*     */ class InstantiationModelAwarePointcutAdvisorImpl
/*     */   implements InstantiationModelAwarePointcutAdvisor, AspectJPrecedenceInformation
/*     */ {
/*     */   private final AspectJExpressionPointcut declaredPointcut;
/*     */   private Pointcut pointcut;
/*     */   private final MetadataAwareAspectInstanceFactory aspectInstanceFactory;
/*     */   private final Method method;
/*     */   private final boolean lazy;
/*     */   private final AspectJAdvisorFactory atAspectJAdvisorFactory;
/*     */   private Advice instantiatedAdvice;
/*     */   private int declarationOrder;
/*     */   private String aspectName;
/*     */   private Boolean isBeforeAdvice;
/*     */   private Boolean isAfterAdvice;
/*     */ 
/*     */   public InstantiationModelAwarePointcutAdvisorImpl(AspectJAdvisorFactory af, AspectJExpressionPointcut ajexp, MetadataAwareAspectInstanceFactory aif, Method method, int declarationOrderInAspect, String aspectName)
/*     */   {
/*  69 */     this.declaredPointcut = ajexp;
/*  70 */     this.method = method;
/*  71 */     this.atAspectJAdvisorFactory = af;
/*  72 */     this.aspectInstanceFactory = aif;
/*  73 */     this.declarationOrder = declarationOrderInAspect;
/*  74 */     this.aspectName = aspectName;
/*     */ 
/*  76 */     if (aif.getAspectMetadata().isLazilyInstantiated())
/*     */     {
/*  79 */       Pointcut preInstantiationPointcut = Pointcuts.union(aif
/*  79 */         .getAspectMetadata().getPerClausePointcut(), this.declaredPointcut);
/*     */ 
/*  84 */       this.pointcut = new PerTargetInstantiationModelPointcut(this.declaredPointcut, preInstantiationPointcut, aif, null);
/*  85 */       this.lazy = true;
/*     */     }
/*     */     else
/*     */     {
/*  89 */       this.instantiatedAdvice = instantiateAdvice(this.declaredPointcut);
/*  90 */       this.pointcut = this.declaredPointcut;
/*  91 */       this.lazy = false;
/*     */     }
/*     */   }
/*     */ 
/*     */   public Pointcut getPointcut()
/*     */   {
/* 102 */     return this.pointcut;
/*     */   }
/*     */ 
/*     */   public boolean isPerInstance()
/*     */   {
/* 112 */     return getAspectMetadata().getAjType().getPerClause().getKind() != PerClauseKind.SINGLETON;
/*     */   }
/*     */ 
/*     */   public AspectMetadata getAspectMetadata()
/*     */   {
/* 119 */     return this.aspectInstanceFactory.getAspectMetadata();
/*     */   }
/*     */ 
/*     */   public synchronized Advice getAdvice()
/*     */   {
/* 127 */     if (this.instantiatedAdvice == null) {
/* 128 */       this.instantiatedAdvice = instantiateAdvice(this.declaredPointcut);
/*     */     }
/* 130 */     return this.instantiatedAdvice;
/*     */   }
/*     */ 
/*     */   public boolean isLazy()
/*     */   {
/* 135 */     return this.lazy;
/*     */   }
/*     */ 
/*     */   public synchronized boolean isAdviceInstantiated()
/*     */   {
/* 140 */     return this.instantiatedAdvice != null;
/*     */   }
/*     */ 
/*     */   private Advice instantiateAdvice(AspectJExpressionPointcut pcut)
/*     */   {
/* 145 */     return this.atAspectJAdvisorFactory.getAdvice(this.method, pcut, this.aspectInstanceFactory, this.declarationOrder, this.aspectName);
/*     */   }
/*     */ 
/*     */   public MetadataAwareAspectInstanceFactory getAspectInstanceFactory()
/*     */   {
/* 150 */     return this.aspectInstanceFactory;
/*     */   }
/*     */ 
/*     */   public AspectJExpressionPointcut getDeclaredPointcut() {
/* 154 */     return this.declaredPointcut;
/*     */   }
/*     */ 
/*     */   public int getOrder()
/*     */   {
/* 159 */     return this.aspectInstanceFactory.getOrder();
/*     */   }
/*     */ 
/*     */   public String getAspectName()
/*     */   {
/* 164 */     return this.aspectName;
/*     */   }
/*     */ 
/*     */   public int getDeclarationOrder()
/*     */   {
/* 169 */     return this.declarationOrder;
/*     */   }
/*     */ 
/*     */   public boolean isBeforeAdvice()
/*     */   {
/* 174 */     if (this.isBeforeAdvice == null) {
/* 175 */       determineAdviceType();
/*     */     }
/* 177 */     return this.isBeforeAdvice.booleanValue();
/*     */   }
/*     */ 
/*     */   public boolean isAfterAdvice()
/*     */   {
/* 182 */     if (this.isAfterAdvice == null) {
/* 183 */       determineAdviceType();
/*     */     }
/* 185 */     return this.isAfterAdvice.booleanValue();
/*     */   }
/*     */ 
/*     */   private void determineAdviceType()
/*     */   {
/* 194 */     AbstractAspectJAdvisorFactory.AspectJAnnotation aspectJAnnotation = AbstractAspectJAdvisorFactory.findAspectJAnnotationOnMethod(this.method);
/*     */ 
/* 195 */     if (aspectJAnnotation == null) {
/* 196 */       this.isBeforeAdvice = Boolean.valueOf(false);
/* 197 */       this.isAfterAdvice = Boolean.valueOf(false);
/*     */     }
/*     */     else {
/* 200 */       switch (1.$SwitchMap$org$springframework$aop$aspectj$annotation$AbstractAspectJAdvisorFactory$AspectJAnnotationType[aspectJAnnotation.getAnnotationType().ordinal()]) {
/*     */       case 1:
/*     */       case 2:
/*     */       case 3:
/* 204 */         this.isAfterAdvice = Boolean.valueOf(true);
/* 205 */         this.isBeforeAdvice = Boolean.valueOf(false);
/* 206 */         break;
/*     */       case 4:
/*     */       case 5:
/* 209 */         this.isAfterAdvice = Boolean.valueOf(false);
/* 210 */         this.isBeforeAdvice = Boolean.valueOf(false);
/* 211 */         break;
/*     */       case 6:
/* 213 */         this.isAfterAdvice = Boolean.valueOf(false);
/* 214 */         this.isBeforeAdvice = Boolean.valueOf(true);
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   public String toString()
/*     */   {
/* 224 */     return "InstantiationModelAwarePointcutAdvisor: expression [" + getDeclaredPointcut().getExpression() + "]; advice method [" + this.method + "]; perClauseKind=" + this.aspectInstanceFactory
/* 224 */       .getAspectMetadata().getAjType().getPerClause().getKind();
/*     */   }
/*     */ 
/*     */   private class PerTargetInstantiationModelPointcut extends DynamicMethodMatcherPointcut
/*     */   {
/*     */     private final AspectJExpressionPointcut declaredPointcut;
/*     */     private final Pointcut preInstantiationPointcut;
/*     */     private LazySingletonAspectInstanceFactoryDecorator aspectInstanceFactory;
/*     */ 
/*     */     private PerTargetInstantiationModelPointcut(AspectJExpressionPointcut declaredPointcut, Pointcut preInstantiationPointcut, MetadataAwareAspectInstanceFactory aspectInstanceFactory)
/*     */     {
/* 244 */       this.declaredPointcut = declaredPointcut;
/* 245 */       this.preInstantiationPointcut = preInstantiationPointcut;
/* 246 */       if ((aspectInstanceFactory instanceof LazySingletonAspectInstanceFactoryDecorator))
/* 247 */         this.aspectInstanceFactory = ((LazySingletonAspectInstanceFactoryDecorator)aspectInstanceFactory);
/*     */     }
/*     */ 
/*     */     public boolean matches(Method method, Class<?> targetClass)
/*     */     {
/* 255 */       return ((isAspectMaterialized()) && (this.declaredPointcut.matches(method, targetClass))) || 
/* 255 */         (this.preInstantiationPointcut
/* 255 */         .getMethodMatcher().matches(method, targetClass));
/*     */     }
/*     */ 
/*     */     public boolean matches(Method method, Class<?> targetClass, Object[] args)
/*     */     {
/* 261 */       return (isAspectMaterialized()) && (this.declaredPointcut.matches(method, targetClass));
/*     */     }
/*     */ 
/*     */     private boolean isAspectMaterialized() {
/* 265 */       return (this.aspectInstanceFactory == null) || (this.aspectInstanceFactory.isMaterialized());
/*     */     }
/*     */   }
/*     */ }

/* Location:           D:\Git\study\spring\WebRoot\WEB-INF\lib\spring-aop-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.aop.aspectj.annotation.InstantiationModelAwarePointcutAdvisorImpl
 * JD-Core Version:    0.6.2
 */