package org.springframework.aop.framework.autoproxy;

import org.springframework.aop.TargetSource;

public abstract interface TargetSourceCreator
{
  public abstract TargetSource getTargetSource(Class<?> paramClass, String paramString);
}

/* Location:           D:\Git\study\spring\WebRoot\WEB-INF\lib\spring-aop-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.aop.framework.autoproxy.TargetSourceCreator
 * JD-Core Version:    0.6.2
 */