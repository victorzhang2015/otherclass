/*    */ package org.springframework.aop.aspectj;
/*    */ 
/*    */ import java.lang.reflect.Method;
/*    */ import org.aopalliance.intercept.MethodInterceptor;
/*    */ import org.aopalliance.intercept.MethodInvocation;
/*    */ import org.aspectj.lang.ProceedingJoinPoint;
/*    */ import org.aspectj.weaver.tools.JoinPointMatch;
/*    */ import org.springframework.aop.ProxyMethodInvocation;
/*    */ 
/*    */ public class AspectJAroundAdvice extends AbstractAspectJAdvice
/*    */   implements MethodInterceptor
/*    */ {
/*    */   public AspectJAroundAdvice(Method aspectJAroundAdviceMethod, AspectJExpressionPointcut pointcut, AspectInstanceFactory aif)
/*    */   {
/* 41 */     super(aspectJAroundAdviceMethod, pointcut, aif);
/*    */   }
/*    */ 
/*    */   public boolean isBeforeAdvice()
/*    */   {
/* 46 */     return false;
/*    */   }
/*    */ 
/*    */   public boolean isAfterAdvice()
/*    */   {
/* 51 */     return false;
/*    */   }
/*    */ 
/*    */   protected boolean supportsProceedingJoinPoint()
/*    */   {
/* 56 */     return true;
/*    */   }
/*    */ 
/*    */   public Object invoke(MethodInvocation mi)
/*    */     throws Throwable
/*    */   {
/* 62 */     if (!(mi instanceof ProxyMethodInvocation)) {
/* 63 */       throw new IllegalStateException("MethodInvocation is not a Spring ProxyMethodInvocation: " + mi);
/*    */     }
/* 65 */     ProxyMethodInvocation pmi = (ProxyMethodInvocation)mi;
/* 66 */     ProceedingJoinPoint pjp = lazyGetProceedingJoinPoint(pmi);
/* 67 */     JoinPointMatch jpm = getJoinPointMatch(pmi);
/* 68 */     return invokeAdviceMethod(pjp, jpm, null, null);
/*    */   }
/*    */ 
/*    */   protected ProceedingJoinPoint lazyGetProceedingJoinPoint(ProxyMethodInvocation rmi)
/*    */   {
/* 79 */     return new MethodInvocationProceedingJoinPoint(rmi);
/*    */   }
/*    */ }

/* Location:           D:\Git\study\spring\WebRoot\WEB-INF\lib\spring-aop-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.aop.aspectj.AspectJAroundAdvice
 * JD-Core Version:    0.6.2
 */