/*     */ package org.springframework.aop.framework;
/*     */ 
/*     */ import org.aopalliance.intercept.Interceptor;
/*     */ import org.springframework.aop.TargetSource;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ClassUtils;
/*     */ 
/*     */ public class ProxyFactory extends ProxyCreatorSupport
/*     */ {
/*     */   public ProxyFactory()
/*     */   {
/*     */   }
/*     */ 
/*     */   public ProxyFactory(Object target)
/*     */   {
/*  50 */     Assert.notNull(target, "Target object must not be null");
/*  51 */     setInterfaces(ClassUtils.getAllInterfaces(target));
/*  52 */     setTarget(target);
/*     */   }
/*     */ 
/*     */   public ProxyFactory(Class<?>[] proxyInterfaces)
/*     */   {
/*  61 */     setInterfaces(proxyInterfaces);
/*     */   }
/*     */ 
/*     */   public ProxyFactory(Class<?> proxyInterface, Interceptor interceptor)
/*     */   {
/*  73 */     addInterface(proxyInterface);
/*  74 */     addAdvice(interceptor);
/*     */   }
/*     */ 
/*     */   public ProxyFactory(Class<?> proxyInterface, TargetSource targetSource)
/*     */   {
/*  84 */     addInterface(proxyInterface);
/*  85 */     setTargetSource(targetSource);
/*     */   }
/*     */ 
/*     */   public Object getProxy()
/*     */   {
/*  98 */     return createAopProxy().getProxy();
/*     */   }
/*     */ 
/*     */   public Object getProxy(ClassLoader classLoader)
/*     */   {
/* 111 */     return createAopProxy().getProxy(classLoader);
/*     */   }
/*     */ 
/*     */   public static <T> T getProxy(Class<T> proxyInterface, Interceptor interceptor)
/*     */   {
/* 127 */     return new ProxyFactory(proxyInterface, interceptor).getProxy();
/*     */   }
/*     */ 
/*     */   public static <T> T getProxy(Class<T> proxyInterface, TargetSource targetSource)
/*     */   {
/* 140 */     return new ProxyFactory(proxyInterface, targetSource).getProxy();
/*     */   }
/*     */ 
/*     */   public static Object getProxy(TargetSource targetSource)
/*     */   {
/* 150 */     if (targetSource.getTargetClass() == null) {
/* 151 */       throw new IllegalArgumentException("Cannot create class proxy for TargetSource with null target class");
/*     */     }
/* 153 */     ProxyFactory proxyFactory = new ProxyFactory();
/* 154 */     proxyFactory.setTargetSource(targetSource);
/* 155 */     proxyFactory.setProxyTargetClass(true);
/* 156 */     return proxyFactory.getProxy();
/*     */   }
/*     */ }

/* Location:           D:\Git\study\spring\WebRoot\WEB-INF\lib\spring-aop-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.aop.framework.ProxyFactory
 * JD-Core Version:    0.6.2
 */