/*    */ package org.springframework.aop.framework.autoproxy;
/*    */ 
/*    */ import org.springframework.beans.factory.config.BeanDefinition;
/*    */ import org.springframework.beans.factory.config.ConfigurableListableBeanFactory;
/*    */ import org.springframework.core.Conventions;
/*    */ 
/*    */ public abstract class AutoProxyUtils
/*    */ {
/* 42 */   public static final String PRESERVE_TARGET_CLASS_ATTRIBUTE = Conventions.getQualifiedAttributeName(AutoProxyUtils.class, "preserveTargetClass")
/* 42 */     ;
/*    */ 
/*    */   public static boolean shouldProxyTargetClass(ConfigurableListableBeanFactory beanFactory, String beanName)
/*    */   {
/* 55 */     if ((beanName != null) && (beanFactory.containsBeanDefinition(beanName))) {
/* 56 */       BeanDefinition bd = beanFactory.getBeanDefinition(beanName);
/* 57 */       return Boolean.TRUE.equals(bd.getAttribute(PRESERVE_TARGET_CLASS_ATTRIBUTE));
/*    */     }
/* 59 */     return false;
/*    */   }
/*    */ }

/* Location:           D:\Git\study\spring\WebRoot\WEB-INF\lib\spring-aop-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.aop.framework.autoproxy.AutoProxyUtils
 * JD-Core Version:    0.6.2
 */