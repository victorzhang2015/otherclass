/*     */ package org.springframework.aop.framework;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import java.lang.reflect.InvocationHandler;
/*     */ import java.lang.reflect.Method;
/*     */ import java.lang.reflect.Proxy;
/*     */ import java.util.List;
/*     */ import org.aopalliance.intercept.MethodInvocation;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.aop.AopInvocationException;
/*     */ import org.springframework.aop.RawTargetAccess;
/*     */ import org.springframework.aop.TargetSource;
/*     */ import org.springframework.aop.support.AopUtils;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ClassUtils;
/*     */ 
/*     */ final class JdkDynamicAopProxy
/*     */   implements AopProxy, InvocationHandler, Serializable
/*     */ {
/*     */   private static final long serialVersionUID = 5531744639992436476L;
/*  78 */   private static Log logger = LogFactory.getLog(JdkDynamicAopProxy.class);
/*     */   private final AdvisedSupport advised;
/*     */   private boolean equalsDefined;
/*     */   private boolean hashCodeDefined;
/*     */ 
/*     */   public JdkDynamicAopProxy(AdvisedSupport config)
/*     */     throws AopConfigException
/*     */   {
/* 101 */     Assert.notNull(config, "AdvisedSupport must not be null");
/* 102 */     if ((config.getAdvisors().length == 0) && (config.getTargetSource() == AdvisedSupport.EMPTY_TARGET_SOURCE)) {
/* 103 */       throw new AopConfigException("No advisors and no TargetSource specified");
/*     */     }
/* 105 */     this.advised = config;
/*     */   }
/*     */ 
/*     */   public Object getProxy()
/*     */   {
/* 111 */     return getProxy(ClassUtils.getDefaultClassLoader());
/*     */   }
/*     */ 
/*     */   public Object getProxy(ClassLoader classLoader)
/*     */   {
/* 116 */     if (logger.isDebugEnabled()) {
/* 117 */       logger.debug("Creating JDK dynamic proxy: target source is " + this.advised.getTargetSource());
/*     */     }
/* 119 */     Class[] proxiedInterfaces = AopProxyUtils.completeProxiedInterfaces(this.advised);
/* 120 */     findDefinedEqualsAndHashCodeMethods(proxiedInterfaces);
/* 121 */     return Proxy.newProxyInstance(classLoader, proxiedInterfaces, this);
/*     */   }
/*     */ 
/*     */   private void findDefinedEqualsAndHashCodeMethods(Class<?>[] proxiedInterfaces)
/*     */   {
/* 130 */     for (Class proxiedInterface : proxiedInterfaces) {
/* 131 */       Method[] methods = proxiedInterface.getDeclaredMethods();
/* 132 */       for (Method method : methods) {
/* 133 */         if (AopUtils.isEqualsMethod(method)) {
/* 134 */           this.equalsDefined = true;
/*     */         }
/* 136 */         if (AopUtils.isHashCodeMethod(method)) {
/* 137 */           this.hashCodeDefined = true;
/*     */         }
/* 139 */         if ((this.equalsDefined) && (this.hashCodeDefined))
/* 140 */           return;
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   public Object invoke(Object proxy, Method method, Object[] args)
/*     */     throws Throwable
/*     */   {
/* 155 */     Object oldProxy = null;
/* 156 */     boolean setProxyContext = false;
/*     */ 
/* 158 */     TargetSource targetSource = this.advised.targetSource;
/* 159 */     Class targetClass = null;
/* 160 */     Object target = null;
/*     */     try
/*     */     {
/*     */       Object localObject1;
/* 163 */       if ((!this.equalsDefined) && (AopUtils.isEqualsMethod(method)))
/*     */       {
/* 165 */         return Boolean.valueOf(equals(args[0]));
/*     */       }
/* 167 */       if ((!this.hashCodeDefined) && (AopUtils.isHashCodeMethod(method)))
/*     */       {
/* 169 */         return Integer.valueOf(hashCode());
/*     */       }
/* 171 */       if ((!this.advised.opaque) && (method.getDeclaringClass().isInterface()) && 
/* 172 */         (method
/* 172 */         .getDeclaringClass().isAssignableFrom(Advised.class)))
/*     */       {
/* 174 */         return AopUtils.invokeJoinpointUsingReflection(this.advised, method, args);
/*     */       }
/*     */ 
/* 179 */       if (this.advised.exposeProxy)
/*     */       {
/* 181 */         oldProxy = AopContext.setCurrentProxy(proxy);
/* 182 */         setProxyContext = true;
/*     */       }
/*     */ 
/* 187 */       target = targetSource.getTarget();
/* 188 */       if (target != null) {
/* 189 */         targetClass = target.getClass();
/*     */       }
/*     */ 
/* 193 */       List chain = this.advised.getInterceptorsAndDynamicInterceptionAdvice(method, targetClass);
/*     */       Object retVal;
/*     */       Object retVal;
/* 197 */       if (chain.isEmpty())
/*     */       {
/* 201 */         retVal = AopUtils.invokeJoinpointUsingReflection(target, method, args);
/*     */       }
/*     */       else
/*     */       {
/* 205 */         MethodInvocation invocation = new ReflectiveMethodInvocation(proxy, target, method, args, targetClass, chain);
/*     */ 
/* 207 */         retVal = invocation.proceed();
/*     */       }
/*     */ 
/* 211 */       Class returnType = method.getReturnType();
/* 212 */       if ((retVal != null) && (retVal == target) && (returnType.isInstance(proxy)) && 
/* 213 */         (!RawTargetAccess.class
/* 213 */         .isAssignableFrom(method
/* 213 */         .getDeclaringClass())))
/*     */       {
/* 217 */         retVal = proxy;
/* 218 */       } else if ((retVal == null) && (returnType != Void.TYPE) && (returnType.isPrimitive())) {
/* 219 */         throw new AopInvocationException("Null return value from advice does not match primitive return type for: " + method);
/*     */       }
/* 221 */       return retVal;
/*     */     }
/*     */     finally {
/* 224 */       if ((target != null) && (!targetSource.isStatic()))
/*     */       {
/* 226 */         targetSource.releaseTarget(target);
/*     */       }
/* 228 */       if (setProxyContext)
/*     */       {
/* 230 */         AopContext.setCurrentProxy(oldProxy);
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   public boolean equals(Object other)
/*     */   {
/* 243 */     if (other == this) {
/* 244 */       return true;
/*     */     }
/* 246 */     if (other == null)
/* 247 */       return false;
/*     */     JdkDynamicAopProxy otherProxy;
/* 251 */     if ((other instanceof JdkDynamicAopProxy)) {
/* 252 */       otherProxy = (JdkDynamicAopProxy)other;
/*     */     }
/*     */     else
/*     */     {
/*     */       JdkDynamicAopProxy otherProxy;
/* 254 */       if (Proxy.isProxyClass(other.getClass())) {
/* 255 */         InvocationHandler ih = Proxy.getInvocationHandler(other);
/* 256 */         if (!(ih instanceof JdkDynamicAopProxy)) {
/* 257 */           return false;
/*     */         }
/* 259 */         otherProxy = (JdkDynamicAopProxy)ih;
/*     */       }
/*     */       else
/*     */       {
/* 263 */         return false;
/*     */       }
/*     */     }
/*     */     JdkDynamicAopProxy otherProxy;
/* 267 */     return AopProxyUtils.equalsInProxy(this.advised, otherProxy.advised);
/*     */   }
/*     */ 
/*     */   public int hashCode()
/*     */   {
/* 275 */     return JdkDynamicAopProxy.class.hashCode() * 13 + this.advised.getTargetSource().hashCode();
/*     */   }
/*     */ }

/* Location:           D:\Git\study\spring\WebRoot\WEB-INF\lib\spring-aop-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.aop.framework.JdkDynamicAopProxy
 * JD-Core Version:    0.6.2
 */