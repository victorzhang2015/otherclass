/*     */ package org.springframework.aop.framework;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import java.lang.reflect.Method;
/*     */ import java.lang.reflect.Modifier;
/*     */ import java.lang.reflect.UndeclaredThrowableException;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.WeakHashMap;
/*     */ import org.aopalliance.aop.Advice;
/*     */ import org.aopalliance.intercept.MethodInvocation;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.aop.Advisor;
/*     */ import org.springframework.aop.AopInvocationException;
/*     */ import org.springframework.aop.PointcutAdvisor;
/*     */ import org.springframework.aop.RawTargetAccess;
/*     */ import org.springframework.aop.TargetSource;
/*     */ import org.springframework.aop.support.AopUtils;
/*     */ import org.springframework.cglib.core.CodeGenerationException;
/*     */ import org.springframework.cglib.proxy.Callback;
/*     */ import org.springframework.cglib.proxy.CallbackFilter;
/*     */ import org.springframework.cglib.proxy.Dispatcher;
/*     */ import org.springframework.cglib.proxy.Enhancer;
/*     */ import org.springframework.cglib.proxy.Factory;
/*     */ import org.springframework.cglib.proxy.MethodInterceptor;
/*     */ import org.springframework.cglib.proxy.MethodProxy;
/*     */ import org.springframework.cglib.proxy.NoOp;
/*     */ import org.springframework.cglib.transform.impl.MemorySafeUndeclaredThrowableStrategy;
/*     */ import org.springframework.core.SmartClassLoader;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ClassUtils;
/*     */ import org.springframework.util.ObjectUtils;
/*     */ 
/*     */ class CglibAopProxy
/*     */   implements AopProxy, Serializable
/*     */ {
/*     */   private static final int AOP_PROXY = 0;
/*     */   private static final int INVOKE_TARGET = 1;
/*     */   private static final int NO_OVERRIDE = 2;
/*     */   private static final int DISPATCH_TARGET = 3;
/*     */   private static final int DISPATCH_ADVISED = 4;
/*     */   private static final int INVOKE_EQUALS = 5;
/*     */   private static final int INVOKE_HASHCODE = 6;
/*  95 */   protected static final Log logger = LogFactory.getLog(CglibAopProxy.class);
/*     */ 
/*  98 */   private static final Map<Class<?>, Boolean> validatedClasses = new WeakHashMap();
/*     */   protected final AdvisedSupport advised;
/*     */   private Object[] constructorArgs;
/*     */   private Class<?>[] constructorArgTypes;
/*     */   private final transient AdvisedDispatcher advisedDispatcher;
/*     */   private transient Map<String, Integer> fixedInterceptorMap;
/*     */   private transient int fixedInterceptorOffset;
/*     */ 
/*     */   public CglibAopProxy(AdvisedSupport config)
/*     */     throws AopConfigException
/*     */   {
/* 123 */     Assert.notNull(config, "AdvisedSupport must not be null");
/* 124 */     if ((config.getAdvisors().length == 0) && (config.getTargetSource() == AdvisedSupport.EMPTY_TARGET_SOURCE)) {
/* 125 */       throw new AopConfigException("No advisors and no TargetSource specified");
/*     */     }
/* 127 */     this.advised = config;
/* 128 */     this.advisedDispatcher = new AdvisedDispatcher(this.advised);
/*     */   }
/*     */ 
/*     */   public void setConstructorArguments(Object[] constructorArgs, Class<?>[] constructorArgTypes)
/*     */   {
/* 137 */     if ((constructorArgs == null) || (constructorArgTypes == null)) {
/* 138 */       throw new IllegalArgumentException("Both 'constructorArgs' and 'constructorArgTypes' need to be specified");
/*     */     }
/* 140 */     if (constructorArgs.length != constructorArgTypes.length) {
/* 141 */       throw new IllegalArgumentException("Number of 'constructorArgs' (" + constructorArgs.length + ") must match number of 'constructorArgTypes' (" + constructorArgTypes.length + ")");
/*     */     }
/*     */ 
/* 144 */     this.constructorArgs = constructorArgs;
/* 145 */     this.constructorArgTypes = constructorArgTypes;
/*     */   }
/*     */ 
/*     */   public Object getProxy()
/*     */   {
/* 151 */     return getProxy(null);
/*     */   }
/*     */ 
/*     */   public Object getProxy(ClassLoader classLoader)
/*     */   {
/* 156 */     if (logger.isDebugEnabled()) {
/* 157 */       logger.debug("Creating CGLIB proxy: target source is " + this.advised.getTargetSource());
/*     */     }
/*     */     try
/*     */     {
/* 161 */       Class rootClass = this.advised.getTargetClass();
/* 162 */       Assert.state(rootClass != null, "Target class must be available for creating a CGLIB proxy");
/*     */ 
/* 164 */       Class proxySuperClass = rootClass;
/* 165 */       if (ClassUtils.isCglibProxyClass(rootClass)) {
/* 166 */         proxySuperClass = rootClass.getSuperclass();
/* 167 */         Class[] additionalInterfaces = rootClass.getInterfaces();
/* 168 */         for (Class additionalInterface : additionalInterfaces) {
/* 169 */           this.advised.addInterface(additionalInterface);
/*     */         }
/*     */ 
/*     */       }
/*     */ 
/* 174 */       validateClassIfNecessary(proxySuperClass);
/*     */ 
/* 177 */       Enhancer enhancer = createEnhancer();
/* 178 */       if (classLoader != null) {
/* 179 */         enhancer.setClassLoader(classLoader);
/* 180 */         if (((classLoader instanceof SmartClassLoader)) && 
/* 181 */           (((SmartClassLoader)classLoader)
/* 181 */           .isClassReloadable(proxySuperClass)))
/*     */         {
/* 182 */           enhancer.setUseCache(false);
/*     */         }
/*     */       }
/* 185 */       enhancer.setSuperclass(proxySuperClass);
/* 186 */       enhancer.setStrategy(new MemorySafeUndeclaredThrowableStrategy(UndeclaredThrowableException.class));
/* 187 */       enhancer.setInterfaces(AopProxyUtils.completeProxiedInterfaces(this.advised));
/*     */ 
/* 189 */       Callback[] callbacks = getCallbacks(rootClass);
/* 190 */       Class[] types = new Class[callbacks.length];
/*     */ 
/* 192 */       for (int x = 0; x < types.length; x++) {
/* 193 */         types[x] = callbacks[x].getClass();
/*     */       }
/*     */ 
/* 196 */       enhancer.setCallbackTypes(types);
/* 197 */       enhancer.setCallbackFilter(new ProxyCallbackFilter(this.advised
/* 198 */         .getConfigurationOnlyCopy(), this.fixedInterceptorMap, this.fixedInterceptorOffset));
/*     */ 
/* 201 */       return createProxyClassAndInstance(enhancer, callbacks);
/*     */     }
/*     */     catch (CodeGenerationException ex)
/*     */     {
/* 205 */       throw new AopConfigException("Could not generate CGLIB subclass of class [" + this.advised
/* 205 */         .getTargetClass() + "]: " + "Common causes of this problem include using a final class or a non-visible class", ex);
/*     */     }
/*     */     catch (IllegalArgumentException ex)
/*     */     {
/* 211 */       throw new AopConfigException("Could not generate CGLIB subclass of class [" + this.advised
/* 211 */         .getTargetClass() + "]: " + "Common causes of this problem include using a final class or a non-visible class", ex);
/*     */     }
/*     */     catch (Exception ex)
/*     */     {
/* 217 */       throw new AopConfigException("Unexpected AOP exception", ex);
/*     */     }
/*     */   }
/*     */ 
/*     */   protected Object createProxyClassAndInstance(Enhancer enhancer, Callback[] callbacks)
/*     */   {
/* 223 */     enhancer.setInterceptDuringConstruction(false);
/* 224 */     enhancer.setCallbacks(callbacks);
/*     */ 
/* 226 */     return this.constructorArgs == null ? enhancer.create() : enhancer.create(this.constructorArgTypes, this.constructorArgs);
/*     */   }
/*     */ 
/*     */   protected Enhancer createEnhancer()
/*     */   {
/* 235 */     return new Enhancer();
/*     */   }
/*     */ 
/*     */   private void validateClassIfNecessary(Class<?> proxySuperClass)
/*     */   {
/* 243 */     if (logger.isWarnEnabled())
/* 244 */       synchronized (validatedClasses) {
/* 245 */         if (!validatedClasses.containsKey(proxySuperClass)) {
/* 246 */           doValidateClass(proxySuperClass);
/* 247 */           validatedClasses.put(proxySuperClass, Boolean.TRUE);
/*     */         }
/*     */       }
/*     */   }
/*     */ 
/*     */   private void doValidateClass(Class<?> proxySuperClass)
/*     */   {
/* 258 */     if (logger.isWarnEnabled()) {
/* 259 */       Method[] methods = proxySuperClass.getMethods();
/* 260 */       for (Method method : methods)
/* 261 */         if ((!Object.class.equals(method.getDeclaringClass())) && (!Modifier.isStatic(method.getModifiers())) && 
/* 262 */           (Modifier.isFinal(method
/* 262 */           .getModifiers())))
/* 263 */           logger.warn("Unable to proxy method [" + method + "] because it is final: " + "All calls to this method via a proxy will be routed directly to the proxy.");
/*     */     }
/*     */   }
/*     */ 
/*     */   private Callback[] getCallbacks(Class<?> rootClass)
/*     */     throws Exception
/*     */   {
/* 272 */     boolean exposeProxy = this.advised.isExposeProxy();
/* 273 */     boolean isFrozen = this.advised.isFrozen();
/* 274 */     boolean isStatic = this.advised.getTargetSource().isStatic();
/*     */ 
/* 277 */     Callback aopInterceptor = new DynamicAdvisedInterceptor(this.advised);
/*     */     Callback targetInterceptor;
/*     */     Callback targetInterceptor;
/* 282 */     if (exposeProxy)
/*     */     {
/* 285 */       targetInterceptor = isStatic ? new StaticUnadvisedExposedInterceptor(this.advised
/* 284 */         .getTargetSource().getTarget()) : new DynamicUnadvisedExposedInterceptor(this.advised
/* 285 */         .getTargetSource());
/*     */     }
/*     */     else
/*     */     {
/* 290 */       targetInterceptor = isStatic ? new StaticUnadvisedInterceptor(this.advised
/* 289 */         .getTargetSource().getTarget()) : new DynamicUnadvisedInterceptor(this.advised
/* 290 */         .getTargetSource());
/*     */     }
/*     */ 
/* 296 */     Callback targetDispatcher = (Callback)(isStatic ? new StaticDispatcher(this.advised
/* 296 */       .getTargetSource().getTarget()) : new SerializableNoOp());
/*     */ 
/* 298 */     Callback[] mainCallbacks = { aopInterceptor, targetInterceptor, new SerializableNoOp(), targetDispatcher, this.advisedDispatcher, new EqualsInterceptor(this.advised), new HashCodeInterceptor(this.advised) };
/*     */     Callback[] callbacks;
/* 312 */     if ((isStatic) && (isFrozen)) {
/* 313 */       Method[] methods = rootClass.getMethods();
/* 314 */       Callback[] fixedCallbacks = new Callback[methods.length];
/* 315 */       this.fixedInterceptorMap = new HashMap(methods.length);
/*     */ 
/* 319 */       for (int x = 0; x < methods.length; x++) {
/* 320 */         List chain = this.advised.getInterceptorsAndDynamicInterceptionAdvice(methods[x], rootClass);
/* 321 */         fixedCallbacks[x] = new FixedChainStaticTargetInterceptor(chain, this.advised
/* 322 */           .getTargetSource().getTarget(), this.advised.getTargetClass());
/* 323 */         this.fixedInterceptorMap.put(methods[x].toString(), Integer.valueOf(x));
/*     */       }
/*     */ 
/* 328 */       Callback[] callbacks = new Callback[mainCallbacks.length + fixedCallbacks.length];
/* 329 */       System.arraycopy(mainCallbacks, 0, callbacks, 0, mainCallbacks.length);
/* 330 */       System.arraycopy(fixedCallbacks, 0, callbacks, mainCallbacks.length, fixedCallbacks.length);
/* 331 */       this.fixedInterceptorOffset = mainCallbacks.length;
/*     */     }
/*     */     else {
/* 334 */       callbacks = mainCallbacks;
/*     */     }
/* 336 */     return callbacks;
/*     */   }
/*     */ 
/*     */   private static Object processReturnType(Object proxy, Object target, Method method, Object retVal)
/*     */   {
/* 345 */     if ((retVal != null) && (retVal == target) && 
/* 346 */       (!RawTargetAccess.class
/* 346 */       .isAssignableFrom(method
/* 346 */       .getDeclaringClass())))
/*     */     {
/* 350 */       retVal = proxy;
/*     */     }
/* 352 */     Class returnType = method.getReturnType();
/* 353 */     if ((retVal == null) && (returnType != Void.TYPE) && (returnType.isPrimitive())) {
/* 354 */       throw new AopInvocationException("Null return value from advice does not match primitive return type for: " + method);
/*     */     }
/* 356 */     return retVal;
/*     */   }
/*     */ 
/*     */   public boolean equals(Object other)
/*     */   {
/* 363 */     return (this == other) || (((other instanceof CglibAopProxy)) && 
/* 363 */       (AopProxyUtils.equalsInProxy(this.advised, ((CglibAopProxy)other).advised)));
/*     */   }
/*     */ 
/*     */   public int hashCode()
/*     */   {
/* 368 */     return CglibAopProxy.class.hashCode() * 13 + this.advised.getTargetSource().hashCode();
/*     */   }
/*     */ 
/*     */   private static class ProxyCallbackFilter
/*     */     implements CallbackFilter
/*     */   {
/*     */     private final AdvisedSupport advised;
/*     */     private final Map<String, Integer> fixedInterceptorMap;
/*     */     private final int fixedInterceptorOffset;
/*     */ 
/*     */     public ProxyCallbackFilter(AdvisedSupport advised, Map<String, Integer> fixedInterceptorMap, int fixedInterceptorOffset)
/*     */     {
/* 731 */       this.advised = advised;
/* 732 */       this.fixedInterceptorMap = fixedInterceptorMap;
/* 733 */       this.fixedInterceptorOffset = fixedInterceptorOffset;
/*     */     }
/*     */ 
/*     */     public int accept(Method method)
/*     */     {
/* 774 */       if (AopUtils.isFinalizeMethod(method)) {
/* 775 */         CglibAopProxy.logger.debug("Found finalize() method - using NO_OVERRIDE");
/* 776 */         return 2;
/*     */       }
/* 778 */       if ((!this.advised.isOpaque()) && (method.getDeclaringClass().isInterface()) && 
/* 779 */         (method
/* 779 */         .getDeclaringClass().isAssignableFrom(Advised.class))) {
/* 780 */         if (CglibAopProxy.logger.isDebugEnabled()) {
/* 781 */           CglibAopProxy.logger.debug("Method is declared on Advised interface: " + method);
/*     */         }
/* 783 */         return 4;
/*     */       }
/*     */ 
/* 786 */       if (AopUtils.isEqualsMethod(method)) {
/* 787 */         CglibAopProxy.logger.debug("Found 'equals' method: " + method);
/* 788 */         return 5;
/*     */       }
/*     */ 
/* 791 */       if (AopUtils.isHashCodeMethod(method)) {
/* 792 */         CglibAopProxy.logger.debug("Found 'hashCode' method: " + method);
/* 793 */         return 6;
/*     */       }
/* 795 */       Class targetClass = this.advised.getTargetClass();
/*     */ 
/* 797 */       List chain = this.advised.getInterceptorsAndDynamicInterceptionAdvice(method, targetClass);
/* 798 */       boolean haveAdvice = !chain.isEmpty();
/* 799 */       boolean exposeProxy = this.advised.isExposeProxy();
/* 800 */       boolean isStatic = this.advised.getTargetSource().isStatic();
/* 801 */       boolean isFrozen = this.advised.isFrozen();
/* 802 */       if ((haveAdvice) || (!isFrozen))
/*     */       {
/* 804 */         if (exposeProxy) {
/* 805 */           if (CglibAopProxy.logger.isDebugEnabled()) {
/* 806 */             CglibAopProxy.logger.debug("Must expose proxy on advised method: " + method);
/*     */           }
/* 808 */           return 0;
/*     */         }
/* 810 */         String key = method.toString();
/*     */ 
/* 813 */         if ((isStatic) && (isFrozen) && (this.fixedInterceptorMap.containsKey(key))) {
/* 814 */           if (CglibAopProxy.logger.isDebugEnabled()) {
/* 815 */             CglibAopProxy.logger.debug("Method has advice and optimisations are enabled: " + method);
/*     */           }
/*     */ 
/* 819 */           int index = ((Integer)this.fixedInterceptorMap.get(key)).intValue();
/* 820 */           return index + this.fixedInterceptorOffset;
/*     */         }
/*     */ 
/* 823 */         if (CglibAopProxy.logger.isDebugEnabled()) {
/* 824 */           CglibAopProxy.logger.debug("Unable to apply any optimisations to advised method: " + method);
/*     */         }
/* 826 */         return 0;
/*     */       }
/*     */ 
/* 836 */       if ((exposeProxy) || (!isStatic)) {
/* 837 */         return 1;
/*     */       }
/* 839 */       Class returnType = method.getReturnType();
/* 840 */       if (targetClass == returnType) {
/* 841 */         if (CglibAopProxy.logger.isDebugEnabled()) {
/* 842 */           CglibAopProxy.logger.debug("Method " + method + "has return type same as target type (may return this) - using INVOKE_TARGET");
/*     */         }
/*     */ 
/* 845 */         return 1;
/*     */       }
/* 847 */       if ((returnType.isPrimitive()) || (!returnType.isAssignableFrom(targetClass))) {
/* 848 */         if (CglibAopProxy.logger.isDebugEnabled()) {
/* 849 */           CglibAopProxy.logger.debug("Method " + method + " has return type that ensures this cannot be returned- using DISPATCH_TARGET");
/*     */         }
/*     */ 
/* 852 */         return 3;
/*     */       }
/*     */ 
/* 855 */       if (CglibAopProxy.logger.isDebugEnabled()) {
/* 856 */         CglibAopProxy.logger.debug("Method " + method + "has return type that is assignable from the target type (may return this) - " + "using INVOKE_TARGET");
/*     */       }
/*     */ 
/* 860 */       return 1;
/*     */     }
/*     */ 
/*     */     public boolean equals(Object other)
/*     */     {
/* 867 */       if (other == this) {
/* 868 */         return true;
/*     */       }
/* 870 */       if (!(other instanceof ProxyCallbackFilter)) {
/* 871 */         return false;
/*     */       }
/* 873 */       ProxyCallbackFilter otherCallbackFilter = (ProxyCallbackFilter)other;
/* 874 */       AdvisedSupport otherAdvised = otherCallbackFilter.advised;
/* 875 */       if ((this.advised == null) || (otherAdvised == null)) {
/* 876 */         return false;
/*     */       }
/* 878 */       if (this.advised.isFrozen() != otherAdvised.isFrozen()) {
/* 879 */         return false;
/*     */       }
/* 881 */       if (this.advised.isExposeProxy() != otherAdvised.isExposeProxy()) {
/* 882 */         return false;
/*     */       }
/* 884 */       if (this.advised.getTargetSource().isStatic() != otherAdvised.getTargetSource().isStatic()) {
/* 885 */         return false;
/*     */       }
/* 887 */       if (!AopProxyUtils.equalsProxiedInterfaces(this.advised, otherAdvised)) {
/* 888 */         return false;
/*     */       }
/*     */ 
/* 892 */       Advisor[] thisAdvisors = this.advised.getAdvisors();
/* 893 */       Advisor[] thatAdvisors = otherAdvised.getAdvisors();
/* 894 */       if (thisAdvisors.length != thatAdvisors.length) {
/* 895 */         return false;
/*     */       }
/* 897 */       for (int i = 0; i < thisAdvisors.length; i++) {
/* 898 */         Advisor thisAdvisor = thisAdvisors[i];
/* 899 */         Advisor thatAdvisor = thatAdvisors[i];
/* 900 */         if (!equalsAdviceClasses(thisAdvisor, thatAdvisor)) {
/* 901 */           return false;
/*     */         }
/* 903 */         if (!equalsPointcuts(thisAdvisor, thatAdvisor)) {
/* 904 */           return false;
/*     */         }
/*     */       }
/* 907 */       return true;
/*     */     }
/*     */ 
/*     */     private boolean equalsAdviceClasses(Advisor a, Advisor b) {
/* 911 */       Advice aa = a.getAdvice();
/* 912 */       Advice ba = b.getAdvice();
/* 913 */       if ((aa == null) || (ba == null)) {
/* 914 */         return aa == ba;
/*     */       }
/* 916 */       return aa.getClass().equals(ba.getClass());
/*     */     }
/*     */ 
/*     */     private boolean equalsPointcuts(Advisor a, Advisor b)
/*     */     {
/* 922 */       if ((a instanceof PointcutAdvisor)) if (!(b instanceof PointcutAdvisor))
/*     */           break label42;
/* 924 */       label42: return ObjectUtils.nullSafeEquals(((PointcutAdvisor)a)
/* 924 */         .getPointcut(), ((PointcutAdvisor)b).getPointcut());
/*     */     }
/*     */ 
/*     */     public int hashCode()
/*     */     {
/* 929 */       int hashCode = 0;
/* 930 */       Advisor[] advisors = this.advised.getAdvisors();
/* 931 */       for (Advisor advisor : advisors) {
/* 932 */         Advice advice = advisor.getAdvice();
/* 933 */         if (advice != null) {
/* 934 */           hashCode = 13 * hashCode + advice.getClass().hashCode();
/*     */         }
/*     */       }
/* 937 */       hashCode = 13 * hashCode + (this.advised.isFrozen() ? 1 : 0);
/* 938 */       hashCode = 13 * hashCode + (this.advised.isExposeProxy() ? 1 : 0);
/* 939 */       hashCode = 13 * hashCode + (this.advised.isOptimize() ? 1 : 0);
/* 940 */       hashCode = 13 * hashCode + (this.advised.isOpaque() ? 1 : 0);
/* 941 */       return hashCode;
/*     */     }
/*     */   }
/*     */ 
/*     */   private static class CglibMethodInvocation extends ReflectiveMethodInvocation
/*     */   {
/*     */     private final MethodProxy methodProxy;
/*     */     private boolean protectedMethod;
/*     */ 
/*     */     public CglibMethodInvocation(Object proxy, Object target, Method method, Object[] arguments, Class<?> targetClass, List<Object> interceptorsAndDynamicMethodMatchers, MethodProxy methodProxy)
/*     */     {
/* 698 */       super(target, method, arguments, targetClass, interceptorsAndDynamicMethodMatchers);
/* 699 */       this.methodProxy = methodProxy;
/* 700 */       this.protectedMethod = Modifier.isProtected(method.getModifiers());
/*     */     }
/*     */ 
/*     */     protected Object invokeJoinpoint()
/*     */       throws Throwable
/*     */     {
/* 709 */       if (this.protectedMethod) {
/* 710 */         return super.invokeJoinpoint();
/*     */       }
/*     */ 
/* 713 */       return this.methodProxy.invoke(this.target, this.arguments);
/*     */     }
/*     */   }
/*     */ 
/*     */   private static class DynamicAdvisedInterceptor
/*     */     implements MethodInterceptor, Serializable
/*     */   {
/*     */     private AdvisedSupport advised;
/*     */ 
/*     */     public DynamicAdvisedInterceptor(AdvisedSupport advised)
/*     */     {
/* 612 */       this.advised = advised;
/*     */     }
/*     */ 
/*     */     public Object intercept(Object proxy, Method method, Object[] args, MethodProxy methodProxy) throws Throwable
/*     */     {
/* 617 */       Object oldProxy = null;
/* 618 */       boolean setProxyContext = false;
/* 619 */       Class targetClass = null;
/* 620 */       Object target = null;
/*     */       try {
/* 622 */         if (this.advised.exposeProxy)
/*     */         {
/* 624 */           oldProxy = AopContext.setCurrentProxy(proxy);
/* 625 */           setProxyContext = true;
/*     */         }
/*     */ 
/* 629 */         target = getTarget();
/* 630 */         if (target != null) {
/* 631 */           targetClass = target.getClass();
/*     */         }
/* 633 */         List chain = this.advised.getInterceptorsAndDynamicInterceptionAdvice(method, targetClass);
/*     */         Object retVal;
/* 637 */         if ((chain.isEmpty()) && (Modifier.isPublic(method.getModifiers())))
/*     */         {
/* 642 */           retVal = methodProxy.invoke(target, args);
/*     */         }
/*     */         else
/*     */         {
/* 646 */           retVal = new CglibAopProxy.CglibMethodInvocation(proxy, target, method, args, targetClass, chain, methodProxy).proceed();
/*     */         }
/* 648 */         Object retVal = CglibAopProxy.processReturnType(proxy, target, method, retVal);
/* 649 */         return retVal;
/*     */       }
/*     */       finally {
/* 652 */         if (target != null) {
/* 653 */           releaseTarget(target);
/*     */         }
/* 655 */         if (setProxyContext)
/*     */         {
/* 657 */           AopContext.setCurrentProxy(oldProxy);
/*     */         }
/*     */       }
/*     */     }
/*     */ 
/*     */     public boolean equals(Object other)
/*     */     {
/* 664 */       if (this != other) if (!(other instanceof DynamicAdvisedInterceptor))
/*     */           break label33;
/* 666 */       label33: return this.advised
/* 666 */         .equals(((DynamicAdvisedInterceptor)other).advised);
/*     */     }
/*     */ 
/*     */     public int hashCode()
/*     */     {
/* 674 */       return this.advised.hashCode();
/*     */     }
/*     */ 
/*     */     protected Object getTarget() throws Exception {
/* 678 */       return this.advised.getTargetSource().getTarget();
/*     */     }
/*     */ 
/*     */     protected void releaseTarget(Object target) throws Exception {
/* 682 */       this.advised.getTargetSource().releaseTarget(target);
/*     */     }
/*     */   }
/*     */ 
/*     */   private static class FixedChainStaticTargetInterceptor
/*     */     implements MethodInterceptor, Serializable
/*     */   {
/*     */     private final List<Object> adviceChain;
/*     */     private final Object target;
/*     */     private final Class<?> targetClass;
/*     */ 
/*     */     public FixedChainStaticTargetInterceptor(List<Object> adviceChain, Object target, Class<?> targetClass)
/*     */     {
/* 586 */       this.adviceChain = adviceChain;
/* 587 */       this.target = target;
/* 588 */       this.targetClass = targetClass;
/*     */     }
/*     */ 
/*     */     public Object intercept(Object proxy, Method method, Object[] args, MethodProxy methodProxy) throws Throwable
/*     */     {
/* 593 */       MethodInvocation invocation = new CglibAopProxy.CglibMethodInvocation(proxy, this.target, method, args, this.targetClass, this.adviceChain, methodProxy);
/*     */ 
/* 596 */       Object retVal = invocation.proceed();
/* 597 */       retVal = CglibAopProxy.processReturnType(proxy, this.target, method, retVal);
/* 598 */       return retVal;
/*     */     }
/*     */   }
/*     */ 
/*     */   private static class HashCodeInterceptor
/*     */     implements MethodInterceptor, Serializable
/*     */   {
/*     */     private final AdvisedSupport advised;
/*     */ 
/*     */     public HashCodeInterceptor(AdvisedSupport advised)
/*     */     {
/* 564 */       this.advised = advised;
/*     */     }
/*     */ 
/*     */     public Object intercept(Object proxy, Method method, Object[] args, MethodProxy methodProxy)
/*     */     {
/* 569 */       return Integer.valueOf(CglibAopProxy.class.hashCode() * 13 + this.advised.getTargetSource().hashCode());
/*     */     }
/*     */   }
/*     */ 
/*     */   private static class EqualsInterceptor
/*     */     implements MethodInterceptor, Serializable
/*     */   {
/*     */     private final AdvisedSupport advised;
/*     */ 
/*     */     public EqualsInterceptor(AdvisedSupport advised)
/*     */     {
/* 531 */       this.advised = advised;
/*     */     }
/*     */ 
/*     */     public Object intercept(Object proxy, Method method, Object[] args, MethodProxy methodProxy)
/*     */     {
/* 536 */       Object other = args[0];
/* 537 */       if (proxy == other) {
/* 538 */         return Boolean.valueOf(true);
/*     */       }
/* 540 */       if ((other instanceof Factory)) {
/* 541 */         Callback callback = ((Factory)other).getCallback(5);
/* 542 */         if (!(callback instanceof EqualsInterceptor)) {
/* 543 */           return Boolean.valueOf(false);
/*     */         }
/* 545 */         AdvisedSupport otherAdvised = ((EqualsInterceptor)callback).advised;
/* 546 */         return Boolean.valueOf(AopProxyUtils.equalsInProxy(this.advised, otherAdvised));
/*     */       }
/*     */ 
/* 549 */       return Boolean.valueOf(false);
/*     */     }
/*     */   }
/*     */ 
/*     */   private static class AdvisedDispatcher
/*     */     implements Dispatcher, Serializable
/*     */   {
/*     */     private final AdvisedSupport advised;
/*     */ 
/*     */     public AdvisedDispatcher(AdvisedSupport advised)
/*     */     {
/* 512 */       this.advised = advised;
/*     */     }
/*     */ 
/*     */     public Object loadObject() throws Exception
/*     */     {
/* 517 */       return this.advised;
/*     */     }
/*     */   }
/*     */ 
/*     */   private static class StaticDispatcher
/*     */     implements Dispatcher, Serializable
/*     */   {
/*     */     private Object target;
/*     */ 
/*     */     public StaticDispatcher(Object target)
/*     */     {
/* 494 */       this.target = target;
/*     */     }
/*     */ 
/*     */     public Object loadObject()
/*     */     {
/* 499 */       return this.target;
/*     */     }
/*     */   }
/*     */ 
/*     */   private static class DynamicUnadvisedExposedInterceptor
/*     */     implements MethodInterceptor, Serializable
/*     */   {
/*     */     private final TargetSource targetSource;
/*     */ 
/*     */     public DynamicUnadvisedExposedInterceptor(TargetSource targetSource)
/*     */     {
/* 464 */       this.targetSource = targetSource;
/*     */     }
/*     */ 
/*     */     public Object intercept(Object proxy, Method method, Object[] args, MethodProxy methodProxy) throws Throwable
/*     */     {
/* 469 */       Object oldProxy = null;
/* 470 */       Object target = this.targetSource.getTarget();
/*     */       try {
/* 472 */         oldProxy = AopContext.setCurrentProxy(proxy);
/* 473 */         Object retVal = methodProxy.invoke(target, args);
/* 474 */         return CglibAopProxy.processReturnType(proxy, target, method, retVal);
/*     */       }
/*     */       finally {
/* 477 */         AopContext.setCurrentProxy(oldProxy);
/* 478 */         this.targetSource.releaseTarget(target);
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   private static class DynamicUnadvisedInterceptor
/*     */     implements MethodInterceptor, Serializable
/*     */   {
/*     */     private final TargetSource targetSource;
/*     */ 
/*     */     public DynamicUnadvisedInterceptor(TargetSource targetSource)
/*     */     {
/* 439 */       this.targetSource = targetSource;
/*     */     }
/*     */ 
/*     */     public Object intercept(Object proxy, Method method, Object[] args, MethodProxy methodProxy) throws Throwable
/*     */     {
/* 444 */       Object target = this.targetSource.getTarget();
/*     */       try {
/* 446 */         Object retVal = methodProxy.invoke(target, args);
/* 447 */         return CglibAopProxy.processReturnType(proxy, target, method, retVal);
/*     */       }
/*     */       finally {
/* 450 */         this.targetSource.releaseTarget(target);
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   private static class StaticUnadvisedExposedInterceptor
/*     */     implements MethodInterceptor, Serializable
/*     */   {
/*     */     private final Object target;
/*     */ 
/*     */     public StaticUnadvisedExposedInterceptor(Object target)
/*     */     {
/* 411 */       this.target = target;
/*     */     }
/*     */ 
/*     */     public Object intercept(Object proxy, Method method, Object[] args, MethodProxy methodProxy) throws Throwable
/*     */     {
/* 416 */       Object oldProxy = null;
/*     */       try {
/* 418 */         oldProxy = AopContext.setCurrentProxy(proxy);
/* 419 */         Object retVal = methodProxy.invoke(this.target, args);
/* 420 */         return CglibAopProxy.processReturnType(proxy, this.target, method, retVal);
/*     */       }
/*     */       finally {
/* 423 */         AopContext.setCurrentProxy(oldProxy);
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   private static class StaticUnadvisedInterceptor
/*     */     implements MethodInterceptor, Serializable
/*     */   {
/*     */     private final Object target;
/*     */ 
/*     */     public StaticUnadvisedInterceptor(Object target)
/*     */     {
/* 391 */       this.target = target;
/*     */     }
/*     */ 
/*     */     public Object intercept(Object proxy, Method method, Object[] args, MethodProxy methodProxy) throws Throwable
/*     */     {
/* 396 */       Object retVal = methodProxy.invoke(this.target, args);
/* 397 */       return CglibAopProxy.processReturnType(proxy, this.target, method, retVal);
/*     */     }
/*     */   }
/*     */ 
/*     */   public static class SerializableNoOp
/*     */     implements NoOp, Serializable
/*     */   {
/*     */   }
/*     */ }

/* Location:           D:\Git\study\spring\WebRoot\WEB-INF\lib\spring-aop-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.aop.framework.CglibAopProxy
 * JD-Core Version:    0.6.2
 */