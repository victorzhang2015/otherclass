package org.springframework.aop.aspectj;

import org.springframework.core.Ordered;

public abstract interface AspectInstanceFactory extends Ordered
{
  public abstract Object getAspectInstance();

  public abstract ClassLoader getAspectClassLoader();
}

/* Location:           D:\Git\study\spring\WebRoot\WEB-INF\lib\spring-aop-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.aop.aspectj.AspectInstanceFactory
 * JD-Core Version:    0.6.2
 */