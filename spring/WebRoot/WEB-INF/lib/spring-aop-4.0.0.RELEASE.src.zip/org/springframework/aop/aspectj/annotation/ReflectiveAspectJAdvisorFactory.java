/*     */ package org.springframework.aop.aspectj.annotation;
/*     */ 
/*     */ import java.lang.annotation.Annotation;
/*     */ import java.lang.reflect.Field;
/*     */ import java.lang.reflect.Method;
/*     */ import java.util.Collections;
/*     */ import java.util.Comparator;
/*     */ import java.util.Iterator;
/*     */ import java.util.LinkedList;
/*     */ import java.util.List;
/*     */ import org.aopalliance.aop.Advice;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.aspectj.lang.annotation.After;
/*     */ import org.aspectj.lang.annotation.AfterReturning;
/*     */ import org.aspectj.lang.annotation.AfterThrowing;
/*     */ import org.aspectj.lang.annotation.Around;
/*     */ import org.aspectj.lang.annotation.Before;
/*     */ import org.aspectj.lang.annotation.DeclareParents;
/*     */ import org.aspectj.lang.annotation.Pointcut;
/*     */ import org.springframework.aop.Advisor;
/*     */ import org.springframework.aop.MethodBeforeAdvice;
/*     */ import org.springframework.aop.aspectj.AbstractAspectJAdvice;
/*     */ import org.springframework.aop.aspectj.AspectJAfterAdvice;
/*     */ import org.springframework.aop.aspectj.AspectJAfterReturningAdvice;
/*     */ import org.springframework.aop.aspectj.AspectJAfterThrowingAdvice;
/*     */ import org.springframework.aop.aspectj.AspectJAroundAdvice;
/*     */ import org.springframework.aop.aspectj.AspectJExpressionPointcut;
/*     */ import org.springframework.aop.aspectj.AspectJMethodBeforeAdvice;
/*     */ import org.springframework.aop.aspectj.DeclareParentsAdvisor;
/*     */ import org.springframework.aop.framework.AopConfigException;
/*     */ import org.springframework.aop.support.DefaultPointcutAdvisor;
/*     */ import org.springframework.core.ParameterNameDiscoverer;
/*     */ import org.springframework.core.annotation.AnnotationUtils;
/*     */ import org.springframework.core.convert.converter.Converter;
/*     */ import org.springframework.core.convert.converter.ConvertingComparator;
/*     */ import org.springframework.util.ReflectionUtils;
/*     */ import org.springframework.util.ReflectionUtils.MethodCallback;
/*     */ import org.springframework.util.StringUtils;
/*     */ import org.springframework.util.comparator.CompoundComparator;
/*     */ import org.springframework.util.comparator.InstanceComparator;
/*     */ 
/*     */ public class ReflectiveAspectJAdvisorFactory extends AbstractAspectJAdvisorFactory
/*     */ {
/*  91 */   private static final Comparator<Method> METHOD_COMPARATOR = comparator;
/*     */ 
/*     */   public List<Advisor> getAdvisors(MetadataAwareAspectInstanceFactory maaif)
/*     */   {
/*  97 */     Class aspectClass = maaif.getAspectMetadata().getAspectClass();
/*  98 */     String aspectName = maaif.getAspectMetadata().getAspectName();
/*  99 */     validate(aspectClass);
/*     */ 
/* 103 */     MetadataAwareAspectInstanceFactory lazySingletonAspectInstanceFactory = new LazySingletonAspectInstanceFactoryDecorator(maaif);
/*     */ 
/* 106 */     List advisors = new LinkedList();
/* 107 */     for (Iterator localIterator = getAdvisorMethods(aspectClass).iterator(); localIterator.hasNext(); ) { method = (Method)localIterator.next();
/* 108 */       advisor = getAdvisor(method, lazySingletonAspectInstanceFactory, advisors.size(), aspectName);
/* 109 */       if (advisor != null) {
/* 110 */         advisors.add(advisor);
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 115 */     if ((!advisors.isEmpty()) && (lazySingletonAspectInstanceFactory.getAspectMetadata().isLazilyInstantiated())) {
/* 116 */       instantiationAdvisor = new SyntheticInstantiationAdvisor(lazySingletonAspectInstanceFactory);
/* 117 */       advisors.add(0, instantiationAdvisor);
/*     */     }
/*     */ 
/* 121 */     Object instantiationAdvisor = aspectClass.getDeclaredFields(); Method method = instantiationAdvisor.length; for (Advisor advisor = 0; advisor < method; advisor++) { Field field = instantiationAdvisor[advisor];
/* 122 */       Advisor advisor = getDeclareParentsAdvisor(field);
/* 123 */       if (advisor != null) {
/* 124 */         advisors.add(advisor);
/*     */       }
/*     */     }
/*     */ 
/* 128 */     return advisors;
/*     */   }
/*     */ 
/*     */   private List<Method> getAdvisorMethods(Class<?> aspectClass) {
/* 132 */     final List methods = new LinkedList();
/* 133 */     ReflectionUtils.doWithMethods(aspectClass, new ReflectionUtils.MethodCallback()
/*     */     {
/*     */       public void doWith(Method method) throws IllegalArgumentException
/*     */       {
/* 137 */         if (AnnotationUtils.getAnnotation(method, Pointcut.class) == null)
/* 138 */           methods.add(method);
/*     */       }
/*     */     });
/* 142 */     Collections.sort(methods, METHOD_COMPARATOR);
/* 143 */     return methods;
/*     */   }
/*     */ 
/*     */   private Advisor getDeclareParentsAdvisor(Field introductionField)
/*     */   {
/* 154 */     DeclareParents declareParents = (DeclareParents)introductionField.getAnnotation(DeclareParents.class);
/* 155 */     if (declareParents == null)
/*     */     {
/* 157 */       return null;
/*     */     }
/*     */ 
/* 160 */     if (DeclareParents.class.equals(declareParents.defaultImpl()))
/*     */     {
/* 163 */       throw new IllegalStateException("defaultImpl must be set on DeclareParents");
/*     */     }
/*     */ 
/* 167 */     return new DeclareParentsAdvisor(introductionField
/* 167 */       .getType(), declareParents.value(), declareParents.defaultImpl());
/*     */   }
/*     */ 
/*     */   public Advisor getAdvisor(Method candidateAdviceMethod, MetadataAwareAspectInstanceFactory aif, int declarationOrderInAspect, String aspectName)
/*     */   {
/* 175 */     validate(aif.getAspectMetadata().getAspectClass());
/*     */ 
/* 178 */     AspectJExpressionPointcut ajexp = getPointcut(candidateAdviceMethod, aif
/* 178 */       .getAspectMetadata().getAspectClass());
/* 179 */     if (ajexp == null) {
/* 180 */       return null;
/*     */     }
/* 182 */     return new InstantiationModelAwarePointcutAdvisorImpl(this, ajexp, aif, candidateAdviceMethod, declarationOrderInAspect, aspectName);
/*     */   }
/*     */ 
/*     */   private AspectJExpressionPointcut getPointcut(Method candidateAdviceMethod, Class<?> candidateAspectClass)
/*     */   {
/* 188 */     AbstractAspectJAdvisorFactory.AspectJAnnotation aspectJAnnotation = AbstractAspectJAdvisorFactory.findAspectJAnnotationOnMethod(candidateAdviceMethod);
/*     */ 
/* 189 */     if (aspectJAnnotation == null) {
/* 190 */       return null;
/*     */     }
/* 192 */     AspectJExpressionPointcut ajexp = new AspectJExpressionPointcut(candidateAspectClass, new String[0], new Class[0]);
/*     */ 
/* 194 */     ajexp.setExpression(aspectJAnnotation.getPointcutExpression());
/* 195 */     return ajexp;
/*     */   }
/*     */ 
/*     */   public Advice getAdvice(Method candidateAdviceMethod, AspectJExpressionPointcut ajexp, MetadataAwareAspectInstanceFactory aif, int declarationOrderInAspect, String aspectName)
/*     */   {
/* 203 */     Class candidateAspectClass = aif.getAspectMetadata().getAspectClass();
/* 204 */     validate(candidateAspectClass);
/*     */ 
/* 207 */     AbstractAspectJAdvisorFactory.AspectJAnnotation aspectJAnnotation = AbstractAspectJAdvisorFactory.findAspectJAnnotationOnMethod(candidateAdviceMethod);
/*     */ 
/* 208 */     if (aspectJAnnotation == null) {
/* 209 */       return null;
/*     */     }
/*     */ 
/* 214 */     if (!isAspect(candidateAspectClass))
/*     */     {
/* 217 */       throw new AopConfigException("Advice must be declared inside an aspect type: Offending method '" + candidateAdviceMethod + "' in class [" + candidateAspectClass
/* 217 */         .getName() + "]");
/*     */     }
/*     */ 
/* 220 */     if (this.logger.isDebugEnabled())
/* 221 */       this.logger.debug("Found AspectJ method: " + candidateAdviceMethod);
/*     */     AbstractAspectJAdvice springAdvice;
/*     */     AbstractAspectJAdvice springAdvice;
/*     */     AbstractAspectJAdvice springAdvice;
/* 226 */     switch (4.$SwitchMap$org$springframework$aop$aspectj$annotation$AbstractAspectJAdvisorFactory$AspectJAnnotationType[aspectJAnnotation.getAnnotationType().ordinal()]) {
/*     */     case 1:
/* 228 */       springAdvice = new AspectJMethodBeforeAdvice(candidateAdviceMethod, ajexp, aif);
/* 229 */       break;
/*     */     case 2:
/* 231 */       springAdvice = new AspectJAfterAdvice(candidateAdviceMethod, ajexp, aif);
/* 232 */       break;
/*     */     case 3:
/* 234 */       AbstractAspectJAdvice springAdvice = new AspectJAfterReturningAdvice(candidateAdviceMethod, ajexp, aif);
/* 235 */       AfterReturning afterReturningAnnotation = (AfterReturning)aspectJAnnotation.getAnnotation();
/* 236 */       if (StringUtils.hasText(afterReturningAnnotation.returning()))
/* 237 */         springAdvice.setReturningName(afterReturningAnnotation.returning()); break;
/*     */     case 4:
/* 241 */       AbstractAspectJAdvice springAdvice = new AspectJAfterThrowingAdvice(candidateAdviceMethod, ajexp, aif);
/* 242 */       AfterThrowing afterThrowingAnnotation = (AfterThrowing)aspectJAnnotation.getAnnotation();
/* 243 */       if (StringUtils.hasText(afterThrowingAnnotation.throwing()))
/* 244 */         springAdvice.setThrowingName(afterThrowingAnnotation.throwing()); break;
/*     */     case 5:
/* 248 */       springAdvice = new AspectJAroundAdvice(candidateAdviceMethod, ajexp, aif);
/* 249 */       break;
/*     */     case 6:
/* 251 */       if (this.logger.isDebugEnabled()) {
/* 252 */         this.logger.debug("Processing pointcut '" + candidateAdviceMethod.getName() + "'");
/*     */       }
/* 254 */       return null;
/*     */     default:
/* 256 */       throw new UnsupportedOperationException("Unsupported advice type on method " + candidateAdviceMethod);
/*     */     }
/*     */     AbstractAspectJAdvice springAdvice;
/* 261 */     springAdvice.setAspectName(aspectName);
/* 262 */     springAdvice.setDeclarationOrder(declarationOrderInAspect);
/* 263 */     String[] argNames = this.parameterNameDiscoverer.getParameterNames(candidateAdviceMethod);
/* 264 */     if (argNames != null) {
/* 265 */       springAdvice.setArgumentNamesFromStringArray(argNames);
/*     */     }
/* 267 */     springAdvice.calculateArgumentBindings();
/* 268 */     return springAdvice;
/*     */   }
/*     */ 
/*     */   static
/*     */   {
/*  73 */     CompoundComparator comparator = new CompoundComparator();
/*  74 */     comparator.addComparator(new ConvertingComparator(new InstanceComparator(new Class[] { Around.class, Before.class, After.class, AfterReturning.class, AfterThrowing.class }), new Converter()
/*     */     {
/*     */       public Annotation convert(Method method)
/*     */       {
/*  80 */         AbstractAspectJAdvisorFactory.AspectJAnnotation annotation = AbstractAspectJAdvisorFactory.findAspectJAnnotationOnMethod(method);
/*  81 */         return annotation == null ? null : annotation.getAnnotation();
/*     */       }
/*     */     }));
/*  84 */     comparator.addComparator(new ConvertingComparator(new Converter()
/*     */     {
/*     */       public String convert(Method method)
/*     */       {
/*  88 */         return method.getName();
/*     */       }
/*     */     }));
/*     */   }
/*     */ 
/*     */   protected static class SyntheticInstantiationAdvisor extends DefaultPointcutAdvisor
/*     */   {
/*     */     public SyntheticInstantiationAdvisor(MetadataAwareAspectInstanceFactory aif)
/*     */     {
/* 280 */       super(new MethodBeforeAdvice()
/*     */       {
/*     */         public void before(Method method, Object[] args, Object target)
/*     */         {
/* 284 */           ReflectiveAspectJAdvisorFactory.SyntheticInstantiationAdvisor.this.getAspectInstance();
/*     */         }
/*     */       });
/*     */     }
/*     */   }
/*     */ }

/* Location:           D:\Git\study\spring\WebRoot\WEB-INF\lib\spring-aop-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.aop.aspectj.annotation.ReflectiveAspectJAdvisorFactory
 * JD-Core Version:    0.6.2
 */