package org.springframework.aop.aspectj;

import org.springframework.aop.PointcutAdvisor;

public abstract interface InstantiationModelAwarePointcutAdvisor extends PointcutAdvisor
{
  public abstract boolean isLazy();

  public abstract boolean isAdviceInstantiated();
}

/* Location:           D:\Git\study\spring\WebRoot\WEB-INF\lib\spring-aop-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.aop.aspectj.InstantiationModelAwarePointcutAdvisor
 * JD-Core Version:    0.6.2
 */