/*    */ package org.springframework.aop.aspectj.annotation;
/*    */ 
/*    */ import org.springframework.util.Assert;
/*    */ 
/*    */ public class LazySingletonAspectInstanceFactoryDecorator
/*    */   implements MetadataAwareAspectInstanceFactory
/*    */ {
/*    */   private final MetadataAwareAspectInstanceFactory maaif;
/*    */   private volatile Object materialized;
/*    */ 
/*    */   public LazySingletonAspectInstanceFactoryDecorator(MetadataAwareAspectInstanceFactory maaif)
/*    */   {
/* 40 */     Assert.notNull(maaif, "AspectInstanceFactory must not be null");
/* 41 */     this.maaif = maaif;
/*    */   }
/*    */ 
/*    */   public synchronized Object getAspectInstance()
/*    */   {
/* 47 */     if (this.materialized == null) {
/* 48 */       synchronized (this) {
/* 49 */         if (this.materialized == null) {
/* 50 */           this.materialized = this.maaif.getAspectInstance();
/*    */         }
/*    */       }
/*    */     }
/* 54 */     return this.materialized;
/*    */   }
/*    */ 
/*    */   public boolean isMaterialized() {
/* 58 */     return this.materialized != null;
/*    */   }
/*    */ 
/*    */   public ClassLoader getAspectClassLoader()
/*    */   {
/* 63 */     return this.maaif.getAspectClassLoader();
/*    */   }
/*    */ 
/*    */   public AspectMetadata getAspectMetadata()
/*    */   {
/* 68 */     return this.maaif.getAspectMetadata();
/*    */   }
/*    */ 
/*    */   public int getOrder()
/*    */   {
/* 73 */     return this.maaif.getOrder();
/*    */   }
/*    */ 
/*    */   public String toString()
/*    */   {
/* 79 */     return "LazySingletonAspectInstanceFactoryDecorator: decorating " + this.maaif;
/*    */   }
/*    */ }

/* Location:           D:\Git\study\spring\WebRoot\WEB-INF\lib\spring-aop-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.aop.aspectj.annotation.LazySingletonAspectInstanceFactoryDecorator
 * JD-Core Version:    0.6.2
 */