package org.springframework.aop.aspectj.annotation;

import java.lang.reflect.Method;
import java.util.List;
import org.aopalliance.aop.Advice;
import org.springframework.aop.Advisor;
import org.springframework.aop.aspectj.AspectJExpressionPointcut;
import org.springframework.aop.framework.AopConfigException;

public abstract interface AspectJAdvisorFactory
{
  public abstract boolean isAspect(Class<?> paramClass);

  public abstract void validate(Class<?> paramClass)
    throws AopConfigException;

  public abstract List<Advisor> getAdvisors(MetadataAwareAspectInstanceFactory paramMetadataAwareAspectInstanceFactory);

  public abstract Advisor getAdvisor(Method paramMethod, MetadataAwareAspectInstanceFactory paramMetadataAwareAspectInstanceFactory, int paramInt, String paramString);

  public abstract Advice getAdvice(Method paramMethod, AspectJExpressionPointcut paramAspectJExpressionPointcut, MetadataAwareAspectInstanceFactory paramMetadataAwareAspectInstanceFactory, int paramInt, String paramString);
}

/* Location:           D:\Git\study\spring\WebRoot\WEB-INF\lib\spring-aop-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.aop.aspectj.annotation.AspectJAdvisorFactory
 * JD-Core Version:    0.6.2
 */