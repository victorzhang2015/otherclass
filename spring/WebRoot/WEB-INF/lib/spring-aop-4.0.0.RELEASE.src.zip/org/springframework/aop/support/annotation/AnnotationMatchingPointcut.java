/*     */ package org.springframework.aop.support.annotation;
/*     */ 
/*     */ import java.lang.annotation.Annotation;
/*     */ import org.springframework.aop.ClassFilter;
/*     */ import org.springframework.aop.MethodMatcher;
/*     */ import org.springframework.aop.Pointcut;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ public class AnnotationMatchingPointcut
/*     */   implements Pointcut
/*     */ {
/*     */   private final ClassFilter classFilter;
/*     */   private final MethodMatcher methodMatcher;
/*     */ 
/*     */   public AnnotationMatchingPointcut(Class<? extends Annotation> classAnnotationType)
/*     */   {
/*  48 */     this.classFilter = new AnnotationClassFilter(classAnnotationType);
/*  49 */     this.methodMatcher = MethodMatcher.TRUE;
/*     */   }
/*     */ 
/*     */   public AnnotationMatchingPointcut(Class<? extends Annotation> classAnnotationType, boolean checkInherited)
/*     */   {
/*  60 */     this.classFilter = new AnnotationClassFilter(classAnnotationType, checkInherited);
/*  61 */     this.methodMatcher = MethodMatcher.TRUE;
/*     */   }
/*     */ 
/*     */   public AnnotationMatchingPointcut(Class<? extends Annotation> classAnnotationType, Class<? extends Annotation> methodAnnotationType)
/*     */   {
/*  74 */     Assert.isTrue((classAnnotationType != null) || (methodAnnotationType != null), "Either Class annotation type or Method annotation type needs to be specified (or both)");
/*     */ 
/*  77 */     if (classAnnotationType != null) {
/*  78 */       this.classFilter = new AnnotationClassFilter(classAnnotationType);
/*     */     }
/*     */     else {
/*  81 */       this.classFilter = ClassFilter.TRUE;
/*     */     }
/*     */ 
/*  84 */     if (methodAnnotationType != null) {
/*  85 */       this.methodMatcher = new AnnotationMethodMatcher(methodAnnotationType);
/*     */     }
/*     */     else
/*  88 */       this.methodMatcher = MethodMatcher.TRUE;
/*     */   }
/*     */ 
/*     */   public ClassFilter getClassFilter()
/*     */   {
/*  95 */     return this.classFilter;
/*     */   }
/*     */ 
/*     */   public MethodMatcher getMethodMatcher()
/*     */   {
/* 100 */     return this.methodMatcher;
/*     */   }
/*     */ 
/*     */   public static AnnotationMatchingPointcut forClassAnnotation(Class<? extends Annotation> annotationType)
/*     */   {
/* 111 */     Assert.notNull(annotationType, "Annotation type must not be null");
/* 112 */     return new AnnotationMatchingPointcut(annotationType);
/*     */   }
/*     */ 
/*     */   public static AnnotationMatchingPointcut forMethodAnnotation(Class<? extends Annotation> annotationType)
/*     */   {
/* 122 */     Assert.notNull(annotationType, "Annotation type must not be null");
/* 123 */     return new AnnotationMatchingPointcut(null, annotationType);
/*     */   }
/*     */ }

/* Location:           D:\Git\study\spring\WebRoot\WEB-INF\lib\spring-aop-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.aop.support.annotation.AnnotationMatchingPointcut
 * JD-Core Version:    0.6.2
 */