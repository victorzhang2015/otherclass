/*    */ package org.springframework.aop.framework.adapter;
/*    */ 
/*    */ import org.springframework.beans.BeansException;
/*    */ import org.springframework.beans.factory.config.BeanPostProcessor;
/*    */ 
/*    */ public class AdvisorAdapterRegistrationManager
/*    */   implements BeanPostProcessor
/*    */ {
/* 38 */   private AdvisorAdapterRegistry advisorAdapterRegistry = GlobalAdvisorAdapterRegistry.getInstance();
/*    */ 
/*    */   public void setAdvisorAdapterRegistry(AdvisorAdapterRegistry advisorAdapterRegistry)
/*    */   {
/* 47 */     this.advisorAdapterRegistry = advisorAdapterRegistry;
/*    */   }
/*    */ 
/*    */   public Object postProcessBeforeInitialization(Object bean, String beanName)
/*    */     throws BeansException
/*    */   {
/* 53 */     return bean;
/*    */   }
/*    */ 
/*    */   public Object postProcessAfterInitialization(Object bean, String beanName) throws BeansException
/*    */   {
/* 58 */     if ((bean instanceof AdvisorAdapter)) {
/* 59 */       this.advisorAdapterRegistry.registerAdvisorAdapter((AdvisorAdapter)bean);
/*    */     }
/* 61 */     return bean;
/*    */   }
/*    */ }

/* Location:           D:\Git\study\spring\WebRoot\WEB-INF\lib\spring-aop-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.aop.framework.adapter.AdvisorAdapterRegistrationManager
 * JD-Core Version:    0.6.2
 */