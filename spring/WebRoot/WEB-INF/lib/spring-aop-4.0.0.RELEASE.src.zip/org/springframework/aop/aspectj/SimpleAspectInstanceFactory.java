/*    */ package org.springframework.aop.aspectj;
/*    */ 
/*    */ import org.springframework.aop.framework.AopConfigException;
/*    */ import org.springframework.util.Assert;
/*    */ 
/*    */ public class SimpleAspectInstanceFactory
/*    */   implements AspectInstanceFactory
/*    */ {
/*    */   private final Class<?> aspectClass;
/*    */ 
/*    */   public SimpleAspectInstanceFactory(Class<?> aspectClass)
/*    */   {
/* 40 */     Assert.notNull(aspectClass, "Aspect class must not be null");
/* 41 */     this.aspectClass = aspectClass;
/*    */   }
/*    */ 
/*    */   public final Class<?> getAspectClass()
/*    */   {
/* 48 */     return this.aspectClass;
/*    */   }
/*    */ 
/*    */   public final Object getAspectInstance()
/*    */   {
/*    */     try
/*    */     {
/* 55 */       return this.aspectClass.newInstance();
/*    */     }
/*    */     catch (InstantiationException ex) {
/* 58 */       throw new AopConfigException("Unable to instantiate aspect class [" + this.aspectClass.getName() + "]", ex);
/*    */     }
/*    */     catch (IllegalAccessException ex) {
/* 61 */       throw new AopConfigException("Cannot access element class [" + this.aspectClass.getName() + "]", ex);
/*    */     }
/*    */   }
/*    */ 
/*    */   public ClassLoader getAspectClassLoader()
/*    */   {
/* 67 */     return this.aspectClass.getClassLoader();
/*    */   }
/*    */ 
/*    */   public int getOrder()
/*    */   {
/* 80 */     return getOrderForAspectClass(this.aspectClass);
/*    */   }
/*    */ 
/*    */   protected int getOrderForAspectClass(Class<?> aspectClass)
/*    */   {
/* 91 */     return 2147483647;
/*    */   }
/*    */ }

/* Location:           D:\Git\study\spring\WebRoot\WEB-INF\lib\spring-aop-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.aop.aspectj.SimpleAspectInstanceFactory
 * JD-Core Version:    0.6.2
 */