/*     */ package org.springframework.aop.support;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import java.lang.reflect.Method;
/*     */ import org.springframework.aop.ClassFilter;
/*     */ import org.springframework.aop.MethodMatcher;
/*     */ import org.springframework.aop.Pointcut;
/*     */ import org.springframework.core.ControlFlow;
/*     */ import org.springframework.core.ControlFlowFactory;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ObjectUtils;
/*     */ 
/*     */ public class ControlFlowPointcut
/*     */   implements Pointcut, ClassFilter, MethodMatcher, Serializable
/*     */ {
/*     */   private Class<?> clazz;
/*     */   private String methodName;
/*     */   private int evaluations;
/*     */ 
/*     */   public ControlFlowPointcut(Class<?> clazz)
/*     */   {
/*  54 */     this(clazz, null);
/*     */   }
/*     */ 
/*     */   public ControlFlowPointcut(Class<?> clazz, String methodName)
/*     */   {
/*  65 */     Assert.notNull(clazz, "Class must not be null");
/*  66 */     this.clazz = clazz;
/*  67 */     this.methodName = methodName;
/*     */   }
/*     */ 
/*     */   public boolean matches(Class<?> clazz)
/*     */   {
/*  76 */     return true;
/*     */   }
/*     */ 
/*     */   public boolean matches(Method method, Class<?> targetClass)
/*     */   {
/*  85 */     return true;
/*     */   }
/*     */ 
/*     */   public boolean isRuntime()
/*     */   {
/*  90 */     return true;
/*     */   }
/*     */ 
/*     */   public boolean matches(Method method, Class<?> targetClass, Object[] args)
/*     */   {
/*  95 */     this.evaluations += 1;
/*  96 */     ControlFlow cflow = ControlFlowFactory.createControlFlow();
/*  97 */     return this.methodName != null ? cflow.under(this.clazz, this.methodName) : cflow.under(this.clazz);
/*     */   }
/*     */ 
/*     */   public int getEvaluations()
/*     */   {
/* 104 */     return this.evaluations;
/*     */   }
/*     */ 
/*     */   public ClassFilter getClassFilter()
/*     */   {
/* 110 */     return this;
/*     */   }
/*     */ 
/*     */   public MethodMatcher getMethodMatcher()
/*     */   {
/* 115 */     return this;
/*     */   }
/*     */ 
/*     */   public boolean equals(Object other)
/*     */   {
/* 120 */     if (this == other) {
/* 121 */       return true;
/*     */     }
/* 123 */     if (!(other instanceof ControlFlowPointcut)) {
/* 124 */       return false;
/*     */     }
/* 126 */     ControlFlowPointcut that = (ControlFlowPointcut)other;
/* 127 */     return (this.clazz.equals(that.clazz)) && (ObjectUtils.nullSafeEquals(that.methodName, this.methodName));
/*     */   }
/*     */ 
/*     */   public int hashCode()
/*     */   {
/* 132 */     int code = 17;
/* 133 */     code = 37 * code + this.clazz.hashCode();
/* 134 */     if (this.methodName != null) {
/* 135 */       code = 37 * code + this.methodName.hashCode();
/*     */     }
/* 137 */     return code;
/*     */   }
/*     */ }

/* Location:           D:\Git\study\spring\WebRoot\WEB-INF\lib\spring-aop-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.aop.support.ControlFlowPointcut
 * JD-Core Version:    0.6.2
 */