/*    */ package org.springframework.aop.aspectj;
/*    */ 
/*    */ import org.aopalliance.aop.Advice;
/*    */ import org.springframework.aop.Pointcut;
/*    */ import org.springframework.aop.PointcutAdvisor;
/*    */ import org.springframework.core.Ordered;
/*    */ import org.springframework.util.Assert;
/*    */ import org.springframework.util.ObjectUtils;
/*    */ 
/*    */ public class AspectJPointcutAdvisor
/*    */   implements PointcutAdvisor, Ordered
/*    */ {
/*    */   private final AbstractAspectJAdvice advice;
/*    */   private final Pointcut pointcut;
/*    */   private Integer order;
/*    */ 
/*    */   public AspectJPointcutAdvisor(AbstractAspectJAdvice advice)
/*    */   {
/* 49 */     Assert.notNull(advice, "Advice must not be null");
/* 50 */     this.advice = advice;
/* 51 */     this.pointcut = advice.buildSafePointcut();
/*    */   }
/*    */ 
/*    */   public void setOrder(int order) {
/* 55 */     this.order = Integer.valueOf(order);
/*    */   }
/*    */ 
/*    */   public boolean isPerInstance()
/*    */   {
/* 61 */     return true;
/*    */   }
/*    */ 
/*    */   public Advice getAdvice()
/*    */   {
/* 66 */     return this.advice;
/*    */   }
/*    */ 
/*    */   public Pointcut getPointcut()
/*    */   {
/* 71 */     return this.pointcut;
/*    */   }
/*    */ 
/*    */   public int getOrder()
/*    */   {
/* 76 */     if (this.order != null) {
/* 77 */       return this.order.intValue();
/*    */     }
/*    */ 
/* 80 */     return this.advice.getOrder();
/*    */   }
/*    */ 
/*    */   public boolean equals(Object other)
/*    */   {
/* 87 */     if (this == other) {
/* 88 */       return true;
/*    */     }
/* 90 */     if (!(other instanceof AspectJPointcutAdvisor)) {
/* 91 */       return false;
/*    */     }
/* 93 */     AspectJPointcutAdvisor otherAdvisor = (AspectJPointcutAdvisor)other;
/* 94 */     return ObjectUtils.nullSafeEquals(this.advice, otherAdvisor.advice);
/*    */   }
/*    */ 
/*    */   public int hashCode()
/*    */   {
/* 99 */     return AspectJPointcutAdvisor.class.hashCode();
/*    */   }
/*    */ }

/* Location:           D:\Git\study\spring\WebRoot\WEB-INF\lib\spring-aop-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.aop.aspectj.AspectJPointcutAdvisor
 * JD-Core Version:    0.6.2
 */