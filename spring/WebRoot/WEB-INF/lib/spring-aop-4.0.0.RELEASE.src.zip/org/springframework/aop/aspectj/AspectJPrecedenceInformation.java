package org.springframework.aop.aspectj;

import org.springframework.core.Ordered;

public abstract interface AspectJPrecedenceInformation extends Ordered
{
  public abstract String getAspectName();

  public abstract int getDeclarationOrder();

  public abstract boolean isBeforeAdvice();

  public abstract boolean isAfterAdvice();
}

/* Location:           D:\Git\study\spring\WebRoot\WEB-INF\lib\spring-aop-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.aop.aspectj.AspectJPrecedenceInformation
 * JD-Core Version:    0.6.2
 */