/*    */ package org.springframework.aop.support;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ import org.aopalliance.aop.Advice;
/*    */ import org.springframework.aop.Pointcut;
/*    */ 
/*    */ public class DefaultPointcutAdvisor extends AbstractGenericPointcutAdvisor
/*    */   implements Serializable
/*    */ {
/* 40 */   private Pointcut pointcut = Pointcut.TRUE;
/*    */ 
/*    */   public DefaultPointcutAdvisor()
/*    */   {
/*    */   }
/*    */ 
/*    */   public DefaultPointcutAdvisor(Advice advice)
/*    */   {
/* 57 */     this(Pointcut.TRUE, advice);
/*    */   }
/*    */ 
/*    */   public DefaultPointcutAdvisor(Pointcut pointcut, Advice advice)
/*    */   {
/* 66 */     this.pointcut = pointcut;
/* 67 */     setAdvice(advice);
/*    */   }
/*    */ 
/*    */   public void setPointcut(Pointcut pointcut)
/*    */   {
/* 77 */     this.pointcut = (pointcut != null ? pointcut : Pointcut.TRUE);
/*    */   }
/*    */ 
/*    */   public Pointcut getPointcut()
/*    */   {
/* 82 */     return this.pointcut;
/*    */   }
/*    */ 
/*    */   public String toString()
/*    */   {
/* 88 */     return getClass().getName() + ": pointcut [" + getPointcut() + "]; advice [" + getAdvice() + "]";
/*    */   }
/*    */ }

/* Location:           D:\Git\study\spring\WebRoot\WEB-INF\lib\spring-aop-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.aop.support.DefaultPointcutAdvisor
 * JD-Core Version:    0.6.2
 */