package org.springframework.aop;

import java.lang.reflect.Method;

public abstract interface IntroductionAwareMethodMatcher extends MethodMatcher
{
  public abstract boolean matches(Method paramMethod, Class<?> paramClass, boolean paramBoolean);
}

/* Location:           D:\Git\study\spring\WebRoot\WEB-INF\lib\spring-aop-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.aop.IntroductionAwareMethodMatcher
 * JD-Core Version:    0.6.2
 */