/*    */ package org.springframework.aop.aspectj.annotation;
/*    */ 
/*    */ import org.springframework.beans.factory.BeanFactory;
/*    */ 
/*    */ public class PrototypeAspectInstanceFactory extends BeanFactoryAspectInstanceFactory
/*    */ {
/*    */   public PrototypeAspectInstanceFactory(BeanFactory beanFactory, String name)
/*    */   {
/* 45 */     super(beanFactory, name);
/* 46 */     if (!beanFactory.isPrototype(name))
/* 47 */       throw new IllegalArgumentException("Cannot use PrototypeAspectInstanceFactory with bean named '" + name + "': not a prototype");
/*    */   }
/*    */ }

/* Location:           D:\Git\study\spring\WebRoot\WEB-INF\lib\spring-aop-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.aop.aspectj.annotation.PrototypeAspectInstanceFactory
 * JD-Core Version:    0.6.2
 */