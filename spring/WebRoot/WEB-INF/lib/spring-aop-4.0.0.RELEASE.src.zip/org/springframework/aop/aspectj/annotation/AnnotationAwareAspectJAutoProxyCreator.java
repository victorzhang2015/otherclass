/*     */ package org.springframework.aop.aspectj.annotation;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.regex.Matcher;
/*     */ import java.util.regex.Pattern;
/*     */ import org.springframework.aop.Advisor;
/*     */ import org.springframework.aop.aspectj.autoproxy.AspectJAwareAdvisorAutoProxyCreator;
/*     */ import org.springframework.beans.factory.ListableBeanFactory;
/*     */ import org.springframework.beans.factory.config.ConfigurableListableBeanFactory;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ public class AnnotationAwareAspectJAutoProxyCreator extends AspectJAwareAdvisorAutoProxyCreator
/*     */ {
/*     */   private List<Pattern> includePatterns;
/*     */   private AspectJAdvisorFactory aspectJAdvisorFactory;
/*     */   private BeanFactoryAspectJAdvisorsBuilder aspectJAdvisorsBuilder;
/*     */ 
/*     */   public AnnotationAwareAspectJAutoProxyCreator()
/*     */   {
/*  53 */     this.aspectJAdvisorFactory = new ReflectiveAspectJAdvisorFactory();
/*     */   }
/*     */ 
/*     */   public void setIncludePatterns(List<String> patterns)
/*     */   {
/*  63 */     this.includePatterns = new ArrayList(patterns.size());
/*  64 */     for (String patternText : patterns)
/*  65 */       this.includePatterns.add(Pattern.compile(patternText));
/*     */   }
/*     */ 
/*     */   public void setAspectJAdvisorFactory(AspectJAdvisorFactory aspectJAdvisorFactory)
/*     */   {
/*  70 */     Assert.notNull(this.aspectJAdvisorFactory, "AspectJAdvisorFactory must not be null");
/*  71 */     this.aspectJAdvisorFactory = aspectJAdvisorFactory;
/*     */   }
/*     */ 
/*     */   protected void initBeanFactory(ConfigurableListableBeanFactory beanFactory)
/*     */   {
/*  76 */     super.initBeanFactory(beanFactory);
/*  77 */     this.aspectJAdvisorsBuilder = new BeanFactoryAspectJAdvisorsBuilderAdapter(beanFactory, this.aspectJAdvisorFactory);
/*     */   }
/*     */ 
/*     */   protected List<Advisor> findCandidateAdvisors()
/*     */   {
/*  85 */     List advisors = super.findCandidateAdvisors();
/*     */ 
/*  87 */     advisors.addAll(this.aspectJAdvisorsBuilder.buildAspectJAdvisors());
/*  88 */     return advisors;
/*     */   }
/*     */ 
/*     */   protected boolean isInfrastructureClass(Class<?> beanClass)
/*     */   {
/* 101 */     return (super.isInfrastructureClass(beanClass)) || (this.aspectJAdvisorFactory.isAspect(beanClass));
/*     */   }
/*     */ 
/*     */   protected boolean isEligibleAspectBean(String beanName)
/*     */   {
/* 111 */     if (this.includePatterns == null) {
/* 112 */       return true;
/*     */     }
/*     */ 
/* 115 */     for (Pattern pattern : this.includePatterns) {
/* 116 */       if (pattern.matcher(beanName).matches()) {
/* 117 */         return true;
/*     */       }
/*     */     }
/* 120 */     return false;
/*     */   }
/*     */ 
/*     */   private class BeanFactoryAspectJAdvisorsBuilderAdapter extends BeanFactoryAspectJAdvisorsBuilder
/*     */   {
/*     */     public BeanFactoryAspectJAdvisorsBuilderAdapter(ListableBeanFactory beanFactory, AspectJAdvisorFactory advisorFactory)
/*     */     {
/* 133 */       super(advisorFactory);
/*     */     }
/*     */ 
/*     */     protected boolean isEligibleBean(String beanName)
/*     */     {
/* 138 */       return AnnotationAwareAspectJAutoProxyCreator.this.isEligibleAspectBean(beanName);
/*     */     }
/*     */   }
/*     */ }

/* Location:           D:\Git\study\spring\WebRoot\WEB-INF\lib\spring-aop-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.aop.aspectj.annotation.AnnotationAwareAspectJAutoProxyCreator
 * JD-Core Version:    0.6.2
 */