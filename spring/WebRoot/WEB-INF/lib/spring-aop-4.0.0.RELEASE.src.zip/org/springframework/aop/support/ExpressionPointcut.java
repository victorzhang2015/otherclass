package org.springframework.aop.support;

import org.springframework.aop.Pointcut;

public abstract interface ExpressionPointcut extends Pointcut
{
  public abstract String getExpression();
}

/* Location:           D:\Git\study\spring\WebRoot\WEB-INF\lib\spring-aop-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.aop.support.ExpressionPointcut
 * JD-Core Version:    0.6.2
 */