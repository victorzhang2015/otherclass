/*    */ package org.springframework.aop.aspectj.annotation;
/*    */ 
/*    */ import org.springframework.aop.aspectj.SimpleAspectInstanceFactory;
/*    */ import org.springframework.core.annotation.AnnotationUtils;
/*    */ import org.springframework.core.annotation.Order;
/*    */ 
/*    */ public class SimpleMetadataAwareAspectInstanceFactory extends SimpleAspectInstanceFactory
/*    */   implements MetadataAwareAspectInstanceFactory
/*    */ {
/*    */   private final AspectMetadata metadata;
/*    */ 
/*    */   public SimpleMetadataAwareAspectInstanceFactory(Class<?> aspectClass, String aspectName)
/*    */   {
/* 44 */     super(aspectClass);
/* 45 */     this.metadata = new AspectMetadata(aspectClass, aspectName);
/*    */   }
/*    */ 
/*    */   public final AspectMetadata getAspectMetadata()
/*    */   {
/* 51 */     return this.metadata;
/*    */   }
/*    */ 
/*    */   protected int getOrderForAspectClass(Class<?> aspectClass)
/*    */   {
/* 63 */     Order order = (Order)AnnotationUtils.findAnnotation(aspectClass, Order.class);
/* 64 */     if (order != null) {
/* 65 */       return order.value();
/*    */     }
/* 67 */     return 2147483647;
/*    */   }
/*    */ }

/* Location:           D:\Git\study\spring\WebRoot\WEB-INF\lib\spring-aop-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.aop.aspectj.annotation.SimpleMetadataAwareAspectInstanceFactory
 * JD-Core Version:    0.6.2
 */