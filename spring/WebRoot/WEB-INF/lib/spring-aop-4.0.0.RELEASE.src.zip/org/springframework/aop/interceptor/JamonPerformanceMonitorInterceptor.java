/*     */ package org.springframework.aop.interceptor;
/*     */ 
/*     */ import com.jamonapi.Monitor;
/*     */ import com.jamonapi.MonitorFactory;
/*     */ import org.aopalliance.intercept.MethodInvocation;
/*     */ import org.apache.commons.logging.Log;
/*     */ 
/*     */ public class JamonPerformanceMonitorInterceptor extends AbstractMonitoringInterceptor
/*     */ {
/*  41 */   private boolean trackAllInvocations = false;
/*     */ 
/*     */   public JamonPerformanceMonitorInterceptor()
/*     */   {
/*     */   }
/*     */ 
/*     */   public JamonPerformanceMonitorInterceptor(boolean useDynamicLogger)
/*     */   {
/*  57 */     setUseDynamicLogger(useDynamicLogger);
/*     */   }
/*     */ 
/*     */   public JamonPerformanceMonitorInterceptor(boolean useDynamicLogger, boolean trackAllInvocations)
/*     */   {
/*  69 */     setUseDynamicLogger(useDynamicLogger);
/*  70 */     setTrackAllInvocations(trackAllInvocations);
/*     */   }
/*     */ 
/*     */   public void setTrackAllInvocations(boolean trackAllInvocations)
/*     */   {
/*  82 */     this.trackAllInvocations = trackAllInvocations;
/*     */   }
/*     */ 
/*     */   protected boolean isInterceptorEnabled(MethodInvocation invocation, Log logger)
/*     */   {
/*  94 */     return (this.trackAllInvocations) || (isLogEnabled(logger));
/*     */   }
/*     */ 
/*     */   protected Object invokeUnderTrace(MethodInvocation invocation, Log logger)
/*     */     throws Throwable
/*     */   {
/* 105 */     String name = createInvocationTraceName(invocation);
/* 106 */     Monitor monitor = MonitorFactory.start(name);
/*     */     try {
/* 108 */       return invocation.proceed();
/*     */     }
/*     */     finally {
/* 111 */       monitor.stop();
/* 112 */       if ((!this.trackAllInvocations) || (isLogEnabled(logger)))
/* 113 */         logger.trace("JAMon performance statistics for method [" + name + "]:\n" + monitor);
/*     */     }
/*     */   }
/*     */ }

/* Location:           D:\Git\study\spring\WebRoot\WEB-INF\lib\spring-aop-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.aop.interceptor.JamonPerformanceMonitorInterceptor
 * JD-Core Version:    0.6.2
 */