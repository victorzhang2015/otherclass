/*     */ package org.springframework.aop.framework;
/*     */ 
/*     */ import java.util.Arrays;
/*     */ import org.springframework.aop.SpringProxy;
/*     */ import org.springframework.aop.TargetClassAware;
/*     */ import org.springframework.aop.TargetSource;
/*     */ import org.springframework.aop.support.AopUtils;
/*     */ import org.springframework.aop.target.SingletonTargetSource;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ public abstract class AopProxyUtils
/*     */ {
/*     */   public static Class<?> ultimateTargetClass(Object candidate)
/*     */   {
/*  52 */     Assert.notNull(candidate, "Candidate object must not be null");
/*  53 */     Object current = candidate;
/*  54 */     Class result = null;
/*  55 */     while ((current instanceof TargetClassAware)) {
/*  56 */       result = ((TargetClassAware)current).getTargetClass();
/*  57 */       Object nested = null;
/*  58 */       if ((current instanceof Advised)) {
/*  59 */         TargetSource targetSource = ((Advised)current).getTargetSource();
/*  60 */         if ((targetSource instanceof SingletonTargetSource)) {
/*  61 */           nested = ((SingletonTargetSource)targetSource).getTarget();
/*     */         }
/*     */       }
/*  64 */       current = nested;
/*     */     }
/*  66 */     if (result == null) {
/*  67 */       result = AopUtils.isCglibProxy(candidate) ? candidate.getClass().getSuperclass() : candidate.getClass();
/*     */     }
/*  69 */     return result;
/*     */   }
/*     */ 
/*     */   public static Class<?>[] completeProxiedInterfaces(AdvisedSupport advised)
/*     */   {
/*  82 */     Class[] specifiedInterfaces = advised.getProxiedInterfaces();
/*  83 */     if (specifiedInterfaces.length == 0)
/*     */     {
/*  85 */       Class targetClass = advised.getTargetClass();
/*  86 */       if ((targetClass != null) && (targetClass.isInterface())) {
/*  87 */         specifiedInterfaces = new Class[] { targetClass };
/*     */       }
/*     */     }
/*  90 */     boolean addSpringProxy = !advised.isInterfaceProxied(SpringProxy.class);
/*  91 */     boolean addAdvised = (!advised.isOpaque()) && (!advised.isInterfaceProxied(Advised.class));
/*  92 */     int nonUserIfcCount = 0;
/*  93 */     if (addSpringProxy) {
/*  94 */       nonUserIfcCount++;
/*     */     }
/*  96 */     if (addAdvised) {
/*  97 */       nonUserIfcCount++;
/*     */     }
/*  99 */     Class[] proxiedInterfaces = new Class[specifiedInterfaces.length + nonUserIfcCount];
/* 100 */     System.arraycopy(specifiedInterfaces, 0, proxiedInterfaces, 0, specifiedInterfaces.length);
/* 101 */     if (addSpringProxy) {
/* 102 */       proxiedInterfaces[specifiedInterfaces.length] = SpringProxy.class;
/*     */     }
/* 104 */     if (addAdvised) {
/* 105 */       proxiedInterfaces[(proxiedInterfaces.length - 1)] = Advised.class;
/*     */     }
/* 107 */     return proxiedInterfaces;
/*     */   }
/*     */ 
/*     */   public static Class<?>[] proxiedUserInterfaces(Object proxy)
/*     */   {
/* 119 */     Class[] proxyInterfaces = proxy.getClass().getInterfaces();
/* 120 */     int nonUserIfcCount = 0;
/* 121 */     if ((proxy instanceof SpringProxy)) {
/* 122 */       nonUserIfcCount++;
/*     */     }
/* 124 */     if ((proxy instanceof Advised)) {
/* 125 */       nonUserIfcCount++;
/*     */     }
/* 127 */     Class[] userInterfaces = new Class[proxyInterfaces.length - nonUserIfcCount];
/* 128 */     System.arraycopy(proxyInterfaces, 0, userInterfaces, 0, userInterfaces.length);
/* 129 */     Assert.notEmpty(userInterfaces, "JDK proxy must implement one or more interfaces");
/* 130 */     return userInterfaces;
/*     */   }
/*     */ 
/*     */   public static boolean equalsInProxy(AdvisedSupport a, AdvisedSupport b)
/*     */   {
/* 140 */     return (a == b) || (
/* 140 */       (equalsProxiedInterfaces(a, b)) && 
/* 140 */       (equalsAdvisors(a, b)) && (a.getTargetSource().equals(b.getTargetSource())));
/*     */   }
/*     */ 
/*     */   public static boolean equalsProxiedInterfaces(AdvisedSupport a, AdvisedSupport b)
/*     */   {
/* 147 */     return Arrays.equals(a.getProxiedInterfaces(), b.getProxiedInterfaces());
/*     */   }
/*     */ 
/*     */   public static boolean equalsAdvisors(AdvisedSupport a, AdvisedSupport b)
/*     */   {
/* 154 */     return Arrays.equals(a.getAdvisors(), b.getAdvisors());
/*     */   }
/*     */ }

/* Location:           D:\Git\study\spring\WebRoot\WEB-INF\lib\spring-aop-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.aop.framework.AopProxyUtils
 * JD-Core Version:    0.6.2
 */